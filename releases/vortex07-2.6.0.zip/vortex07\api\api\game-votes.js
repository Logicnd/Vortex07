import { applyCors, handleOptions } from "../lib/http.js";
import { enforceRateLimit } from "../lib/rate-limit.js";
import {
  getGameVotes,
  hasPersistentStore,
  isValidGameId,
  isValidVoterId,
  setGameVote,
} from "../lib/game-votes-store.js";

export default async function handler(req, res) {
  applyCors(res, req);
  if (handleOptions(req, res)) return;

  const gameId = String(req.query?.gameId || req.body?.gameId || "").trim();
  const voterId = String(req.query?.voterId || req.body?.voterId || "").trim();

  if (!isValidGameId(gameId)) {
    res.status(400).json({ error: "Invalid gameId" });
    return;
  }

  if (!isValidVoterId(voterId)) {
    res.status(400).json({ error: "Invalid voterId" });
    return;
  }

  if (req.method === "GET") {
    if (
      !(await enforceRateLimit(req, res, {
        route: "game-votes-get",
        limit: 120,
        windowSec: 60,
        voterId,
        voterLimit: 60,
      }))
    ) {
      return;
    }

    const result = await getGameVotes(gameId, voterId);
    res.status(200).json({ ...result, persistent: hasPersistentStore() });
    return;
  }

  if (req.method === "POST") {
    if (
      !(await enforceRateLimit(req, res, {
        route: "game-votes-post",
        limit: 40,
        windowSec: 60,
        voterId,
        voterLimit: 20,
      }))
    ) {
      return;
    }

    const rawVote = req.body?.vote;
    const vote =
      rawVote === null || rawVote === undefined || rawVote === ""
        ? null
        : String(rawVote).trim();

    if (vote !== null && vote !== "like" && vote !== "dislike") {
      res.status(400).json({ error: "Invalid vote" });
      return;
    }

    const result = await setGameVote(gameId, voterId, vote);
    res.status(200).json({ ...result, persistent: hasPersistentStore() });
    return;
  }

  res.status(405).json({ error: "Method not allowed" });
}
