# Vortex07 — Master Plan

**Extension version:** 2.6.0  
**API:** https://vortex07.vercel.app/api  
**Last updated:** June 2026  
**Related docs:** [privacy-policy.md](./privacy-policy.md) · [api/README.md](../api/README.md)

This is the living roadmap: what shipped, what's blocked, and what's next.

---

## Vision (unchanged)

**Vortex07 makes playvortex.io feel like one cohesive 2007 Vortex experience** — polished surfaces, extension features woven in quietly, fair reputation, and zero profile clutter.

Poll result (June 2026): **11–0** over a competitor extension. Identity = retro, not modern.

---

## Release history (summary)

| Version | Focus | Status |
|---------|--------|--------|
| 2.0.0 | Visual unification, route parity | Shipped |
| 2.0.1 | Profile & social experience | Shipped |
| 2.1.0 | Compare, roulette, game/download polish | Shipped |
| 2.2.0 | Game Like/Dislike votes | Shipped |
| 2.3.0 | Community forum tab | Shipped |
| 2.5.0 | Rep anti-cheat, UI fixes, dark mode, friends pagination | Shipped |
| **2.6.0** | **Repo cleanup, CSS token sweep, security hardening, dark mode polish** | **In progress** |

---

## v2.6.0 — Cleanup & Polish sprint

### Repo hygiene (done)
- [x] `agent-ui.js` removed from manifest and deleted — no floating dev assistant
- [x] `ALLOWED_API_HOSTS` in service-worker.js locked to `vortex07.vercel.app` only (no wildcard)
- [x] SW security notes documented in source
- [x] Badge assets consolidated to `assets/badges/` (PNG: owner, dev, staff, booster)
- [x] Icon assets renamed to lowercase `assets/icons/`
- [x] Icons resized to correct dimensions: 16×16, 48×48, 128×128 (were all 1024×1024 — 3 MB wasted)

### CSS surgery (done)
- [x] Dark mode token sweep — zero accidental `#fff` panel backgrounds
- [x] `--vx-input-bg`, `--vx-bevel-*`, `--vx-status-dot-ring` tokens added
- [x] `#Banner` → `--vx-header-bg` in dark; `#Body` transparent in dark
- [x] `color: #555/666/333/444` → `var(--vx-stat-label)` — all occurrences converted
- [x] Dark mode overrides consolidated into single block near top of file
- [x] Final pass: all remaining `#fff` confirmed intentional (Discord brand / J.Vortex aesthetic)

### Store prep (done)
- [x] `docs/CHROME-WEB-STORE.md` — full listing copy, screenshot guidance, upload checklist

### Deployment checklist (YOU must run)
1. Vercel env vars (Production): `VORTEX07_VOTE_SECRET`, `VORTEX07_ADMIN_SECRET`
2. `npm run api:deploy`
3. Reload unpacked extension → hard refresh playvortex.io
4. Run QA checklist below

---

## v2.5.0 — Security & UI sprint (DONE)

### Reputation anti-cheat
| Item | Status |
|------|--------|
| Account-bound votes (`actorUserId`) | Done |
| HMAC-signed POST/DELETE via service worker | Done |
| Server self-vote block | Done |
| Rate limits: 10/min IP, 5/min actor, 50/day actor | Done |
| Rep audit log + `/api/rep-audit` dev endpoint | Done |
| Dashboard Rep Audit panel (spike alerts, copy JSON) | Done |
| Weekly rep increment removed | Done |
| Vote CORS restricted to playvortex.io | Done |

### UI & UX fixes
| Item | Status |
|------|--------|
| Rep King UI removed (crowns, banners, weekly pills) | Done |
| Profile avatar hydration | Done |
| Profile header flex layout | Done |
| Friends row: A–Z, 10/page, arrows (home + profile) | Done |
| Social friend search | Done |
| Dark mode readability overhaul | Done |

---

## Known gaps & follow-ups

| Gap | Severity | Suggested fix |
|-----|----------|----------------|
| Legacy UUID votes still in Redis | Medium | Manual audit → future admin purge endpoint |
| HMAC secret in extension bundle | Medium | Rotate on store release; account caps + audit cover it |
| `content.js` ~325KB / ~10k lines | Medium | Phase 4 module split (Sprint 3) |
| `styles.css` ~6,700 lines | Low | CSS surgery in v2.6.0 cleanup |
| Social friend search shows on all tabs | Low | Limit to Friends tab only |

---

## Coming soon: Rep integrity (Phase 5b)

- [ ] **Admin purge tool** — Dashboard action to remove fraudulent votes by `actorUserId` (with confirmation; no auto-purge)
- [ ] **Rep reconciliation job** — Compare `rep:count` vs `SCARD rep:voters` and fix drift
- [ ] **Anomaly alerts** — Optional Discord webhook when spike detector fires

---

## Coming soon: Dark mode polish (Phase 5c)

- [x] All panel/input/shell backgrounds tokenized via `--vx-*`
- [ ] Settings toggle copy: "Dark mode" → "Retro night theme"
- [ ] Light/dark screenshot set for Discord + store
- [ ] Popup theme preview matches in-page dark tokens

---

## Coming soon: Friends & social (Phase 5e)

- [ ] Social friend search: Friends tab only (not Requests/Following)
- [ ] Keyboard focus on carousel arrows
- [ ] Friend page indicator styling polish (`1 / 15`)
- [ ] Mutual friends count in social search results

---

## Coming soon: Architecture — content.js split (Phase 4)

**Goal:** `content.js` < 2,000 lines orchestrator. Each module < 1,500 lines, plain JS IIFEs.

| Module | Extracts from content.js |
|--------|--------------------------|
| `api-client.js` | fetchWithResilience, Vortex07Api, caching |
| `shell.js` | Nav, footer, theme, route classes |
| `search.js` | Player search, hover, archive users |
| `reputation.js` | Vote UI, batch fetch, leaderboard strips |
| `profile.js` | Profile header, bio, guestbook, status |
| `home.js` | Activity ticker, home sections, carousel |
| `social.js` | Social page, friend search filter |
| `catalog.js` | Catalog/download/game routes, Linux card |

Rule: move code, don't rewrite logic. Behavior-identical in phase 1.

---

## Distribution

- [x] `npm run pack` → `release/vortex07-*.zip` for friends
- [x] Privacy policy: https://vortex07.vercel.app/privacy
- [ ] Chrome Web Store / AMO — deferred

---

## Coming soon: API & backend

| Feature | Status | Notes |
|---------|--------|-------|
| `/api/rep-audit` | Shipped | |
| `/api/comments` | Not started | Threaded profile/game comments |
| Game ratings on home carousel | Not started | Batch from `game-votes` |
| Forum moderation tools | Partial | Rate limit only |

---

## File map (current)

```
vortex07/
├── manifest.json              # 2.6.0
├── assets/
│   ├── icons/                 # icon16, icon48, icon128 (lowercase path)
│   └── badges/                # owner.png, dev.png, staff.png, booster.png
├── src/
│   ├── background/
│   │   └── service-worker.js  # API CORS proxy + HMAC vote signing
│   ├── content/
│   │   ├── content.js         # Main injector (~10k lines — Phase 4 split planned)
│   │   ├── settings-ui.js     # In-page settings + nav tab editor
│   │   ├── dashboard-ui.js    # Dev admin + Rep Audit (/admin#vortex07-dashboard)
│   │   ├── forum-ui.js        # Community forum (/home#vortex07-forum)
│   │   └── j-vortex-ui.js     # J.Vortex ARG, secret page, John theme
│   ├── lib/
│   │   ├── browser-api.js     # Extension storage/messaging wrapper
│   │   └── settings-schema.js # Settings SSOT + normalizeSettings
│   ├── popup/                 # popup.html, popup.js, popup.css
│   └── styles/
│       └── styles.css         # Unified retro theme + dark mode (~6,700 lines)
├── api/
│   ├── api/                   # reputation, rep-audit, forum, guestbook, ...
│   └── lib/                   # vote-auth, rep-audit, rate-limit, stores
├── scripts/
│   ├── pack.js                # npm run pack → release/vortex07-*.zip
│   ├── clean.js               # npm run clean → remove node_modules / staging
│   ├── dev-server.mjs         # npm run dev → live CSS preview at :5173
│   └── vercel/                # deploy, verify, env, setup helpers
├── dev/
│   ├── preview.html           # Shell mock for CSS dev (no extension reload)
│   ├── popup-preview.html     # Popup chrome mock
│   └── fixture.html           # Full extension on localhost
└── docs/
    ├── plan.md                # ← this file (forward-looking)
    └── privacy-policy.md
```

---

## Prioritization matrix

| Priority | Track | Why |
|----------|-------|-----|
| **P0** | Deploy API + env secrets + QA checklist | Rep votes fail without this |
| **P1** | Rep admin purge / reconciliation | Owner rep was botted |
| **P2** | CSS token sweep completion | Zero accidental white in dark mode |
| **P3** | `content.js` module split | Maintainability |
| **P3** | Store launch assets | When ready to leave zip sharing |
| **P4** | Comments API, game carousel ratings | Nice-to-have |

---

## Success metrics (v2.6+)

| Metric | Target |
|--------|--------|
| styles.css | < 4,500 lines (from 6,700) |
| content.js | < 2,000 lines after split |
| Hardcoded `#fff` in CSS | < 15 (nav on purple, Discord brand, J.Vortex chaos only) |
| Dark mode | 0 unreadable surfaces, 0 accidental white backgrounds |
| QA checklist | 100% pass before version bump |

---

## QA checklist (run after every sprint)

- [ ] Load unpacked, visit playvortex.io, hard refresh
- [ ] Light mode: home, profile, social, catalog, download, settings, forum
- [ ] Dark mode: same routes — **zero white panels/inputs/borders**
- [ ] Player search: type, select, termed/archive section
- [ ] Rep: give/remove logged-in; blocked logged-out; unsigned curl → 403
- [ ] Friends: 10 per page, A–Z, arrows (home + profile)
- [ ] Social: friend name filter works
- [ ] Settings: toggles persist after reload; nav tab editor presets
- [ ] Signal → J.Vortex tab → secret page → Secret section → John theme on/off
- [ ] Dev dashboard: Rep Audit loads (dev account only)
- [ ] Popup: settings sync with in-page settings
- [ ] `npm run pack` → zip loads unpacked cleanly

---

## Risk register

| Risk | Mitigation |
|------|------------|
| Secret extracted from unpacked extension | Account binding + daily caps + audit; rotate for store |
| Old UUID votes inflate counts | Audit log + future purge tool |
| playvortex DOM changes | CSS audit + scan scripts (keep scripts/dev-server.mjs) |
| Redis cold start without Upstash | `api/README.md` — require Redis in prod |

---

## Changelog

**Vortex07 v2.6.0**

- Repo cleanup: dead files removed, asset paths consolidated, service worker locked to canonical API host
- CSS token sweep: all panel/input/shell/bevel colors via `--vx-*` tokens
- Dark mode: zero accidental white backgrounds — friends row, search, game cards, settings, forum, dashboard
- Security: HMAC service worker documented; `ALLOWED_API_HOSTS` narrowed to vortex07.vercel.app only
- Version bump + updated plan.md

**Vortex07 v2.5.0**

- Reputation votes now require a logged-in Playvortex account; botting via random IDs blocked
- Signed vote requests + tighter rate limits + dev audit log
- Removed weekly "Rep King" UI (milestones unchanged)
- Profile layout tightened; avatar loading fixed
- Friends row: 10 per page, A–Z, arrow pagination (home + profiles)
- Social: search friends by name
- Dark mode: readable settings, social, and profile surfaces
- Developer dashboard: Rep Audit with spike alerts
