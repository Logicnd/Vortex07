#!/usr/bin/env node
/**
 * Sync required Vortex07 API secrets to Vercel (production + preview + development).
 * Uses the Vercel REST API — no interactive CLI prompts.
 */
const { PROJECT, vercelFetch } = require("./config.js");

const REQUIRED_ENVS = {
  VORTEX07_VOTE_SECRET: "vortex07-vote-hmac-v2-5-0-playvortex",
  VORTEX07_ADMIN_SECRET: "vortex07-admin-audit-v2-5-0",
};

const TARGETS = ["production", "preview", "development"];

function teamQuery() {
  return `?teamId=${encodeURIComponent(PROJECT.teamId)}`;
}

async function listEnvs() {
  const body = await vercelFetch(`/v10/projects/${PROJECT.id}/env${teamQuery()}`);
  return body.envs || [];
}

function hasEnv(envs, key, target) {
  return envs.some(
    (entry) => entry.key === key && Array.isArray(entry.target) && entry.target.includes(target),
  );
}

async function createEnv(key, value, target) {
  await vercelFetch(`/v10/projects/${PROJECT.id}/env${teamQuery()}`, {
    method: "POST",
    body: JSON.stringify({
      key,
      value,
      type: "encrypted",
      target: [target],
    }),
  });
}

async function main() {
  console.log("=== Vortex07 API env sync ===\n");
  console.log(`Project: ${PROJECT.name} (${PROJECT.productionUrl})\n`);

  let envs = [];
  try {
    envs = await listEnvs();
  } catch (err) {
    console.warn("Could not list env vars:", err.message);
  }

  for (const [name, value] of Object.entries(REQUIRED_ENVS)) {
    for (const target of TARGETS) {
      if (hasEnv(envs, name, target)) {
        console.log(`✓ ${name} (${target}) — already set`);
        continue;
      }

      try {
        await createEnv(name, value, target);
        console.log(`+ ${name} (${target}) — synced`);
      } catch (err) {
        console.warn(`! ${name} (${target}) — ${err.message}`);
      }
    }
  }

  console.log("\nEnv sync complete.");
}

main().catch((err) => {
  console.error("Env sync failed:", err.message);
  process.exit(1);
});
