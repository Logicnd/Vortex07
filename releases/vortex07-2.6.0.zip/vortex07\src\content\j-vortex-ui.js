/* J.Vortex — secret page (unlocked via the signal sequence). */
(function initVortex07JVortexUi(global) {
  const JOHN_VORTEX_USER_ID = 90;
  const JOHN_VORTEX_PROFILE = `/users/${JOHN_VORTEX_USER_ID}/profile`;
  const WITNESS_COUNT = 42;
  const JOHN_SPAM_FLOATS = 40;
  const JOHN_HEADER_STAMPS = 14;
  const JOHN_LOGO_ORBITS = 10;

  let johnProfileCache = null;
  let johnProfilePromise = null;

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function safeSrc(value) {
    const src = String(value || "").trim();
    if (!src) return "";
    if (src.startsWith("https://") || src.startsWith("http://") || src.startsWith("/")) return src;
    if (src.startsWith("data:image/")) return src;
    if (src.length > 80 && /^[A-Za-z0-9+/=]+$/.test(src)) {
      return `data:image/png;base64,${src}`;
    }
    return "";
  }

  function pickAvatarFromPayload(payload) {
    if (!payload || typeof payload !== "object") return "";

    if (typeof payload === "string") return safeSrc(payload);

    const direct = safeSrc(
      payload.dataUri ||
        payload.avatarUrl ||
        payload.avatar_url ||
        payload.avatar ||
        payload.picture ||
        payload.image ||
        payload.url ||
        payload.headshot,
    );
    if (direct) return direct;

    const bucket =
      payload.avatars || payload.pictures || payload.data || payload;
    if (bucket && typeof bucket === "object" && !Array.isArray(bucket)) {
      const keyed = bucket[String(JOHN_VORTEX_USER_ID)] ?? bucket[JOHN_VORTEX_USER_ID];
      if (keyed) return pickAvatarFromPayload(keyed);
    }

    if (Array.isArray(payload)) {
      const row = payload.find(
        (entry) =>
          Number(entry?.id ?? entry?.userId ?? entry?.user_id) === JOHN_VORTEX_USER_ID,
      );
      if (row) return pickAvatarFromPayload(row);
    }

    return "";
  }

  function avatarFallback(name) {
    const letter = escapeHtml(String(name || "J").charAt(0).toUpperCase() || "J");
    return `<span class="vortex07-jvortex-avatar-fallback">${letter}</span>`;
  }

  function imgTag(src, alt, className, eager = false) {
    const clean = safeSrc(src);
    if (!clean) return avatarFallback(alt);
    return `<img class="${className}" src="${escapeHtml(clean)}" alt="${escapeHtml(alt)}" loading="${eager ? "eager" : "lazy"}" decoding="async" />`;
  }

  function buildWitnessCells() {
    let html = "";
    for (let i = 0; i < WITNESS_COUNT; i += 1) {
      html += `<td class="vortex07-jvortex-witness-cell" data-jvortex-witness="${i}"><a href="${JOHN_VORTEX_PROFILE}">${avatarFallback("J")}</a></td>`;
      if ((i + 1) % 7 === 0 && i + 1 < WITNESS_COUNT) html += "</tr><tr>";
    }
    return html;
  }

  function buildJVortexHtml(version, session, meta) {
    const name = session?.username ? escapeHtml(session.username) : "Guest";
    const userId = escapeHtml(session?.id ?? "???");
    const runs = Number(meta?.runs) || 0;
    const signalRuns = runs > 0 ? runs : 1;
    const visitorNum = String(800000 + signalRuns * 13 + Number(userId || 0)).slice(-7);

    return `
      <div class="vortex07-jvortex-shell">
        <div class="vortex07-jvortex-banner">
          <span class="vortex07-jvortex-blink">*** WELCOME 2 J.VORTEX ***</span>
          &nbsp;|&nbsp;
          <span class="vortex07-jvortex-rainbow">JOHN VORTEX FAN PAGE!!!</span>
        </div>

        <div class="vortex07-jvortex-marquee-wrap">
          <div class="vortex07-jvortex-marquee-track">
            ${Array.from({ length: 20 })
              .map(
                () =>
                  `<span class="vortex07-jvortex-marquee-bit"><span class="vortex07-jvortex-marquee-face">${avatarFallback("J")}</span> ITS HIM!!! ITS JOHN VORTEX!!!</span>`,
              )
              .join("")}
            ${Array.from({ length: 20 })
              .map(
                () =>
                  `<span class="vortex07-jvortex-marquee-bit"><span class="vortex07-jvortex-marquee-face">${avatarFallback("J")}</span> ITS HIM!!! ITS JOHN VORTEX!!!</span>`,
              )
              .join("")}
          </div>
        </div>

        <table class="vortex07-jvortex-layout" cellpadding="6" cellspacing="0" border="0" width="100%">
          <tr>
            <td class="vortex07-jvortex-side" width="110" valign="top">
              <div class="vortex07-jvortex-side-stack" id="vortex07-jvortexSideStack">
                <a href="${JOHN_VORTEX_PROFILE}" class="vortex07-jvortex-side-face vortex07-jvortex-side-face-lg" id="vortex07-jvortexSideA">${avatarFallback("J")}</a>
                <a href="${JOHN_VORTEX_PROFILE}" class="vortex07-jvortex-side-face" id="vortex07-jvortexSideB">${avatarFallback("J")}</a>
                <a href="${JOHN_VORTEX_PROFILE}" class="vortex07-jvortex-side-face vortex07-jvortex-side-face-sm" id="vortex07-jvortexSideC">${avatarFallback("J")}</a>
              </div>
              <p class="vortex07-jvortex-side-note">click him<br>click him<br>click him</p>
              <p class="vortex07-jvortex-counter">visitors:<br><b id="vortex07-jvortexCounter">${visitorNum}</b></p>
            </td>
            <td valign="top" class="vortex07-jvortex-main">
              <p class="vortex07-jvortex-h1">~~ J.VORTEX ~~</p>
              <p class="vortex07-jvortex-sub">hi ${name} (id ${userId}) u found the secret tab lol</p>
              <p class="vortex07-jvortex-sub vortex07-jvortex-blink">signal run #${signalRuns} · page under construction since 2006 probably</p>

              <div class="vortex07-jvortex-floatbox">
                <a class="vortex07-jvortex-hero-link" id="vortex07-jvortexHeroLink" href="${JOHN_VORTEX_PROFILE}">
                  <span class="vortex07-jvortex-hero-frame" id="vortex07-jvortexHeroAvatar">${avatarFallback("John")}</span>
                </a>
                <div class="vortex07-jvortex-floatcopy">
                  <p class="vortex07-jvortex-name" id="vortex07-jvortexHeroName">JOHN VORTEX</p>
                  <p class="vortex07-jvortex-meta">user #${JOHN_VORTEX_USER_ID}</p>
                  <p class="vortex07-jvortex-blurb" id="vortex07-jvortexHeroBlurb">fetching john from playvortex api plz wait........</p>
                  <a class="vortex07-jvortex-link" href="${JOHN_VORTEX_PROFILE}">&gt;&gt;&gt; GO 2 HIS PROFILE &lt;&lt;&lt;</a>
                </div>
              </div>

              <hr class="vortex07-jvortex-hr" />

              <p class="vortex07-jvortex-wtf vortex07-jvortex-blink">WHY SO MANY FACES?????</p>
              <table class="vortex07-jvortex-witness" id="vortex07-jvortexWitness" border="2" cellpadding="1" cellspacing="2" width="100%">
                <tr>${buildWitnessCells()}</tr>
              </table>

              <p class="vortex07-jvortex-fine">best viewed in internet explorer 6 @ 800x600<br>no copyright. all john.</p>

              <p class="vortex07-jvortex-status" id="vortex07-jvortexStatus">shhhhh dont tell anyone about /home#j-vortex</p>
            </td>
          </tr>
        </table>

        <div class="vortex07-jvortex-footer">
          <span>/home#j-vortex</span>
          <span id="vortex07-jvortexStatusRight">john john john john</span>
        </div>

        <div class="vortex07-jvortex-sticker vortex07-jvortex-sticker-a" id="vortex07-jvortexStickerA">${avatarFallback("J")}</div>
        <div class="vortex07-jvortex-sticker vortex07-jvortex-sticker-b" id="vortex07-jvortexStickerB">${avatarFallback("J")}</div>
        <div class="vortex07-jvortex-sticker vortex07-jvortex-sticker-c" id="vortex07-jvortexStickerC">${avatarFallback("J")}</div>
      </div>
    `;
  }

  async function fetchAvatarDirect() {
    try {
      const response = await fetch(
        `/api/users/avatar-pictures?ids=${JOHN_VORTEX_USER_ID}`,
        {
          credentials: "include",
          headers: { Accept: "application/json" },
        },
      );
      if (!response.ok) return "";
      return pickAvatarFromPayload(await response.json());
    } catch {
      return "";
    }
  }

  async function fetchUserDirect() {
    try {
      const response = await fetch(`/api/users/${JOHN_VORTEX_USER_ID}`, {
        credentials: "include",
        headers: { Accept: "application/json" },
      });
      if (!response.ok) return null;
      const data = await response.json();
      const user = data?.user || data?.data || data;
      return user && typeof user === "object" ? user : null;
    } catch {
      return null;
    }
  }

  async function loadJohnVortexProfile() {
    const api = global.Vortex07Api;
    let username = "John Vortex";
    let displayName = "John Vortex";
    let avatarUrl = "";

    if (api?.fetchPlayvortexUsersByIds) {
      try {
        const users = await api.fetchPlayvortexUsersByIds([JOHN_VORTEX_USER_ID], {
          force: true,
        });
        const player = users.get(JOHN_VORTEX_USER_ID);
        if (player) {
          username = player.username || username;
          displayName = player.displayName || player.username || displayName;
          avatarUrl = player.avatarUrl || "";
        }
      } catch {
        /* fall through */
      }
    }

    if (!avatarUrl && api?.fetchPlayerAvatars) {
      try {
        const avatars = await api.fetchPlayerAvatars([JOHN_VORTEX_USER_ID], {
          userInitiated: true,
        });
        avatarUrl = avatars.get(JOHN_VORTEX_USER_ID) || "";
      } catch {
        /* fall through */
      }
    }

    if (!avatarUrl) avatarUrl = await fetchAvatarDirect();

    if (username === "John Vortex") {
      const raw = await fetchUserDirect();
      if (raw) {
        username =
          String(raw.username || raw.name || raw.userName || username).trim() || username;
        displayName =
          String(raw.displayName || raw.display_name || raw.nickname || username).trim() ||
          username;
        if (!avatarUrl) avatarUrl = pickAvatarFromPayload(raw);
      }
    }

    return {
      id: JOHN_VORTEX_USER_ID,
      username,
      displayName,
      avatarUrl,
    };
  }

  function prefetchJohnVortex() {
    if (johnProfileCache) return Promise.resolve(johnProfileCache);
    if (!johnProfilePromise) {
      johnProfilePromise = loadJohnVortexProfile()
        .then((profile) => {
          johnProfileCache = profile;
          return profile;
        })
        .finally(() => {
          johnProfilePromise = null;
        });
    }
    return johnProfilePromise;
  }

  function paintSlot(slot, src, alt, imgClass, eager = false) {
    if (!slot) return;
    slot.innerHTML = imgTag(src, alt, imgClass, eager);
  }

  function hydrateJohnVortex(root, profile) {
    const src = profile?.avatarUrl || "";
    const name = profile?.displayName || profile?.username || "John Vortex";
    const username = profile?.username || "John Vortex";

    paintSlot(root.querySelector("#vortex07-jvortexHeroAvatar"), src, name, "vortex07-jvortex-hero-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexSideA"), src, name, "vortex07-jvortex-side-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexSideB"), src, name, "vortex07-jvortex-side-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexSideC"), src, name, "vortex07-jvortex-side-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexStickerA"), src, name, "vortex07-jvortex-sticker-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexStickerB"), src, name, "vortex07-jvortex-sticker-img", true);
    paintSlot(root.querySelector("#vortex07-jvortexStickerC"), src, name, "vortex07-jvortex-sticker-img", true);

    root.querySelectorAll(".vortex07-jvortex-marquee-face").forEach((slot) => {
      paintSlot(slot, src, name, "vortex07-jvortex-marquee-img");
    });

    root.querySelectorAll(".vortex07-jvortex-witness-cell a").forEach((link) => {
      paintSlot(link, src, name, "vortex07-jvortex-witness-img");
    });

    const heroName = root.querySelector("#vortex07-jvortexHeroName");
    if (heroName) heroName.textContent = username.toUpperCase();

    const blurb = root.querySelector("#vortex07-jvortexHeroBlurb");
    if (blurb) {
      blurb.innerHTML = `ok so thats <b>${escapeHtml(username)}</b>. user #${JOHN_VORTEX_USER_ID}. the grey logo thing was ALWAYS about this guy. there r like ${WITNESS_COUNT + 8} pictures of him on this page. why. idk.`;
    }

    const statusRight = root.querySelector("#vortex07-jvortexStatusRight");
    if (statusRight) statusRight.textContent = `${username} x ${WITNESS_COUNT + 8} !!!`;

    applyJohnToNavTabs(profile);
  }

  async function hydrateJohnVortexFromApi(root) {
    const blurb = root.querySelector("#vortex07-jvortexHeroBlurb");
    try {
      const profile = await prefetchJohnVortex();
      if (!profile?.avatarUrl) {
        if (blurb) blurb.textContent = "api didnt give a pic but hes still user #90 go look";
      }
      hydrateJohnVortex(root, profile);
    } catch {
      if (blurb) blurb.textContent = "api broke. john vortex is still at /users/90/profile tho";
    }
  }

  function applyJohnToNavTabs(profile) {
    const src = safeSrc(profile?.avatarUrl);
    document.querySelectorAll(".vortex07-hidden-signal-tab").forEach((btn) => {
      const faceHtml = src
        ? `<img class="vortex07-jvortex-tab-face" src="${escapeHtml(src)}" alt="" />`
        : `<span class="vortex07-jvortex-tab-face vortex07-jvortex-tab-face-empty">J</span>`;
      btn.innerHTML = `<span class="vortex07-jvortex-tab-inner">${faceHtml}<span class="vortex07-jvortex-tab-label">J.Vortex</span></span>`;
    });
  }

  function wireJVortexPage(root) {
    if (!root || root.dataset.vortex07JvortexWired === "true") return;
    root.dataset.vortex07JvortexWired = "true";

    if (johnProfileCache) hydrateJohnVortex(root, johnProfileCache);
    void hydrateJohnVortexFromApi(root);
  }

  function mountJVortexPage(root, version, session, meta) {
    root.innerHTML = buildJVortexHtml(version, session, meta);
    delete root.dataset.vortex07JvortexWired;
    wireJVortexPage(root);
  }

  function buildJohnSpamFloat(index) {
    const left = (index * 19 + 5) % 94;
    const top = (index * 27 + 11) % 90;
    const size = 28 + (index % 6) * 16;
    const rotate = (index % 9) * 14 - 56;
    const delay = (index % 12) * 0.31;
    const duration = 3.6 + (index % 5) * 0.8;

    const el = document.createElement("div");
    el.className = "vortex07-john-spam-float";
    el.style.left = `${left}%`;
    el.style.top = `${top}%`;
    el.style.width = `${size}px`;
    el.style.height = `${size}px`;
    el.style.setProperty("--vortex07-john-rot", `${rotate}deg`);
    el.style.animationDelay = `${delay}s`;
    el.style.animationDuration = `${duration}s`;
    el.innerHTML = `<img alt="" />`;
    return el;
  }

  function buildJohnSpamBannerBits(count = 24) {
    return Array.from({ length: count })
      .map(
        () =>
          `<span class="vortex07-john-spam-banner-bit"><span class="vortex07-john-spam-banner-face">${avatarFallback("J")}</span> JOHN VORTEX</span>`,
      )
      .join("");
  }

  function ensureJohnSpamRoot() {
    let root = document.getElementById("vortex07-john-spam-root");
    if (root) return root;

    root = document.createElement("div");
    root.id = "vortex07-john-spam-root";
    root.className = "vortex07-john-spam-root";
    root.setAttribute("aria-hidden", "true");
    root.innerHTML = `
      <div class="vortex07-john-spam-tile"></div>
      <div class="vortex07-john-spam-floats" id="vortex07-john-spam-floats"></div>
      <div class="vortex07-john-spam-banner">
        <div class="vortex07-john-spam-banner-track">
          ${buildJohnSpamBannerBits(24)}
          ${buildJohnSpamBannerBits(24)}
        </div>
      </div>
    `;

    const floats = root.querySelector("#vortex07-john-spam-floats");
    for (let i = 0; i < JOHN_SPAM_FLOATS; i += 1) {
      floats?.appendChild(buildJohnSpamFloat(i));
    }

    const container = document.getElementById("Container") || document.body;
    container.appendChild(root);
    return root;
  }

  function clearJohnThemeDom() {
    document.getElementById("vortex07-john-spam-root")?.remove();
    document.querySelectorAll(".vortex07-john-header-stamp").forEach((el) => el.remove());
    document.querySelector(".vortex07-john-logo-ring")?.remove();
    document.documentElement.classList.remove("vortex07-john-has-avatar");
    document.documentElement.style.removeProperty("--vortex07-john-avatar-url");
  }

  function paintJohnSpam(profile) {
    const src = safeSrc(profile?.avatarUrl);
    const name = profile?.displayName || profile?.username || "John Vortex";
    const root = document.getElementById("vortex07-john-spam-root");
    if (!root) return;

    if (src) {
      document.documentElement.style.setProperty("--vortex07-john-avatar-url", `url("${src.replace(/"/g, '\\"')}")`);
      document.documentElement.classList.add("vortex07-john-has-avatar");
    }

    root.querySelectorAll(".vortex07-john-spam-float img").forEach((img) => {
      if (src) {
        img.src = src;
        img.alt = name;
      }
    });

    root.querySelectorAll(".vortex07-john-spam-banner-face").forEach((slot) => {
      paintSlot(slot, src, name, "vortex07-john-spam-banner-img");
    });

    document.querySelectorAll(".vortex07-john-header-stamp").forEach((el) => el.remove());
    const headers = document.querySelectorAll("#Body .section-header, #Body .vortex07-settings-titlebar");
    headers.forEach((header, index) => {
      if (index >= JOHN_HEADER_STAMPS || !src) return;
      const stamp = document.createElement("a");
      stamp.href = JOHN_VORTEX_PROFILE;
      stamp.className = "vortex07-john-header-stamp";
      stamp.title = name;
      stamp.style.setProperty("--vortex07-john-stamp-rot", `${(index % 5) * 12 - 24}deg`);
      stamp.innerHTML = `<img src="${escapeHtml(src)}" alt="" />`;
      header.appendChild(stamp);
    });

    const logo = document.getElementById("Logo");
    logo?.querySelector(".vortex07-john-logo-ring")?.remove();
    if (logo && src) {
      const ring = document.createElement("div");
      ring.className = "vortex07-john-logo-ring";
      ring.innerHTML = Array.from({ length: JOHN_LOGO_ORBITS })
        .map(
          (_, i) =>
            `<a class="vortex07-john-logo-orbit" style="--vortex07-john-orbit-i:${i}" href="${JOHN_VORTEX_PROFILE}"><img src="${escapeHtml(src)}" alt="" /></a>`,
        )
        .join("");
      logo.appendChild(ring);
    }

    applyJohnToNavTabs(profile);
  }

  function syncJohnThemeEffects(active) {
    if (!active) {
      clearJohnThemeDom();
      return;
    }

    ensureJohnSpamRoot();
    if (johnProfileCache) paintJohnSpam(johnProfileCache);
    void prefetchJohnVortex().then((profile) => {
      if (!document.documentElement.classList.contains("vortex07-john-theme")) return;
      paintJohnSpam(profile);
    });
  }

  function refreshJohnThemeSpam() {
    if (!document.documentElement.classList.contains("vortex07-john-theme")) return;
    if (!document.getElementById("vortex07-john-spam-root")) {
      syncJohnThemeEffects(true);
      return;
    }
    if (johnProfileCache) paintJohnSpam(johnProfileCache);
    else void prefetchJohnVortex().then((profile) => paintJohnSpam(profile));
  }

  global.Vortex07JVortexUi = {
    mountJVortexPage,
    prefetchJohnVortex,
    applyJohnToNavTabs,
    syncJohnThemeEffects,
    refreshJohnThemeSpam,
    JOHN_VORTEX_USER_ID,
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
