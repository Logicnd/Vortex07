#!/usr/bin/env node
/**
 * Local dev server for Vortex07 UI previews.
 * - CSS live reload (no extension reload needed for styling)
 * - Serves extension assets from repo root
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const PORT = Number(process.env.PORT || 5173);
const HOST = process.env.HOST || "127.0.0.1";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

const WATCH_DIRS = [
  path.join(ROOT, "src", "styles"),
  path.join(ROOT, "src", "popup"),
];

/** @type {Set<import("node:http").ServerResponse>} */
const livereloadClients = new Set();

function safePath(urlPath) {
  const decoded = decodeURIComponent(urlPath.split("?")[0]);
  const rel = decoded.replace(/^\/+/, "") || "dev/preview.html";
  const abs = path.normalize(path.join(ROOT, rel));
  if (!abs.startsWith(ROOT)) return null;
  return abs;
}

function broadcastReload() {
  const payload = "data: reload\n\n";
  for (const res of livereloadClients) {
    try {
      res.write(payload);
    } catch {
      livereloadClients.delete(res);
    }
  }
}

function watchCss() {
  for (const dir of WATCH_DIRS) {
    if (!fs.existsSync(dir)) continue;
    fs.watch(dir, { recursive: true }, (_event, filename) => {
      if (!filename || !String(filename).endsWith(".css")) return;
      console.log(`[dev] CSS changed: ${filename}`);
      broadcastReload();
    });
  }
}

function openBrowser(url) {
  if (process.env.NO_OPEN) return;
  const platform = process.platform;
  if (platform === "win32") {
    spawn("cmd", ["/c", "start", "", url], { stdio: "ignore", detached: true }).unref();
    return;
  }
  const cmd = platform === "darwin" ? "open" : "xdg-open";
  spawn(cmd, [url], { stdio: "ignore", detached: true }).unref();
}

const server = http.createServer((req, res) => {
  const url = req.url || "/";

  if (url === "/__livereload") {
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });
    res.write("data: connected\n\n");
    livereloadClients.add(res);
    req.on("close", () => livereloadClients.delete(res));
    return;
  }

  const filePath = safePath(url === "/" ? "/dev/preview.html" : url);
  if (!filePath) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(err.code === "ENOENT" ? 404 : 500);
      res.end(err.code === "ENOENT" ? "Not found" : "Server error");
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      "Content-Type": MIME[ext] || "application/octet-stream",
      "Cache-Control": ext === ".css" ? "no-cache" : "public, max-age=60",
    });
    res.end(data);
  });
});

server.listen(PORT, HOST, () => {
  const base = `http://${HOST}:${PORT}`;
  console.log("");
  console.log("  Vortex07 dev server");
  console.log("  ───────────────────");
  console.log(`  Shell preview (CSS live reload): ${base}/dev/preview.html`);
  console.log(`  Popup preview:                   ${base}/dev/popup-preview.html`);
  console.log(`  Extension fixture (load unpacked + visit): ${base}/dev/fixture.html`);
  console.log("");
  console.log("  For JS/API work: keep extension loaded on https://playvortex.io");
  console.log("  Reload extension after .js changes (chrome://extensions → Reload)");
  console.log("");
  watchCss();
  openBrowser(`${base}/dev/preview.html`);
});
