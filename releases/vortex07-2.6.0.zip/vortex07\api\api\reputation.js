import { applyCors, handleOptions } from "../lib/http.js";
import {
  enforceRateLimit,
  enforceVoteRateLimits,
  getClientIp,
} from "../lib/rate-limit.js";
import {
  addVote,
  getBatchReputation,
  getCount,
  hasPersistentStore,
  hasVoted,
  isValidVoterId,
  parseNumericIds,
  removeVote,
  resolveVoterKey,
} from "../lib/reputation-store.js";
import { verifyTurnstileToken } from "../lib/turnstile.js";
import {
  actorStorageKey,
  parseActorUserId,
  verifyVoteSignature,
} from "../lib/vote-auth.js";

export default async function handler(req, res) {
  applyCors(res, req);
  if (handleOptions(req, res)) return;

  const userId = String(req.query?.userId || req.body?.userId || "").trim();
  const voterId = String(req.query?.voterId || req.body?.voterId || "").trim();
  const actorUserId = parseActorUserId(
    req.query?.actorUserId || req.body?.actorUserId,
  );
  const idsParam = String(req.query?.ids || "").trim();
  const voterKey = resolveVoterKey({ actorUserId, voterId });

  // ── Batch GET ──────────────────────────────────────────────────────────────
  if (req.method === "GET" && idsParam) {
    if (
      !(await enforceRateLimit(req, res, {
        route: "reputation-batch",
        limit: 90,
        windowSec: 60,
        voterId: voterKey || voterId,
        voterLimit: 45,
      }))
    ) {
      return;
    }
    if (!voterKey && !isValidVoterId(voterId)) {
      res.status(400).json({ error: "Invalid voterId or actorUserId" });
      return;
    }

    const ids = parseNumericIds(idsParam);
    const results = await getBatchReputation(ids, voterKey || voterId);

    res.status(200).json({ results, persistent: hasPersistentStore() });
    return;
  }

  if (!/^\d+$/.test(userId)) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  // ── Single GET ─────────────────────────────────────────────────────────────
  if (req.method === "GET") {
    if (
      !(await enforceRateLimit(req, res, {
        route: "reputation-get",
        limit: 120,
        windowSec: 60,
        voterId: voterKey || voterId,
        voterLimit: 60,
      }))
    ) {
      return;
    }

    if (!voterKey && !isValidVoterId(voterId)) {
      res.status(400).json({ error: "Invalid voterId or actorUserId" });
      return;
    }

    const count = await getCount(userId);
    const voted = voterKey
      ? await hasVoted(userId, voterKey)
      : voterId
        ? await hasVoted(userId, voterId)
        : false;
    res
      .status(200)
      .json({ count, hasVoted: voted, persistent: hasPersistentStore() });
    return;
  }

  // ── Vote (POST / DELETE) ───────────────────────────────────────────────────
  const isVoteMethod = req.method === "POST" || req.method === "DELETE";

  if (isVoteMethod) {
    if (!actorUserId) {
      res.status(400).json({ error: "actorUserId required" });
      return;
    }

    if (actorUserId === userId) {
      res.status(403).json({ error: "Cannot rep yourself" });
      return;
    }

    const signatureCheck = verifyVoteSignature(req, actorUserId, userId);
    if (!signatureCheck.ok) {
      res.status(403).json({ error: signatureCheck.error || "Forbidden" });
      return;
    }

    // Turnstile CAPTCHA verification (only on POST add-votes, not removals)
    const action = String(req.body?.action || req.query?.action || "add").trim();
    const isAddVote = req.method === "POST" && action !== "remove";

    if (isAddVote) {
      const captchaToken = String(
        req.headers?.["x-turnstile-token"] ||
          req.headers?.["X-Turnstile-Token"] ||
          req.body?.turnstileToken ||
          "",
      ).trim();
      const ip = getClientIp(req);
      const captchaResult = await verifyTurnstileToken(captchaToken, ip);
      if (!captchaResult.success) {
        res.status(403).json({
          error: "CAPTCHA verification failed",
          code: captchaResult.error || "captcha_failed",
        });
        return;
      }
    }

    if (!(await enforceVoteRateLimits(req, res, actorUserId))) {
      return;
    }

    const storageKey = actorStorageKey(actorUserId);
    const auditContext = {
      actorUserId,
      ip: getClientIp(req),
    };

    if (req.method === "POST") {
      if (action === "remove") {
        const result = await removeVote(userId, storageKey, auditContext);
        res.status(200).json({
          count: result.count,
          hasVoted: false,
          removed: result.removed,
          persistent: hasPersistentStore(),
        });
        return;
      }

      const result = await addVote(userId, storageKey, auditContext);
      res.status(200).json({
        count: result.count,
        hasVoted: true,
        added: result.added,
        persistent: hasPersistentStore(),
      });
      return;
    }

    // DELETE → remove vote
    const result = await removeVote(userId, storageKey, auditContext);
    res.status(200).json({
      count: result.count,
      hasVoted: false,
      removed: result.removed,
      persistent: hasPersistentStore(),
    });
    return;
  }

  res.status(405).json({ error: "Method not allowed" });
}
