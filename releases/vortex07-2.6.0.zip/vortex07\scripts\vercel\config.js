/**
 * Vortex07 Vercel automation — shared config + auth helpers.
 */
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const REPO_ROOT = path.resolve(__dirname, "../..");
const API_DIR = path.join(REPO_ROOT, "api");

const PROJECT = {
  id: "prj_TKYjCjvpOsorUw9BlaYtxFUIaw13",
  name: "vortex07",
  teamId: "team_9MqWsNU886SwQfKDeqKiU1Kk",
  rootDirectory: "api",
  productionUrl: "https://vortex07.vercel.app",
};

function resolveVercelToken() {
  if (process.env.VERCEL_TOKEN) return process.env.VERCEL_TOKEN.trim();

  const candidates = [
    path.join(process.env.APPDATA || "", "Roaming", "com.vercel.cli", "auth.json"),
    path.join(process.env.APPDATA || "", "xdg.data", "com.vercel.cli", "auth.json"),
    path.join(process.env.HOME || "", ".local", "share", "com.vercel.cli", "auth.json"),
    path.join(process.env.HOME || "", ".vercel", "auth.json"),
    path.join(process.env.USERPROFILE || "", ".vercel", "auth.json"),
  ].filter(Boolean);

  for (const file of candidates) {
    try {
      if (!fs.existsSync(file)) continue;
      const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
      if (parsed?.token) return parsed.token;
    } catch {
      /* try next */
    }
  }

  return null;
}

async function vercelFetch(pathname, options = {}) {
  const token = resolveVercelToken();
  if (!token) {
    throw new Error(
      "No Vercel token. Run `vercel login` or set VERCEL_TOKEN in .env",
    );
  }

  const url = pathname.startsWith("http")
    ? pathname
    : `https://api.vercel.com${pathname}`;

  const response = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  const text = await response.text();
  let body;
  try {
    body = text ? JSON.parse(text) : {};
  } catch {
    body = { raw: text };
  }

  if (!response.ok) {
    const message =
      body?.error?.message || body?.message || `HTTP ${response.status}`;
    throw new Error(message);
  }

  return body;
}

async function ensureProjectRootDirectory() {
  const query = `?teamId=${encodeURIComponent(PROJECT.teamId)}`;
  const current = await vercelFetch(`/v9/projects/${PROJECT.id}${query}`);
  if (current.rootDirectory === PROJECT.rootDirectory) {
    return { changed: false, rootDirectory: current.rootDirectory };
  }

  const updated = await vercelFetch(`/v9/projects/${PROJECT.id}${query}`, {
    method: "PATCH",
    body: JSON.stringify({ rootDirectory: PROJECT.rootDirectory }),
  });

  return {
    changed: true,
    rootDirectory: updated.rootDirectory || PROJECT.rootDirectory,
  };
}

function spawnCommand(command, args, options = {}) {
  const cwd = options.cwd || REPO_ROOT;
  const env = {
    ...process.env,
    NODE_OPTIONS: process.env.NODE_OPTIONS || "--use-system-ca",
  };

  const useCmdShim =
    process.platform === "win32" &&
    (command === "npm" ||
      command === "npx" ||
      String(command).toLowerCase().endsWith(".cmd") ||
      String(command).toLowerCase().endsWith(".bat"));

  if (useCmdShim) {
    return spawnSync("cmd.exe", ["/d", "/s", "/c", command, ...args], {
      cwd,
      stdio: options.stdio ?? "inherit",
      input: options.input,
      encoding: options.encoding,
      env,
    });
  }

  return spawnSync(command, args, {
    cwd,
    stdio: options.stdio ?? "inherit",
    input: options.input,
    shell: options.shell ?? false,
    encoding: options.encoding,
    env,
  });
}

function run(command, args, options = {}) {
  const stdio = options.input !== undefined ? ["pipe", "inherit", "inherit"] : "inherit";
  const result = spawnCommand(command, args, { ...options, stdio });

  if (result.error) {
    throw new Error(`${command} ${args.join(" ")} failed: ${result.error.message}`);
  }

  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(" ")} failed (${result.status})`);
  }
}

function runCapture(command, args, options = {}) {
  const result = spawnCommand(command, args, {
    ...options,
    stdio: ["pipe", "pipe", "pipe"],
    encoding: "utf8",
  });

  if (result.error) {
    throw new Error(`${command} ${args.join(" ")} failed: ${result.error.message}`);
  }

  return {
    status: result.status,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
  };
}

function ensureNoBomJson(filePath) {
  if (!fs.existsSync(filePath)) return;
  const raw = fs.readFileSync(filePath);
  if (raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf) {
    fs.writeFileSync(filePath, raw.slice(3));
  }
}

function ensureApiLinked() {
  const vercelDir = path.join(REPO_ROOT, ".vercel");
  const projectFile = path.join(vercelDir, "project.json");
  fs.mkdirSync(vercelDir, { recursive: true });
  fs.writeFileSync(
    projectFile,
    `${JSON.stringify(
      {
        projectId: PROJECT.id,
        orgId: PROJECT.teamId,
        projectName: PROJECT.name,
        settings: { rootDirectory: PROJECT.rootDirectory },
      },
      null,
      2,
    )}\n`,
    "utf8",
  );
}

function npmInstallApi() {
  ensureNoBomJson(path.join(API_DIR, "package.json"));
  ensureNoBomJson(path.join(API_DIR, "vercel.json"));
  run("npm", ["install"], { cwd: API_DIR });
}

function vercelCommand() {
  const globalWin = path.join(process.env.APPDATA || "", "npm", "vercel.cmd");
  if (process.platform === "win32" && fs.existsSync(globalWin)) {
    return { command: globalWin, argsPrefix: [] };
  }

  const globalUnix = path.join(process.env.HOME || "", ".npm-global", "bin", "vercel");
  if (process.platform !== "win32" && fs.existsSync(globalUnix)) {
    return { command: globalUnix, argsPrefix: [] };
  }

  const vercelBin =
    process.platform === "win32"
      ? path.join(REPO_ROOT, "node_modules", ".bin", "vercel.cmd")
      : path.join(REPO_ROOT, "node_modules", ".bin", "vercel");

  if (fs.existsSync(vercelBin)) {
    return { command: vercelBin, argsPrefix: [] };
  }

  return { command: "npx", argsPrefix: ["--yes", "vercel"] };
}

function deployProduction() {
  const { command, argsPrefix } = vercelCommand();
  run(command, [...argsPrefix, "deploy", "--prod", "--yes"], { cwd: REPO_ROOT });
}

module.exports = {
  REPO_ROOT,
  API_DIR,
  PROJECT,
  resolveVercelToken,
  vercelFetch,
  ensureProjectRootDirectory,
  ensureApiLinked,
  npmInstallApi,
  deployProduction,
  vercelCommand,
  run,
  runCapture,
};
