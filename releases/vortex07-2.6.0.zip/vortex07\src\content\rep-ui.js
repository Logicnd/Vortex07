// Vortex07 rep-ui.js — Banned-status detection, badge rendering, reputation system.
// Shares scope with content.js.

// Set to your Cloudflare Turnstile Site Key (public) to enable CAPTCHA on votes.
// Leave empty to disable — the server also gracefully skips if TURNSTILE_SECRET_KEY
// is not configured. Both must be set together when enabling.
const VORTEX07_TURNSTILE_SITE_KEY = "";

const TURNSTILE_CDN =
  "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";

let turnstileScriptLoading = null;

async function loadTurnstileScript() {
  if (window.turnstile) return;
  if (turnstileScriptLoading) return turnstileScriptLoading;

  // Check if another part of the page already started loading it.
  if (document.querySelector(`script[src*="challenges.cloudflare.com/turnstile"]`)) {
    turnstileScriptLoading = new Promise((resolve) => {
      let attempts = 0;
      const poll = setInterval(() => {
        if (window.turnstile) { clearInterval(poll); resolve(); return; }
        if (++attempts > 60) { clearInterval(poll); resolve(); }
      }, 100);
    });
    return turnstileScriptLoading;
  }

  turnstileScriptLoading = new Promise((resolve) => {
    const script = document.createElement("script");
    script.src = TURNSTILE_CDN;
    script.async = true;
    script.onload = resolve;
    script.onerror = resolve; // Fail open — don't block voting on CDN errors
    (document.head || document.documentElement).appendChild(script);
  });
  return turnstileScriptLoading;
}

async function getTurnstileToken() {
  if (!VORTEX07_TURNSTILE_SITE_KEY) return "";

  try {
    await loadTurnstileScript();
    if (!window.turnstile?.render) return "";

    // Off-screen container — never visible to the user
    const container = document.createElement("div");
    container.style.cssText =
      "position:fixed;left:-9999px;top:-9999px;width:0;height:0;overflow:hidden;pointer-events:none";
    document.body.appendChild(container);

    const token = await new Promise((resolve) => {
      window.turnstile.render(container, {
        sitekey: VORTEX07_TURNSTILE_SITE_KEY,
        action: "rep-vote",
        size: "invisible",
        callback: resolve,
        "error-callback": () => resolve(""), // Fail open
        "expired-callback": () => resolve(""),
        "timeout-callback": () => resolve(""),
      });
    });

    container.remove();
    return token || "";
  } catch {
    return ""; // Fail open — CAPTCHA errors never block voting
  }
}

/* ========================================================= */
/* ================= BANNED DETECTION ====================== */
/* ========================================================= */

function readBooleanLike(value) {
  if (value === true) return true;
  if (value === false) return false;

  const text = safeLower(value);
  return [
    "true",
    "yes",
    "1",
    "banned",
    "terminated",
    "deleted",
    "restricted",
    "disabled",
    "suspended",
  ].includes(text);
}

function detectBannedStatus(rawPlayer) {
  const result = { isBanned: false, detectedBy: "", rawValue: null };
  if (!rawPlayer || typeof rawPlayer !== "object") return result;

  const directFields = [
    "isBanned",
    "banned",
    "is_banned",
    "isTerminated",
    "terminated",
    "is_terminated",
    "deleted",
    "isDeleted",
    "is_deleted",
    "restricted",
    "isRestricted",
    "is_restricted",
    "disabled",
    "isDisabled",
    "is_disabled",
    "suspended",
    "isSuspended",
    "is_suspended",
  ];

  for (const field of directFields) {
    if (Object.prototype.hasOwnProperty.call(rawPlayer, field)) {
      const value = rawPlayer[field];
      if (readBooleanLike(value)) {
        result.isBanned = true;
        result.detectedBy = field;
        result.rawValue = value;
        return result;
      }
    }
  }

  const statusFields = [
    "status",
    "accountStatus",
    "account_status",
    "moderationStatus",
    "moderation_status",
    "state",
  ];
  const bannedWords = [
    "banned",
    "ban",
    "terminated",
    "deleted",
    "restricted",
    "disabled",
    "moderated",
    "suspended",
  ];

  for (const field of statusFields) {
    if (Object.prototype.hasOwnProperty.call(rawPlayer, field)) {
      const value = rawPlayer[field];
      const text = safeLower(value);
      if (bannedWords.some((word) => text.includes(word))) {
        result.isBanned = true;
        result.detectedBy = field;
        result.rawValue = value;
        return result;
      }
    }
  }

  return result;
}

function logBannedCandidate(rawPlayer, normalizedPlayer, detection) {
  if (!currentSettings.debugLogs) return;

  const id =
    normalizedPlayer?.id ??
    rawPlayer?.id ??
    rawPlayer?.userId ??
    rawPlayer?.user_id ??
    "unknown";
  const username =
    normalizedPlayer?.username ??
    rawPlayer?.username ??
    rawPlayer?.name ??
    "unknown";

  if (detection?.isBanned) {
    logBanned("Detected banned user:", {
      id,
      username,
      detectedBy: detection.detectedBy,
      rawValue: detection.rawValue,
      normalized: normalizedPlayer,
      raw: rawPlayer,
    });
    return;
  }

  const visibleSignals = {};
  [
    "isBanned",
    "banned",
    "terminated",
    "deleted",
    "restricted",
    "disabled",
    "suspended",
    "status",
    "accountStatus",
    "moderationStatus",
    "state",
  ].forEach((key) => {
    if (Object.prototype.hasOwnProperty.call(rawPlayer || {}, key))
      visibleSignals[key] = rawPlayer[key];
  });

  if (Object.keys(visibleSignals).length > 0) {
    logBanned("Ban-related fields found but user was not marked banned:", {
      id,
      username,
      fields: visibleSignals,
    });
  }
}

/* ========================================================= */
/* ================= REPUTATION ============================ */
/* Extension-only thumbs-up reputation — blocky 2007 UI.     */
/* ========================================================= */

function repThumbUpSvg(size = 14) {
  return `<svg class="vortex07-rep-svg vortex07-rep-svg-up" viewBox="0 0 16 16" width="${size}" height="${size}" aria-hidden="true" focusable="false"><path class="vortex07-rep-svg-fill" d="M3 6.5h2.4V4.2c0-1.1.9-2 2.1-2s2.1.9 2.1 2v2.3H13c.6 0 1 .4 1 1v.6c0 1.7-.9 3.2-2.2 4.1L11.2 15H2V6.5h1z"/><path class="vortex07-rep-svg-stroke" d="M3 6.5h2.4V4.2c0-1.1.9-2 2.1-2s2.1.9 2.1 2v2.3H13c.6 0 1 .4 1 1v.6c0 1.7-.9 3.2-2.2 4.1L11.2 15H2V6.5h1z"/></svg>`;
}

function repThumbDownSvg(size = 14) {
  return `<svg class="vortex07-rep-svg vortex07-rep-svg-down" viewBox="0 0 16 16" width="${size}" height="${size}" aria-hidden="true" focusable="false"><path class="vortex07-rep-svg-fill" d="M3 9.5h2.4v2.3c0 1.1.9 2 2.1 2s2.1-.9 2.1-2V9.5H13c.6 0 1-.4 1-1v-.6c0-1.7-.9-3.2-2.2-4.1L11.2 1H2v8.5h1z"/><path class="vortex07-rep-svg-stroke" d="M3 9.5h2.4v2.3c0 1.1.9 2 2.1 2s2.1-.9 2.1-2V9.5H13c.6 0 1-.4 1-1v-.6c0-1.7-.9-3.2-2.2-4.1L11.2 1H2v8.5h1z"/></svg>`;
}

function isVortex07Developer(userId) {
  const id = Number(userId);
  return Number.isFinite(id) && VORTEX07_DEVELOPER_IDS.has(id);
}

function isTheHaloDeveloper(userId) {
  return safeNumber(userId) === VORTEX07_HALO_DEVELOPER_ID;
}

function applyAvatarFrameClasses(wrap, userId) {
  if (!wrap) return;
  const id = safeNumber(userId);
  if (id === null) return;

  wrap.classList.toggle("vortex07-dev-avatar-frame", isVortex07Developer(id));
  wrap.classList.toggle(
    "vortex07-rainbow-avatar-frame",
    isTheHaloDeveloper(id),
  );
}

function readOnlineStatus(rawPlayer) {
  if (!rawPlayer || typeof rawPlayer !== "object") return "";

  if (
    readBooleanLike(
      rawPlayer.isInGame ??
        rawPlayer.inGame ??
        rawPlayer.in_game ??
        rawPlayer.is_in_game,
    )
  ) {
    return "in-game";
  }

  if (
    readBooleanLike(
      rawPlayer.isOnline ?? rawPlayer.online ?? rawPlayer.is_online,
    )
  ) {
    return "online";
  }

  const status = safeLower(
    rawPlayer.status ??
      rawPlayer.presence ??
      rawPlayer.onlineStatus ??
      rawPlayer.online_status,
  );

  if (status.includes("in-game") || status.includes("ingame")) return "in-game";
  if (status.includes("online")) return "online";
  if (status.includes("offline")) return "offline";

  if (rawPlayer.isOnline === false || rawPlayer.online === false) {
    return "offline";
  }

  return "";
}

function readRoleBoolean(value) {
  if (value === true) return true;
  if (value === false || value === null || value === undefined) return false;
  if (typeof value === "number") return value > 0;
  if (typeof value === "string") {
    const text = value.trim().toLowerCase();
    if (["false", "no", "0", "off", "none", ""].includes(text)) return false;
    if (["true", "yes", "1", "on"].includes(text)) return true;
    if (/boost|nitro|premium/.test(text)) return true;
  }
  return readBooleanLike(value);
}

function readBoosterFromBadgesList(rawPlayer) {
  const lists = [
    rawPlayer?.badges,
    rawPlayer?.user_badges,
    rawPlayer?.role_badges,
  ];

  for (const list of lists) {
    if (!Array.isArray(list)) continue;
    if (
      list.some((entry) => {
        const text = safeLower(entry);
        return (
          text.includes("booster") ||
          text.includes("server_booster") ||
          text.includes("server-booster") ||
          text === "boost"
        );
      })
    ) {
      return true;
    }
  }

  return false;
}

const PLAYER_ROLE_SIGNAL_KEYS = [
  "is_booster",
  "isBooster",
  "is_staff",
  "isStaff",
  "is_moderator",
  "isModerator",
  "booster",
  "staff",
  "moderator",
  "badges",
  "user_badges",
  "role_badges",
  "roles",
];

function playerPayloadHasRoleSignals(rawPlayer) {
  if (!rawPlayer || typeof rawPlayer !== "object") return false;
  if (rawPlayer.roles && typeof rawPlayer.roles === "object") return true;
  return PLAYER_ROLE_SIGNAL_KEYS.some((key) =>
    Object.prototype.hasOwnProperty.call(rawPlayer, key),
  );
}

function extractUserEntriesFromPayload(payload) {
  if (!payload) return [];
  if (Array.isArray(payload)) {
    return payload.filter((entry) => entry && typeof entry === "object");
  }
  if (typeof payload !== "object") return [];

  for (const key of ["users", "results", "friends", "data", "items"]) {
    const nested = payload[key];
    if (Array.isArray(nested)) {
      return nested.filter((entry) => entry && typeof entry === "object");
    }
  }

  return [payload];
}

function readPlayerRoles(rawPlayer) {
  if (!rawPlayer || typeof rawPlayer !== "object") {
    return { isStaff: false, isModerator: false, isBooster: false };
  }

  const nested =
    rawPlayer.roles && typeof rawPlayer.roles === "object" ?
      rawPlayer.roles
    : null;

  const isModerator = readRoleBoolean(
      rawPlayer.isModerator ??
        rawPlayer.moderator ??
        rawPlayer.is_moderator ??
        nested?.isModerator ??
        nested?.moderator ??
        nested?.is_moderator,
    );
  const isStaff =
    readRoleBoolean(
      rawPlayer.isStaff ??
        rawPlayer.staff ??
        rawPlayer.is_staff ??
        nested?.isStaff ??
        nested?.staff ??
        nested?.is_staff,
    ) || isModerator;

  return {
    isStaff,
    isModerator,
    isBooster:
      readRoleBoolean(
        rawPlayer.isBooster ??
          rawPlayer.booster ??
          rawPlayer.is_booster ??
          rawPlayer.isServerBooster ??
          rawPlayer.is_server_booster ??
          rawPlayer.server_booster ??
          rawPlayer.serverBooster ??
          rawPlayer.has_booster ??
          rawPlayer.hasBooster ??
          nested?.isBooster ??
          nested?.booster ??
          nested?.is_booster ??
          nested?.is_server_booster ??
          nested?.server_booster,
      ) || readBoosterFromBadgesList(rawPlayer),
  };
}

async function loadKnownBoosterIds() {
  if (knownBoosterIdsLoaded) return;
  knownBoosterIdsLoaded = true;

  try {
    const data = await storageGet("local", { [VORTEX07_BOOSTER_IDS_KEY]: [] });
    const list = data[VORTEX07_BOOSTER_IDS_KEY];
    if (!Array.isArray(list)) return;

    list.forEach((entry) => {
      const id = safeNumber(entry);
      if (id !== null) knownBoosterIds.add(id);
    });
  } catch (err) {
    logWarn("Failed to load booster ID cache:", err);
  }
}

async function persistKnownBoosterId(userId) {
  const id = safeNumber(userId);
  if (id === null || knownBoosterIds.has(id)) return;

  knownBoosterIds.add(id);
  try {
    await storageSet("local", {
      [VORTEX07_BOOSTER_IDS_KEY]: [...knownBoosterIds],
    });
  } catch (err) {
    logWarn("Failed to persist booster ID cache:", err);
  }
}

async function removeKnownBoosterId(userId) {
  const id = safeNumber(userId);
  if (id === null || !knownBoosterIds.has(id)) return;

  knownBoosterIds.delete(id);
  try {
    await storageSet("local", {
      [VORTEX07_BOOSTER_IDS_KEY]: [...knownBoosterIds],
    });
  } catch (err) {
    logWarn("Failed to update booster ID cache:", err);
  }
}

function applyKnownBoosterIdsToRoles(userId, roles = null) {
  const id = safeNumber(userId);
  if (id === null || !knownBoosterIds.has(id)) return roles;

  if (roles?.isBooster === false) {
    void removeKnownBoosterId(id);
    return roles;
  }

  return mergePlayerRoles(roles, {
    isStaff: false,
    isModerator: false,
    isBooster: true,
  });
}

function resolvePlayerRoles(userId, roles = null, domRoles = null) {
  const id = safeNumber(userId);
  let merged = mergePlayerRoles(
    mergePlayerRoles(roles, domRoles),
    id === null ? null : profileRoleCache.get(id),
  );
  merged = applyKnownBoosterIdsToRoles(id, merged);
  return merged;
}

function mergeFreshPlayerRoles(prev, fresh, rawPlayer) {
  let merged = mergePlayerRoles(prev, fresh);
  if (!rawPlayer || typeof rawPlayer !== "object") return merged;

  const hasExplicitBooster =
    Object.prototype.hasOwnProperty.call(rawPlayer, "is_booster") ||
    Object.prototype.hasOwnProperty.call(rawPlayer, "isBooster");

  if (hasExplicitBooster) {
    merged = {
      ...merged,
      isBooster:
        rawPlayer.is_booster === true || rawPlayer.isBooster === true,
    };
  } else if (prev?.isBooster && fresh && !fresh.isBooster) {
    merged = { ...merged, isBooster: true };
  }

  return merged;
}

function rememberPlayvortexUserRoles(rawPlayer) {
  if (!rawPlayer || typeof rawPlayer !== "object") return null;

  const id = safeNumber(rawPlayer.id ?? rawPlayer.userId ?? rawPlayer.user_id);
  if (id === null) return null;

  const roles = readPlayerRoles(rawPlayer);
  const prev = profileRoleCache.get(id);
  const merged = mergeFreshPlayerRoles(prev, roles, rawPlayer);
  const changed = !rolesSnapshotEqual(prev, merged);
  profileRoleCache.set(id, merged);
  playvortexUserRoleCacheAt.set(id, Date.now());

  if (merged.isBooster) {
    void persistKnownBoosterId(id);
  } else if (knownBoosterIds.has(id)) {
    void removeKnownBoosterId(id);
  }

  return { roles: merged, changed };
}

function ingestPlayvortexUserPayload(payload, context = {}) {
  if (!payload) return;

  let rolesChanged = false;
  const entries = extractUserEntriesFromPayload(payload);

  entries.forEach((entry) => {
    if (!entry || typeof entry !== "object") return;

    const authoritative = Boolean(
      context.authoritative || playerPayloadHasRoleSignals(entry),
    );
    if (!authoritative) return;

    const id = safeNumber(entry.id ?? entry.userId ?? entry.user_id);
    if (id !== null) playvortexInterceptorIngestedIds.add(id);

    const remembered = rememberPlayvortexUserRoles(entry);
    if (remembered?.changed) rolesChanged = true;
  });

  if (rolesChanged) scheduleBadgeRefreshAfterRoleIngest();
}

function scheduleBadgeRefreshAfterRoleIngest() {
  if (!currentSettings.enabled || isEnhancingBadges) return;

  clearTimeout(roleIngestRefreshTimer);
  roleIngestRefreshTimer = setTimeout(() => {
    roleIngestRefreshTimer = null;
    if (areObserverMutationsPaused()) return;
    enhanceRetroBadges();
  }, ROLE_INGEST_REFRESH_DEBOUNCE_MS);
}

function installPlayvortexFetchInterceptor() {
  if (window.__vortex07FetchHooked) return;
  window.__vortex07FetchHooked = true;

  const nativeFetch = window.fetch.bind(window);

  window.fetch = async function vortex07Fetch(input, init) {
    const response = await nativeFetch(input, init);

    try {
      const rawUrl =
        typeof input === "string" ? input
        : input instanceof URL ? input.href
        : input?.url || "";
      const pathname = rawUrl.startsWith("http")
        ? new URL(rawUrl).pathname
        : rawUrl.split("?")[0];

      const isUserRecord = /^\/api\/users\/\d+\/?$/.test(pathname);
      const isUserSearch = pathname === "/api/users/search";
      const isFriendsList = pathname === "/api/friends" || /^\/api\/friends\/\d+\/?$/.test(pathname);

      if (!isUserRecord && !isUserSearch && !isFriendsList) {
        return response;
      }

      if (response.status === 429 || response.status === 403) {
        markPlayvortexApiFailure(response.status, { severe: response.status === 429 });
        return response;
      }

      const clone = response.clone();
      void clone
        .text()
        .then((text) => {
          if (isCloudflareRateLimitText(text)) {
            markPlayvortexApiFailure(429, { severe: true });
            return;
          }
          const data = parsePlayvortexJsonPayload(text);
          if (data === null || data === undefined) return;
          ingestPlayvortexUserPayload(data, { authoritative: isUserRecord });
        })
        .catch(() => {});
    } catch (_err) {
      // Ignore hook failures — never break native fetch.
    }

    return response;
  };
}

function createOnlineDot(status) {
  const dot = document.createElement("span");
  dot.className = "vortex07-search-online-dot";
  dot.setAttribute("aria-hidden", "true");

  if (status === "online") dot.classList.add("vortex07-status-online");
  else if (status === "in-game") dot.classList.add("vortex07-status-ingame");
  else if (status === "offline") dot.classList.add("vortex07-status-offline");
  else dot.hidden = true;

  return dot;
}

const VORTEX07_NATIVE_STAFF_SELECTOR =
  ".staff-badge-icon, [data-vortex07-badge-kind='staff']";
const VORTEX07_NATIVE_BOOSTER_SELECTOR =
  ".boost-badge-icon, svg.boost-badge-icon, svg.profile-badge-icon[title='Server Booster'], [data-vortex07-badge-kind='booster']";
const VORTEX07_NATIVE_MODERATOR_SELECTOR =
  ".moderator-badge-icon, [data-vortex07-badge-kind='moderator']";

function readRolesFromScope(scope) {
  if (!scope?.querySelector) return null;

  const hasNativeBooster = Boolean(
    scope.querySelector(VORTEX07_NATIVE_BOOSTER_SELECTOR),
  );
  const hasRetroBooster = Boolean(
    scope.querySelector("[data-vortex07-badge-kind='booster']"),
  );

  const isModerator = Boolean(
    scope.querySelector(VORTEX07_NATIVE_MODERATOR_SELECTOR),
  );

  return {
    isStaff:
      Boolean(scope.querySelector(VORTEX07_NATIVE_STAFF_SELECTOR)) ||
      isModerator,
    isModerator,
    isBooster: hasNativeBooster || hasRetroBooster,
  };
}

function resolveBadgeRoleScope(host, badgeHost) {
  return (
    badgeHost?.closest(".profile-header") ||
    host?.closest(".profile-header") ||
    badgeHost?.closest(".friend-card, .user-card, .user-row") ||
    host?.closest(".friend-card, .user-card, .user-row") ||
    badgeHost ||
    host
  );
}

function resolveBadgeIconSize(host) {
  if (!host) return VORTEX07_BADGE_ICON_SIZE;
  if (host.closest(".profile-username, .profile-header")) {
    return VORTEX07_BADGE_ICON_SIZE_PROFILE;
  }
  if (host.closest(".vortex07-user-name-row, .vortex07-hover-name-row")) {
    return VORTEX07_BADGE_ICON_SIZE_SEARCH;
  }
  if (host.closest(".friends-grid .friend-name, .friends-grid .friend-card")) {
    return VORTEX07_BADGE_ICON_SIZE_GRID;
  }
  if (host.closest(".friend-name, .user-card-name, .vortex07-home-leaderboard-name")) {
    return VORTEX07_BADGE_ICON_SIZE_FRIEND;
  }
  if (host.closest(".user-row-name")) {
    return VORTEX07_BADGE_ICON_SIZE_COMPACT;
  }
  return VORTEX07_BADGE_ICON_SIZE;
}

function applyBadgeWrapSize(wrap, size) {
  if (!wrap || !size) return;
  wrap.style.width = `${size}px`;
  wrap.style.height = `${size}px`;
  const img = wrap.querySelector(".vortex07-retro-badge-img");
  if (img) {
    img.setAttribute("width", String(size));
    img.setAttribute("height", String(size));
    img.style.width = `${size}px`;
    img.style.height = `${size}px`;
  }
}
function resolveBadgeKindMeta(kind) {
  if (kind === "owner") {
    return { title: "Owner", extraClass: "" };
  }
  if (kind === "developer") {
    return { title: "Vortex07 Developer", extraClass: "" };
  }
  if (kind === "staff") {
    return { title: "Staff", extraClass: "vortex07-search-role-badge" };
  }
  if (kind === "booster") {
    return { title: "Server Booster", extraClass: "vortex07-search-role-badge" };
  }
  return null;
}

function resolveBadgeKinds(userId, roles = null) {
  const id = safeNumber(userId);
  if (id === null) return [];

  const kinds = [];
  if (isTheHaloDeveloper(id)) kinds.push("owner");
  if (isVortex07Developer(id)) kinds.push("developer");
  if (roles?.isStaff || roles?.isModerator) kinds.push("staff");
  if (roles?.isBooster) kinds.push("booster");
  return kinds;
}

function mergePlayerRoles(primary = null, secondary = null) {
  if (!primary && !secondary) return null;
  const isModerator = Boolean(primary?.isModerator || secondary?.isModerator);
  return {
    isStaff: Boolean(
      primary?.isStaff || secondary?.isStaff || isModerator,
    ),
    isModerator,
    isBooster: Boolean(primary?.isBooster || secondary?.isBooster),
  };
}

function resolveUsernameBadgeHost(host) {
  if (!host) return null;
  if (host.classList.contains("profile-username")) {
    return ensureProfileBadgeHost(host);
  }
  if (host.classList.contains("friend-name")) {
    host.classList.add("vortex07-friend-name-host");
  }
  return host;
}

function finalizeBadgeHost(badgeHost) {
  if (!badgeHost?.querySelector(".vortex07-retro-badge-wrap")) return;

  replaceNativeBadgeIcons(badgeHost);

  badgeHost.classList.add("vortex07-badges-ready");
  if (badgeHost.classList.contains("profile-badges")) {
    badgeHost.classList.add("vortex07-badge-strip");
  }
  badgeHost.closest(".profile-username")?.classList.add("vortex07-badges-ready");
  badgeHost
    .querySelectorAll(
      ".staff-badge-icon:not(.vortex07-retro-badge-wrap), .boost-badge-icon:not(.vortex07-retro-badge-wrap), .moderator-badge-icon:not(.vortex07-retro-badge-wrap)",
    )
    .forEach((el) => {
      el.hidden = true;
      el.setAttribute("aria-hidden", "true");
    });
}

function badgesMatchDesiredState(badgeHost, desiredKinds) {
  if (!badgeHost?.classList.contains("vortex07-badges-ready")) return false;

  const existingKinds = [...badgeHost.querySelectorAll(".vortex07-retro-badge-wrap")]
    .map((el) => el.dataset.vortex07BadgeKind)
    .filter(Boolean)
    .sort();

  const desired = [...desiredKinds].sort();
  if (existingKinds.length !== desired.length) return false;
  return existingKinds.every((kind, index) => kind === desired[index]);
}

function organizeFriendNameLayout(nameHost) {
  if (!nameHost?.classList.contains("friend-name")) return;

  const badges = [...nameHost.querySelectorAll(".vortex07-retro-badge-wrap")];
  let text = "";

  nameHost.childNodes.forEach((node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      text += node.textContent;
    } else if (
      node.nodeType === Node.ELEMENT_NODE &&
      !node.classList.contains("vortex07-retro-badge-wrap") &&
      !node.classList.contains("friend-name-text") &&
      !node.classList.contains("vortex07-friend-badge-row")
    ) {
      text += node.textContent;
    }
  });

  text = safeString(text);
  if (!text && badges.length === 0) return;

  const existingText = nameHost.querySelector(".friend-name-text");
  const existingRow = nameHost.querySelector(".vortex07-friend-badge-row");

  if (existingText) {
    if (text) existingText.textContent = text;
  } else {
    nameHost.textContent = "";
    nameHost.classList.add("vortex07-friend-name-host");

    const textEl = document.createElement("span");
    textEl.className = "friend-name-text";
    textEl.textContent = text;
    nameHost.appendChild(textEl);
  }

  if (badges.length === 0) {
    existingRow?.remove();
    return;
  }

  let badgeRow = existingRow;
  if (!badgeRow) {
    badgeRow = document.createElement("span");
    badgeRow.className = "vortex07-friend-badge-row";
    nameHost.appendChild(badgeRow);
  }

  badges.forEach((badge) => badgeRow.appendChild(badge));
}

function syncUsernameBadges(host, userId, roles = null) {
  if (!host) return;

  const id = safeNumber(userId);
  if (id === null) return;

  markDeveloperPresence(host, id);

  const badgeHost = resolveUsernameBadgeHost(host);
  if (!badgeHost) return;

  const roleScope = resolveBadgeRoleScope(host, badgeHost);
  const domRoles = readRolesFromScope(roleScope);
  const mergedRoles = resolvePlayerRoles(id, roles, domRoles);
  const desiredKinds = resolveBadgeKinds(id, mergedRoles);

  if (badgesMatchDesiredState(badgeHost, desiredKinds)) {
    organizeFriendNameLayout(badgeHost);
    return;
  }

  replaceNativeBadgeIcons(roleScope);
  replaceNativeBadgeIcons(badgeHost);

  const existingByKind = new Map(
    [...badgeHost.querySelectorAll(".vortex07-retro-badge-wrap")]
      .map((el) => [el.dataset.vortex07BadgeKind, el])
      .filter(([kind]) => Boolean(kind)),
  );

  const badgeSize = resolveBadgeIconSize(badgeHost);

  existingByKind.forEach((el, kind) => {
    const file = VORTEX07_BADGE_ASSETS[kind];
    if (file) {
      const img = el.querySelector(".vortex07-retro-badge-img");
      const url = badgeAssetUrl(file);
      if (img && url && img.getAttribute("src") !== url) {
        img.setAttribute("src", url);
        wireBadgeIconFallback(img, kind);
      }
      applyBadgeWrapSize(el, badgeSize);
    }

    if (!desiredKinds.includes(kind)) {
      el.remove();
      existingByKind.delete(kind);
    }
  });

  desiredKinds.forEach((kind) => {
    if (existingByKind.has(kind)) return;

    const meta = resolveBadgeKindMeta(kind);
    if (!meta) return;

    const wrap = createRetroBadgeWrap(kind, meta.title, meta.extraClass, badgeSize);
    wrap.dataset.vortex07BadgeKind = kind;
    existingByKind.set(kind, wrap);
    badgeHost.appendChild(wrap);
  });

  let orderChanged = false;
  desiredKinds.forEach((kind, index) => {
    const el = existingByKind.get(kind);
    if (!el) return;
    const sibling = badgeHost.children[index];
    if (sibling !== el) {
      orderChanged = true;
      badgeHost.appendChild(el);
    }
  });

  if (orderChanged || desiredKinds.length > 0) {
    finalizeBadgeHost(badgeHost);
  }

  organizeFriendNameLayout(badgeHost);
}

function appendUsernameBadges(host, userId, roles = null) {
  syncUsernameBadges(host, userId, roles);
}

const VORTEX07_BADGE_ASSETS = {
  owner: "owner.svg",
  developer: "developer.svg",
  staff: "staff.svg",
  booster: "booster.svg",
};
const VORTEX07_BADGE_ICON_SIZE = 14;
const VORTEX07_BADGE_ICON_SIZE_PROFILE = 18;
const VORTEX07_BADGE_ICON_SIZE_SEARCH = 15;
const VORTEX07_BADGE_ICON_SIZE_FRIEND = 12;
const VORTEX07_BADGE_ICON_SIZE_GRID = 10;
const VORTEX07_BADGE_ICON_SIZE_COMPACT = 13;

function badgeAssetUrl(filename) {
  return extensionAssetUrl(`assets/badges/${filename}`);
}

function preloadBadgeAssets() {
  if (!isExtensionContextAlive()) return;
  Object.entries(VORTEX07_BADGE_ASSETS).forEach(([kind, file]) => {
    const img = new Image();
    img.decoding = "async";
    img.src = badgeAssetUrl(file);
    wireBadgeIconFallback(img, kind);
  });
}

function retroBadgeImgHtml(kind, size = VORTEX07_BADGE_ICON_SIZE) {
  const file = VORTEX07_BADGE_ASSETS[kind];
  if (!file) return "";

  const url = badgeAssetUrl(file);
  if (!url) return "";

  return `<img class="vortex07-retro-badge-img vortex07-retro-badge-${kind}" src="${url}" width="${size}" height="${size}" alt="" aria-hidden="true" loading="eager" decoding="async" />`;
}

function createRetroBadgeWrap(kind, title, extraClass = "", size = VORTEX07_BADGE_ICON_SIZE) {
  const wrap = document.createElement("span");
  wrap.className =
    `profile-badge-icon vortex07-retro-badge-wrap vortex07-retro-badge-size-${size} ${extraClass}`.trim();
  wrap.title = title;
  wrap.dataset.vortex07Retro = "1";
  wrap.dataset.vortex07BadgeKind = kind;
  wrap.innerHTML = retroBadgeImgHtml(kind, size);
  applyBadgeWrapSize(wrap, size);
  wireBadgeIconFallback(wrap.querySelector(".vortex07-retro-badge-img"), kind);
  return wrap;
}

function replaceRetroBadgeElement(el, className, title, kind) {
  if (!el || el.dataset.vortex07Retro === "1") return;

  const wrap = createRetroBadgeWrap(kind, title, className);
  el.replaceWith(wrap);
}

function replaceNativeBadgeIcons(root = document) {
  if (!root?.querySelectorAll) return;

  root
    .querySelectorAll(
      `${VORTEX07_NATIVE_STAFF_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
    )
    .forEach((el) => {
      replaceRetroBadgeElement(
        el,
        "vortex07-retro-staff",
        el.getAttribute("title") || "Staff",
        "staff",
      );
    });

  root
    .querySelectorAll(
      `${VORTEX07_NATIVE_MODERATOR_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
    )
    .forEach((el) => {
      const badgeHost =
        el.closest(
          ".profile-badges, .profile-username, .friend-name, .vortex07-user-name-row, .vortex07-hover-name-row",
        ) || el.parentElement;
      const hasStaffBadge = badgeHost?.querySelector(
        `${VORTEX07_NATIVE_STAFF_SELECTOR}, [data-vortex07-badge-kind='staff']`,
      );

      if (hasStaffBadge) {
        el.hidden = true;
        el.setAttribute("aria-hidden", "true");
        el.dataset.vortex07Retro = "1";
        return;
      }

      replaceRetroBadgeElement(el, "vortex07-retro-staff", "Staff", "staff");
    });

  root
    .querySelectorAll(
      `${VORTEX07_NATIVE_BOOSTER_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
    )
    .forEach((el) => {
      replaceRetroBadgeElement(
        el,
        "vortex07-retro-booster",
        el.getAttribute("title") || "Server Booster",
        "booster",
      );
    });
}

function markDeveloperPresence(host, userId) {
  if (!isVortex07Developer(userId)) return;

  if (host.classList.contains("profile-username")) {
    host.classList.add("vortex07-dev-username");
  }
  if (host.classList.contains("friend-name")) {
    host.classList.add("vortex07-dev-friend-name");
  }
}

function ensureProfileBadgeHost(usernameEl) {
  if (!usernameEl) return null;

  let badges = usernameEl.querySelector(".profile-badges");
  if (!badges) {
    badges = document.createElement("span");
    badges.className = "profile-badges";
    usernameEl.appendChild(badges);
  }

  return badges;
}

function enhanceRetroBadges(root = document) {
  if (isEnhancingBadges || !currentSettings.enabled) return;

  isEnhancingBadges = true;
  try {
    withDomEnhancementPaused(() => {
      const profileHeader =
        root.matches?.(".profile-header") ?
          root
        : root.querySelector(".profile-header");
      const profileUsername =
        profileHeader?.querySelector(".profile-username") ||
        root.querySelector(".profile-username");
      const profileRoles = profileHeader ? readRolesFromScope(profileHeader) : null;
      const profileUserId = profileUsername ? getProfileUserIdFromPage() : null;
      const currentProfileKey =
        profileUserId !== null ? profileEnhanceKey(profileUserId) : "";
      const skipProfileBadges =
        currentProfileKey !== "" &&
        currentProfileKey === lastEnhancedProfileKey &&
        !profileBadgesNeedRefresh(profileHeader, profileUserId);

      const friendBadgeTargets = [];
      root
        .querySelectorAll(
          "a.friend-card[href*='/users/'], a.user-card[href*='/users/'], .user-row a[href*='/users/']",
        )
        .forEach((link) => {
          const card =
            link.closest(".friend-card, .user-card, .user-row") || link;
          const userId = extractUserIdFromHref(link.getAttribute("href") || "");
          if (userId === null) return;

          friendBadgeTargets.push({
            card,
            userId,
            roles: readRolesFromScope(card),
          });
        });

      replaceNativeBadgeIcons(root);

      if (profileUsername && !skipProfileBadges) {
        replaceNativeBadgeIcons(profileHeader || root);
        syncUsernameBadges(
          profileUsername,
          profileUserId,
          resolvePlayerRoles(profileUserId, profileRoles),
        );
        if (
          currentProfileKey &&
          !profileBadgesNeedRefresh(profileHeader || root, profileUserId)
        ) {
          lastEnhancedProfileKey = currentProfileKey;
        }
        scheduleProfileBadgeHydration(
          profileHeader || root,
          profileUsername,
          profileUserId,
        );
      }

      friendBadgeTargets.forEach(({ card, userId, roles }) => {
        const nameHost =
          card.querySelector(
            ".friend-name, .user-card-name, .user-row-name, .profile-username",
          ) || card;
        const cachedRoles = profileRoleCache.get(userId);
        syncUsernameBadges(
          nameHost,
          userId,
          resolvePlayerRoles(userId, mergePlayerRoles(roles, cachedRoles)),
        );
      });

      root.querySelectorAll(".vortex07-player-result").forEach((row) => {
        const userId = safeNumber(row.dataset.vortex07UserId);
        if (userId === null) return;
        syncUsernameBadges(
          row.querySelector(".vortex07-user-name-row"),
          userId,
          resolvePlayerRoles(userId, profileRoleCache.get(userId) || null),
        );
      });

      scheduleFriendBadgeHydration(root);
    });
  } finally {
    isEnhancingBadges = false;
  }
}

function getProfileUserIdFromPage() {
  const pathParts = safeString(window.location.pathname)
    .split("/")
    .filter(Boolean);
  if (pathParts[0] === "users" && pathParts[1]) {
    const fromParts = safeNumber(pathParts[1]);
    if (fromParts !== null) return fromParts;
  }

  const fromPath = extractUserIdFromHref(window.location.pathname);
  if (fromPath !== null) return fromPath;

  const header = document.querySelector(".profile-header");
  if (!header) return null;

  const statLink = header.querySelector('a.profile-stat[href*="user="]');
  if (statLink) {
    const match = safeString(statLink.getAttribute("href")).match(
      /[?&]user=(\d+)/i,
    );
    if (match) return safeNumber(match[1]);
  }

  const repPanel = header.querySelector(".vortex07-reputation-panel");
  if (repPanel?.dataset.vortex07UserId) {
    return safeNumber(repPanel.dataset.vortex07UserId);
  }

  const avatarImg = header.querySelector(
    "img[data-vortex07-uid], .profile-avatar[data-vortex07-uid]",
  );
  if (avatarImg?.dataset.vortex07Uid) {
    return safeNumber(avatarImg.dataset.vortex07Uid);
  }

  return null;
}

async function fetchPlayvortexUserRecord(userId, options = {}) {
  const id = safeNumber(userId);
  if (id === null) return null;

  if (!options.force) {
    if (hasFreshUserRolesInCache(id)) return null;
  }

  if (isPlayvortexUserFetchBlocked() && !options.force) return null;

  const inflight = playvortexUserFetchInflight.get(id);
  if (inflight) return inflight;

  const promise = (async () => {
    const data = await enqueuePlayvortexUserFetch(() =>
      vortexApi.get(
        `/api/users/${id}`,
        {},
        { userInitiated: options.userInitiated === true },
      ),
    );
    if (!data || typeof data !== "object") return null;
    return data;
  })();

  playvortexUserFetchInflight.set(id, promise);
  try {
    return await promise;
  } finally {
    if (playvortexUserFetchInflight.get(id) === promise) {
      playvortexUserFetchInflight.delete(id);
    }
  }
}

async function fetchProfileUserRoles(userId, options = {}) {
  const id = safeNumber(userId);
  if (id === null) return null;

  if (!options.force) {
    if (hasFreshUserRolesInCache(id)) {
      return profileRoleCache.get(id);
    }
  }

  if (isPlayvortexUserFetchBlocked() && !options.force) {
    return profileRoleCache.get(id) || resolvePlayerRoles(id, null);
  }

  const data = await fetchPlayvortexUserRecord(id, options);
  if (!data) return profileRoleCache.get(id) || resolvePlayerRoles(id, null);

  const remembered = rememberPlayvortexUserRoles(data);
  return remembered?.roles ?? (profileRoleCache.get(id) || null);
}

function collectFriendBadgeTargets(root = document) {
  const targets = [];

  root
    .querySelectorAll(
      "a.friend-card[href*='/users/'], a.user-card[href*='/users/'], .user-row a[href*='/users/']",
    )
    .forEach((link) => {
      const card =
        link.closest(".friend-card, .user-card, .user-row") || link;
      const userId = extractUserIdFromHref(link.getAttribute("href") || "");
      if (userId === null) return;

      const nameHost = card.querySelector(
        ".friend-name, .user-card-name, .user-row-name",
      );
      if (!nameHost) return;

      targets.push({ nameHost, userId });
    });

  return targets;
}

function scheduleFriendBadgeHydration(root = document) {
  if (!currentSettings.enabled) return;
  if (isPlayvortexUserFetchBlocked() || shouldSkipNonEssentialPolling()) return;

  const route = resolvePageRouteKey();
  if (route === "home" || route === "catalog") return;

  resetFriendBadgeBudgetIfPageChanged();
  if (friendBadgeApiFetchBudget <= 0) return;

  clearTimeout(friendBadgeHydrateTimer);
  friendBadgeHydrateTimer = setTimeout(() => {
    friendBadgeHydrateTimer = null;
    void hydrateFriendBadgesFromApi(root);
  }, FRIEND_BADGE_DEBOUNCE_MS);
}

async function hydrateFriendBadgesFromApi(root = document) {
  if (!currentSettings.enabled) return;
  if (isPlayvortexUserFetchBlocked() || shouldSkipNonEssentialPolling()) return;

  resetFriendBadgeBudgetIfPageChanged();
  if (friendBadgeApiFetchBudget <= 0) return;

  const targets = collectFriendBadgeTargets(root);
  if (targets.length === 0) return;

  const token = ++friendBadgeHydrateToken;
  const pendingIds = [];

  targets.forEach(({ userId }) => {
    if (isTheHaloDeveloper(userId)) return;
    if (hasFreshUserRolesInCache(userId)) return;
    pendingIds.push(userId);
  });

  const uniquePending = [...new Set(pendingIds)].slice(
    0,
    Math.min(friendBadgeApiFetchBudget, FRIEND_BADGE_QUEUE_MAX),
  );

  for (const userId of uniquePending) {
    if (token !== friendBadgeHydrateToken) return;
    if (isPlayvortexUserFetchBlocked() || friendBadgeApiFetchBudget <= 0) break;

    await fetchProfileUserRoles(userId, { userInitiated: false });
    friendBadgeApiFetchBudget -= 1;

    if (uniquePending.indexOf(userId) < uniquePending.length - 1) {
      await sleep(FRIEND_BADGE_QUEUE_SPACING_MS);
    }
  }

  if (token !== friendBadgeHydrateToken) return;

  targets.forEach(({ nameHost, userId }) => {
    if (!nameHost.isConnected) return;
    syncUsernameBadges(
      nameHost,
      userId,
      resolvePlayerRoles(userId, profileRoleCache.get(userId) || null),
    );
  });
}

function scheduleProfileBadgeHydration(header, usernameEl, userId) {
  if (!header || !usernameEl || userId === null) return;

  const id = safeNumber(userId);
  const isNewProfile = id !== null && id !== lastProfileBadgeRefreshUserId;
  if (isNewProfile) {
    lastProfileBadgeRefreshUserId = id;
    playvortexInterceptorIngestedIds.delete(id);
    playvortexUserRoleCacheAt.delete(id);
  }

  clearTimeout(profileBadgeEnhanceTimer);
  profileBadgeEnhanceTimer = setTimeout(() => {
    profileBadgeEnhanceTimer = null;
    void hydrateProfileBadgesFromApi(header, usernameEl, userId, {
      force: isNewProfile,
    });
  }, PROFILE_BADGE_DEBOUNCE_MS);
}

async function hydrateProfileBadgesFromApi(header, usernameEl, userId, options = {}) {
  if (!header?.isConnected || !usernameEl?.isConnected) return;

  const token = ++profileBadgeHydrateToken;

  withDomEnhancementPaused(() => {
    const domRoles = readRolesFromScope(header);
    replaceNativeBadgeIcons(header);
    syncUsernameBadges(
      usernameEl,
      userId,
      resolvePlayerRoles(userId, domRoles),
    );
  });

  if (
    !options.force &&
    hasFreshUserRolesInCache(userId)
  ) {
    return;
  }
  if (isPlayvortexUserFetchBlocked() && !options.force) return;

  const apiRoles = await fetchProfileUserRoles(userId, {
    userInitiated: false,
    force: options.force === true,
  });
  if (token !== profileBadgeHydrateToken) return;
  if (!usernameEl.isConnected) return;

  withDomEnhancementPaused(() => {
    replaceNativeBadgeIcons(header);
    syncUsernameBadges(
      usernameEl,
      userId,
      resolvePlayerRoles(userId, apiRoles, readRolesFromScope(header)),
    );
    const key = profileEnhanceKey(userId);
    if (key && !profileBadgesNeedRefresh(header, userId)) {
      lastEnhancedProfileKey = key;
    }
  });
}

function startProfileBadgeObserver() {
  if (profileBadgeObserverStarted) return;
  profileBadgeObserverStarted = true;

  profileBadgeObserver = new MutationObserver((mutations) => {
    if (!currentSettings.enabled || areObserverMutationsPaused()) return;
    if (!mutations.some(isProfileBadgeRelevantMutation)) return;
    scheduleProfileBadgeEnhanceFast();
  });

  profileBadgeObserver.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "title"],
  });
}

function runProfileBadgeEnhanceFast() {
  if (!currentSettings.enabled || isEnhancingBadges || areObserverMutationsPaused()) {
    return;
  }

  const header = document.querySelector(".profile-header");
  const profileUsername = header?.querySelector(".profile-username");
  if (!header || !profileUsername) return;

  const userId = getProfileUserIdFromPage();
  if (userId === null) return;

  const key = profileEnhanceKey(userId);
  if (key && key === lastEnhancedProfileKey && !profileBadgesNeedRefresh(header, userId)) {
    return;
  }

  withDomEnhancementPaused(() => {
    const domRoles = readRolesFromScope(header);
    replaceNativeBadgeIcons(header);
    syncUsernameBadges(
      profileUsername,
      userId,
      resolvePlayerRoles(userId, domRoles),
    );
  });

  if (key && !profileBadgesNeedRefresh(header, userId)) {
    lastEnhancedProfileKey = key;
  }
}

function scheduleProfileBadgeEnhanceFast() {
  if (!currentSettings.enabled || areObserverMutationsPaused()) return;

  clearTimeout(profileBadgeFastEnhanceTimer);
  profileBadgeFastEnhanceTimer = setTimeout(() => {
    profileBadgeFastEnhanceTimer = null;
    runProfileBadgeEnhanceFast();
  }, PROFILE_BADGE_DEBOUNCE_MS);
}

function getLoggedInUserIdFromNav() {
  const links = document.querySelectorAll(
    '.navbar-actions a[href*="/users/"], #Alerts a[href*="/users/"]',
  );

  for (const link of links) {
    const href = link.getAttribute("href") || "";
    if (!href.includes("/profile")) continue;
    const id = extractUserIdFromHref(href);
    if (id !== null) return id;
  }

  return null;
}

function getActorUserId() {
  return getLoggedInUserIdFromNav();
}

function isVortex07DeveloperSession() {
  const actorId = getActorUserId();
  return actorId !== null && VORTEX07_DEVELOPER_IDS.has(actorId);
}

async function buildRepActorQuery(extraParams = {}) {
  const actorId = getActorUserId();
  if (actorId !== null) {
    return new URLSearchParams({
      ...extraParams,
      actorUserId: String(actorId),
    }).toString();
  }

  const voterId = await ensureVoterId();
  return new URLSearchParams({ ...extraParams, voterId }).toString();
}

function invalidateRepApiCache(userId = null) {
  const keysToDelete = [];
  for (const key of apiRequestState.cache.keys()) {
    if (!key.includes("/reputation") && !key.includes("/players/batch")) continue;
    if (userId !== null && !key.includes(String(userId))) continue;
    keysToDelete.push(key);
  }
  keysToDelete.forEach((key) => apiRequestState.cache.delete(key));
}

function getReputationApiBase() {
  if (!currentSettings.enabled) return "";
  const custom = safeString(currentSettings.reputationApiUrl).replace(/\/$/, "");
  if (custom && isVortex07DeveloperSession()) return custom;
  return VORTEX07_API_BASE;
}

function getVortex07ApiBase() {
  return getReputationApiBase();
}

async function ensureVoterId() {
  if (sessionMemoryStore.voterId) return sessionMemoryStore.voterId;

  const data = await storageGet("local", { [REPUTATION_VOTER_KEY]: "" });
  if (data[REPUTATION_VOTER_KEY]) {
    sessionMemoryStore.voterId = data[REPUTATION_VOTER_KEY];
    return data[REPUTATION_VOTER_KEY];
  }

  const voterId =
    typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID()
      : `v${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

  sessionMemoryStore.voterId = voterId;
  await storageSet("local", { [REPUTATION_VOTER_KEY]: voterId });
  return voterId;
}

async function loadMyReputationVotes() {
  const data = await storageGet("local", { [REPUTATION_MY_VOTES_KEY]: {} });
  const votes = data[REPUTATION_MY_VOTES_KEY];
  return votes && typeof votes === "object" ? votes : {};
}

async function saveMyReputationVote(userId) {
  const votes = await loadMyReputationVotes();
  votes[String(userId)] = Date.now();
  await storageSet("local", { [REPUTATION_MY_VOTES_KEY]: votes });
}

async function removeMyReputationVote(userId) {
  const votes = await loadMyReputationVotes();
  delete votes[String(userId)];
  await storageSet("local", { [REPUTATION_MY_VOTES_KEY]: votes });
}

async function getCachedReputation(userId) {
  const data = await storageGet("local", { [REPUTATION_CACHE_KEY]: {} });
  const cache = data[REPUTATION_CACHE_KEY];
  return cache?.[String(userId)] || null;
}

function normalizeReputationCount(count, hasVoted) {
  const numeric = Number(count) || 0;
  if (hasVoted && numeric < 1) return 1;
  return numeric;
}

function buildReputationStatus(count, hasVoted, localHasVoted, meta = {}) {
  const voted = Boolean(hasVoted) || Boolean(localHasVoted);
  const normalizedCount = normalizeReputationCount(count, voted);
  return {
    count: normalizedCount,
    hasVoted: voted,
    ...meta,
  };
}

async function cacheReputation(userId, count, hasVoted) {
  const data = await storageGet("local", { [REPUTATION_CACHE_KEY]: {} });
  const cache = data[REPUTATION_CACHE_KEY] || {};
  cache[String(userId)] = {
    count: normalizeReputationCount(count, hasVoted),
    hasVoted: Boolean(hasVoted),
    cachedAt: Date.now(),
  };
  await storageSet("local", { [REPUTATION_CACHE_KEY]: cache });
}

async function fetchReputationStatus(userId) {
  const myVotes = await loadMyReputationVotes();
  const localHasVoted = Boolean(myVotes[String(userId)]);
  const apiBase = getReputationApiBase();

  if (!apiBase) {
    return buildReputationStatus(localHasVoted ? 1 : 0, localHasVoted, localHasVoted, {
      synced: false,
      localOnly: true,
    });
  }

  if (!isRepApiAvailable()) {
    const cached = await getCachedReputation(userId);
    if (cached) {
      return buildReputationStatus(
        cached.count,
        cached.hasVoted,
        localHasVoted,
        { synced: false, localOnly: true },
      );
    }

    return buildReputationStatus(localHasVoted ? 1 : 0, localHasVoted, localHasVoted, {
      synced: false,
      localOnly: true,
    });
  }

  try {
    const query = await buildRepActorQuery({ userId: String(userId) });
    const url = `${apiBase}/reputation?${query}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
      force: true,
    });

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const json = await response.json();
    const apiHasVoted = Boolean(json.hasVoted);
    const count = Number(json.count) || 0;

    if (localHasVoted && !apiHasVoted) {
      queuePendingReputationVote(userId);
    }

    const status = buildReputationStatus(count, apiHasVoted, localHasVoted, {
      synced: true,
      localOnly: localHasVoted && !apiHasVoted,
    });

    await cacheReputation(userId, status.count, status.hasVoted);
    logRep("Fetched reputation:", { userId, ...status });

    return status;
  } catch (err) {
    markRepApiFailure();
    logRepFailureOnce("Reputation fetch failed:", err);
    const cached = await getCachedReputation(userId);
    if (cached) {
      return buildReputationStatus(
        cached.count,
        cached.hasVoted,
        localHasVoted,
        { synced: false, localOnly: false },
      );
    }

    return buildReputationStatus(localHasVoted ? 1 : 0, localHasVoted, localHasVoted, {
      synced: false,
      localOnly: true,
    });
  }
}

async function giveReputation(userId) {
  const numericId = safeNumber(userId);
  if (numericId === null) return { ok: false, reason: "invalid-user" };

  const actorId = getActorUserId();
  if (actorId === null) return { ok: false, reason: "not-logged-in" };

  if (actorId === numericId) {
    return { ok: false, reason: "self" };
  }

  const myVotes = await loadMyReputationVotes();
  if (myVotes[String(numericId)]) {
    return { ok: false, reason: "already-voted" };
  }

  const apiBase = getReputationApiBase();

  if (apiBase) {
    try {
      const captchaToken = await getTurnstileToken();
      const voteHeaders = {
        Accept: "application/json",
        "Content-Type": "application/json",
      };
      if (captchaToken) voteHeaders["X-Turnstile-Token"] = captchaToken;

      const response = await fetchReputationRequest(`${apiBase}/reputation`, {
        method: "POST",
        headers: voteHeaders,
        body: JSON.stringify({ userId: numericId, actorUserId: actorId }),
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const json = await response.json();
      await saveMyReputationVote(numericId);
      const count = normalizeReputationCount(json.count, true);
      await cacheReputation(numericId, count, true);
      invalidateRepApiCache(numericId);
      logRep("Gave reputation (synced):", numericId, count);
      void pushLocalActivityEvent(numericId, 1);

      return {
        ok: true,
        count,
        hasVoted: true,
        synced: true,
      };
    } catch (err) {
      markRepApiFailure();
      logRepFailureOnce("Reputation POST failed:", err);
      await queuePendingReputationVote(numericId);
    }
  } else {
    await queuePendingReputationVote(numericId);
  }

  await saveMyReputationVote(numericId);
  const cached = await getCachedReputation(numericId);
  const count = (Number(cached?.count) || 0) + 1;
  await cacheReputation(numericId, count, true);
  logRep("Gave reputation (queued/local):", numericId, count);
  void pushLocalActivityEvent(numericId, 1);

  return {
    ok: true,
    count,
    hasVoted: true,
    synced: false,
    localOnly: true,
  };
}

async function removeReputation(userId) {
  const numericId = safeNumber(userId);
  if (numericId === null) return { ok: false, reason: "invalid-user" };

  const actorId = getActorUserId();
  if (actorId === null) return { ok: false, reason: "not-logged-in" };

  const myVotes = await loadMyReputationVotes();
  if (!myVotes[String(numericId)]) {
    return { ok: false, reason: "not-voted" };
  }

  const apiBase = getReputationApiBase();

  if (apiBase && isRepApiAvailable()) {
    try {
      const query = await buildRepActorQuery({ userId: String(numericId) });
      let response = await fetchReputationRequest(`${apiBase}/reputation?${query}`, {
        method: "DELETE",
        headers: { Accept: "application/json" },
      });

      if (response.status === 405 || response.status === 404) {
        response = await fetchReputationRequest(`${apiBase}/reputation`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: numericId,
            actorUserId: actorId,
            action: "remove",
          }),
        });
      }

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const json = await response.json();
      await unqueuePendingReputationVote(numericId);
      await removeMyReputationVote(numericId);
      const count = Math.max(0, Number(json.count) || 0);
      await cacheReputation(numericId, count, false);
      invalidateRepApiCache(numericId);
      logRep("Removed reputation (synced):", numericId, count);

      return {
        ok: true,
        count,
        hasVoted: false,
        synced: true,
      };
    } catch (err) {
      markRepApiFailure();
      logRepFailureOnce("Reputation DELETE failed:", err);
    }
  }

  await unqueuePendingReputationVote(numericId);
  await removeMyReputationVote(numericId);
  const cached = await getCachedReputation(numericId);
  const count = Math.max(0, (Number(cached?.count) || 1) - 1);
  await cacheReputation(numericId, count, false);
  logRep("Removed reputation (local):", numericId, count);

  return {
    ok: true,
    count,
    hasVoted: false,
    synced: false,
    localOnly: true,
  };
}

function updateReputationPanel(panel, status) {
  const countEl = panel.querySelector(".vortex07-rep-count");
  const scoreBox = panel.querySelector(".vortex07-reputation-score");
  const upBtn = panel.querySelector(".vortex07-rep-btn-up");
  const downBtn = panel.querySelector(".vortex07-rep-btn-down");
  const count = Number(status.count) || 0;
  const voted = Boolean(status.hasVoted);
  const busy = Boolean(status.busy);

  if (countEl) countEl.textContent = String(count);
  scoreBox?.classList.toggle("is-voted", voted);

  if (upBtn) {
    upBtn.classList.toggle("is-on", voted);
    upBtn.disabled = voted || busy;
  }

  if (downBtn) {
    downBtn.classList.toggle("is-on", voted);
    downBtn.disabled = !voted || busy;
  }

  panel.classList.toggle("vortex07-rep-synced", Boolean(status.synced));
  panel.classList.toggle("vortex07-rep-pending", Boolean(status.localOnly));
  syncRepMilestoneOnPanel(panel, count);
}

async function handleReputationPanelAction(panel, userId, action) {
  const upBtn = panel.querySelector(".vortex07-rep-btn-up");
  const downBtn = panel.querySelector(".vortex07-rep-btn-down");
  const countEl = panel.querySelector(".vortex07-rep-count");
  const previousCount = Number(countEl?.textContent) || 0;
  const wasVoted = panel.querySelector(".vortex07-reputation-score")?.classList.contains("is-voted");

  updateReputationPanel(panel, {
    count: previousCount,
    hasVoted: wasVoted,
    busy: true,
  });

  const result =
    action === "remove"
      ? await removeReputation(userId)
      : await giveReputation(userId);

  if (result.ok) {
    updateReputationPanel(panel, {
      count: result.count,
      hasVoted: action === "remove" ? false : true,
      synced: result.synced,
      localOnly: result.localOnly,
    });
    scheduleGlobalRepBadges();
    return;
  }

  if (result.reason === "self" && action === "add") {
    updateReputationPanel(panel, {
      count: previousCount,
      hasVoted: wasVoted,
      busy: false,
    });
    if (upBtn) upBtn.title = "You can't rep yourself";
    return;
  }

  if (result.reason === "not-logged-in") {
    updateReputationPanel(panel, {
      count: previousCount,
      hasVoted: wasVoted,
      busy: false,
    });
    if (upBtn) {
      upBtn.disabled = true;
      upBtn.title = "Sign in to give rep";
    }
    if (downBtn) downBtn.disabled = true;
    return;
  }

  if (result.reason === "already-voted" || result.reason === "not-voted") {
    await refreshReputationPanel(panel, userId);
    return;
  }

  updateReputationPanel(panel, {
    count: previousCount,
    hasVoted: wasVoted,
    synced: false,
    localOnly: false,
  });
}

async function refreshReputationPanel(panel, userId) {
  try {
    const status = await fetchReputationStatus(userId);
    updateReputationPanel(panel, status);
    return status;
  } catch (err) {
    if (!isContextInvalidatedError(err)) logWarn("Reputation panel refresh failed:", err);
    return null;
  }
}

function injectReputationWidget() {
  if (!currentSettings.enabled) return;

  const userId = getProfileUserIdFromPage();
  if (userId === null) return;

  const header = document.querySelector(".profile-header");
  if (!header) return;

  let panel = header.querySelector(".vortex07-reputation-panel");
  if (panel && !panel.querySelector(".vortex07-rep-btn-up")) {
    panel.remove();
    panel = null;
  }

  const isNewPanel = !panel;

  if (!panel) {
    panel = document.createElement("div");
    panel.className = "vortex07-reputation-panel";
    panel.dataset.vortex07UserId = String(userId);

    panel.innerHTML = `
      <div class="vortex07-reputation-head">Reputation</div>
      <div class="vortex07-reputation-score">
        <div class="vortex07-rep-score-display">
          <span class="vortex07-rep-count-wrap" aria-live="polite">
            <span class="vortex07-rep-count-sign">+</span><span class="vortex07-rep-count">0</span>
          </span>
          <span class="vortex07-rep-score-icon">${repThumbUpSvg(16)}</span>
        </div>
      </div>
      <div class="vortex07-rep-controls">
        <button type="button" class="vortex07-rep-btn vortex07-rep-btn-up rbx-2007-btn" title="Give +1 rep" aria-label="Give +1 reputation">
          ${repThumbUpSvg(13)}
          <span class="vortex07-rep-btn-label">+1</span>
        </button>
        <button type="button" class="vortex07-rep-btn vortex07-rep-btn-down rbx-2007-btn" title="Remove your rep" aria-label="Remove your reputation">
          ${repThumbDownSvg(13)}
          <span class="vortex07-rep-btn-label">-1</span>
        </button>
      </div>
    `;

    panel.querySelector(".vortex07-rep-btn-up")?.addEventListener("click", async () => {
      if (!isExtensionContextAlive()) {
        maybeShowRefreshBanner();
        return;
      }
      await handleReputationPanelAction(panel, userId, "add");
    });

    panel.querySelector(".vortex07-rep-btn-down")?.addEventListener("click", async () => {
      if (!isExtensionContextAlive()) {
        maybeShowRefreshBanner();
        return;
      }
      await handleReputationPanelAction(panel, userId, "remove");
    });

    header.appendChild(panel);
  } else if (panel.dataset.vortex07UserId !== String(userId)) {
    panel.dataset.vortex07UserId = String(userId);
    lastRepPanelUserId = null;
  }

  if (isNewPanel || lastRepPanelUserId !== userId) {
    lastRepPanelUserId = userId;
    refreshReputationPanel(panel, userId);
    if (isExtensionContextAlive()) syncPendingReputationVotes();
  }

  injectProfileTierFeatures();
}

