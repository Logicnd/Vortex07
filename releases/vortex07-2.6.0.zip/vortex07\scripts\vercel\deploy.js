#!/usr/bin/env node
/**
 * Full Vercel API deploy pipeline: setup → deploy → verify.
 */
const {
  ensureProjectRootDirectory,
  ensureApiLinked,
  npmInstallApi,
  deployProduction,
  PROJECT,
  run,
  REPO_ROOT,
} = require("./config.js");
const { spawnSync } = require("child_process");
const path = require("path");

async function main() {
  console.log("=== Vortex07 API deploy ===\n");

  try {
    const root = await ensureProjectRootDirectory();
    console.log(
      root.changed
        ? `Root directory patched → ${root.rootDirectory}`
        : `Root directory OK (${root.rootDirectory})`,
    );
  } catch (err) {
  const msg = String(err?.message || err);
  if (msg.toLowerCase().includes("not authorized")) {
    console.warn(
      "Skipping Vercel project API patch (token lacks team access). Using linked .vercel/project.json + CLI deploy.",
    );
  } else {
    throw err;
  }
  }

  ensureApiLinked();
  npmInstallApi();

  console.log("\nSyncing Vercel env vars…");
  const envScript = path.join(__dirname, "env.js");
  const envResult = spawnSync(process.execPath, [envScript], {
    stdio: "inherit",
    cwd: REPO_ROOT,
    env: {
      ...process.env,
      NODE_OPTIONS: process.env.NODE_OPTIONS || "--use-system-ca",
    },
  });
  if (envResult.status !== 0) {
    console.warn("Env sync had warnings — continuing deploy.");
  }

  console.log("\nDeploying to production…");
  deployProduction();

  console.log("\nVerifying deployment…");
  const verifyScript = path.join(__dirname, "verify.js");
  const result = spawnSync(process.execPath, [verifyScript], {
    stdio: "inherit",
    env: {
      ...process.env,
      NODE_OPTIONS: process.env.NODE_OPTIONS || "--use-system-ca",
    },
  });

  if (result.status !== 0) {
    process.exit(result.status || 1);
  }

  console.log(`\nLive: ${PROJECT.productionUrl}/api`);
}

main().catch((err) => {
  console.error("Deploy failed:", err.message);
  process.exit(1);
});
