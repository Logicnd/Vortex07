#!/usr/bin/env node
/** Remove local dev bloat (node_modules, staging, old zips). */
const fs = require("fs");
const path = require("path");

const REPO_ROOT = path.resolve(__dirname, "..");

const REMOVE_DIRS = [
  "node_modules",
  "api/node_modules",
  ".pack-staging",
  "dist-store",
  "release",
];

const REMOVE_GLOBS = ["vortex07-*.zip"];

function rmDir(rel) {
  const target = path.join(REPO_ROOT, rel);
  if (!fs.existsSync(target)) return;
  fs.rmSync(target, { recursive: true, force: true });
  console.log(`removed ${rel}/`);
}

function main() {
  for (const dir of REMOVE_DIRS) rmDir(dir);

  for (const name of fs.readdirSync(REPO_ROOT)) {
    if (name.startsWith("vortex07-") && name.endsWith(".zip")) {
      fs.unlinkSync(path.join(REPO_ROOT, name));
      console.log(`removed ${name}`);
    }
  }

  console.log("\nClean. Extension source only (~90 files in git).");
  console.log("Reinstall API deps when needed: npm run api:setup");
}

main();
