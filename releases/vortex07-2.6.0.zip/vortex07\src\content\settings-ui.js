/* Shared Vortex07 settings UI — used on playvortex settings tab. */
(function initVortex07SettingsUi(global) {
  const VORTEX07_JVORTEX_UNLOCK_KEY = "vortex07JVortexUnlocked";

  const VORTEX07_NAV_VISIBLE_DEFAULTS =
    global.Vortex07SettingsSchema?.NAV_VISIBLE_DEFAULTS ?? {
      home: true,
      games: true,
      catalog: true,
      social: true,
      download: true,
      discord: true,
      profile: true,
      forum: true,
      vortex07: true,
      admin: true,
    };

  const VORTEX07_NAV_ITEMS = [
    { key: "home", label: "Home" },
    { key: "games", label: "Games" },
    { key: "catalog", label: "Catalog" },
    { key: "social", label: "Social" },
    { key: "download", label: "Download" },
    { key: "discord", label: "Discord" },
    { key: "profile", label: "My Vortex / profile" },
    { key: "forum", label: "Forum" },
    { key: "vortex07", label: "Settings" },
    { key: "admin", label: "Admin (devs only)" },
  ];

  const VORTEX07_DEFAULT_SETTINGS =
    global.Vortex07SettingsSchema?.DEFAULT_SETTINGS ?? {
      enabled: true,
      customNav: true,
      classicFooter: true,
      retroButtons: true,
      userSearch: true,
      friendRowCarousels: true,
      darkMode: false,
      iconCache: true,
      reputationApiUrl: "",
      showExtensionStatus: true,
      showGuestbook: true,
      showForum: true,
      showActivityTicker: true,
      debugLogs: false,
      johnVortexTheme: false,
      navVisible: { ...VORTEX07_NAV_VISIBLE_DEFAULTS },
    };

  const VORTEX07_CHECKBOX_IDS = [
    "enabled",
    "customNav",
    "classicFooter",
    "retroButtons",
    "userSearch",
    "friendRowCarousels",
    "darkMode",
    "iconCache",
    "showExtensionStatus",
    "showGuestbook",
    "showActivityTicker",
    "debugLogs",
    "johnVortexTheme",
  ];

  const VORTEX07_TEXT_IDS = ["reputationApiUrl"];
  const VORTEX07_DEPENDENT_CHECKBOX_IDS = VORTEX07_CHECKBOX_IDS.filter(
    (id) => id !== "enabled",
  );

  function normalizeNavVisible(settings) {
    if (global.Vortex07SettingsSchema?.normalizeNavVisible) {
      return global.Vortex07SettingsSchema.normalizeNavVisible(settings);
    }
    const raw =
      settings?.navVisible && typeof settings.navVisible === "object"
        ? settings.navVisible
        : {};
    return { ...VORTEX07_NAV_VISIBLE_DEFAULTS, ...raw };
  }

  function normalizeSettings(settings) {
    if (global.Vortex07SettingsSchema?.normalizeSettings) {
      return global.Vortex07SettingsSchema.normalizeSettings(settings, {
        johnVortexUnlocked: isJVortexUnlockedInSettings(),
      });
    }
    const merged = { ...VORTEX07_DEFAULT_SETTINGS, ...(settings || {}) };
    delete merged.reputation;
    delete merged.themePreset;
    merged.navVisible = normalizeNavVisible(merged);
    merged.showForum = merged.navVisible.forum;
    if (!isJVortexUnlockedInSettings()) merged.johnVortexTheme = false;
    return merged;
  }

  function isJVortexUnlockedInSettings() {
    try {
      return sessionStorage.getItem(VORTEX07_JVORTEX_UNLOCK_KEY) === "1";
    } catch {
      return false;
    }
  }

  function buildNavTabGridHtml() {
    return VORTEX07_NAV_ITEMS.map(
      ({ key, label }) => `
        <label class="vortex07-settings-nav-item">
          <input type="checkbox" data-nav-item="${key}" />
          <span>${label}</span>
        </label>
      `,
    ).join("");
  }

  function buildSettingsPageHtml(version) {
    const ver = String(version || "1.1.0");
    return `
      <div class="vortex07-settings-shell">
        <div class="vortex07-settings-titlebar">
          <span class="vortex07-settings-glyph" aria-hidden="true">V07</span>
          <h1 class="vortex07-settings-heading">Vortex07 Settings</h1>
          <span class="vortex07-settings-ver">v${ver}</span>
        </div>

        <div class="vortex07-settings-client">
          <fieldset class="vortex07-settings-group" data-group="general">
            <legend>General</legend>
            <label class="vortex07-settings-row vortex07-settings-row-master">
              <input type="checkbox" id="vortex07-enabled" data-setting="enabled" />
              <span>Enable Vortex07</span>
            </label>
            <p class="vortex07-settings-hint vortex07-settings-off-hint" id="vortex07-enabledHint" hidden>
              Vortex07 is off — check the box above, then refresh playvortex.
            </p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-customNav" data-setting="customNav" />
              <span>Classic navigation tabs</span>
            </label>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-classicFooter" data-setting="classicFooter" />
              <span>Classic footer legalese</span>
            </label>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-retroButtons" data-setting="retroButtons" />
              <span>Windows XP style buttons</span>
            </label>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-darkMode" data-setting="darkMode" />
              <span>Dark mode (retro night theme)</span>
            </label>
          </fieldset>

          <fieldset class="vortex07-settings-group" data-group="navigation">
            <legend>Top bar tabs</legend>
            <p class="vortex07-settings-hint vortex07-settings-group-intro">
              Hide tabs you don't use — the bar auto-shrinks when it gets crowded. Changes apply instantly.
            </p>
            <div class="vortex07-settings-nav-grid">${buildNavTabGridHtml()}</div>
            <div class="vortex07-settings-nav-presets">
              <button type="button" class="vortex07-settings-nav-preset" data-nav-preset="minimal">
                Minimal
              </button>
              <button type="button" class="vortex07-settings-nav-preset" data-nav-preset="default">
                Show all
              </button>
            </div>
            <p class="vortex07-settings-hint" id="vortex07-navTabHint">
              J.Vortex stays hidden until you unlock it from the signal — not listed here.
            </p>
          </fieldset>

          <fieldset class="vortex07-settings-group" data-group="layout">
            <legend>Layout</legend>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-friendRowCarousels" data-setting="friendRowCarousels" />
              <span>Friend row scroll arrows (home &amp; profiles)</span>
            </label>
            <p class="vortex07-settings-hint">Hidden on the dedicated Friends page.</p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-iconCache" data-setting="iconCache" />
              <span>Cache extension badge &amp; logo URLs</span>
            </label>
          </fieldset>

          <fieldset class="vortex07-settings-group" data-group="search">
            <legend>Search</legend>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-userSearch" data-setting="userSearch" />
              <span>Smart player search</span>
            </label>
          </fieldset>

          <fieldset class="vortex07-settings-group" data-group="social">
            <legend>Social features</legend>
            <p class="vortex07-settings-hint vortex07-settings-group-intro">
              Extension-only extras on profiles and home — toggle what you want visible.
            </p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-showExtensionStatus" data-setting="showExtensionStatus" />
              <span>Extension status lines</span>
            </label>
            <p class="vortex07-settings-hint">Shown on profiles, social cards, and search results.</p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-showGuestbook" data-setting="showGuestbook" />
              <span>Profile guestbook</span>
            </label>
            <p class="vortex07-settings-hint">Sign once per day on other players' profiles.</p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-showActivityTicker" data-setting="showActivityTicker" />
              <span>Home activity ticker</span>
            </label>
            <p class="vortex07-settings-hint">Live rep feed on the home page.</p>
          </fieldset>

          <fieldset class="vortex07-settings-group vortex07-settings-secret" data-group="secret" hidden>
            <legend>Secret</legend>
            <p class="vortex07-settings-hint vortex07-settings-group-intro">
              You found J.Vortex. This section is not in the manual.
            </p>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-johnVortexTheme" data-setting="johnVortexTheme" />
              <span>John Vortex theme</span>
            </label>
            <p class="vortex07-settings-hint">
              Hot pink nav, lime hover, cyan panels — early-web chaos. John energy sitewide.
            </p>
          </fieldset>

          <fieldset class="vortex07-settings-group" data-group="dev">
            <legend>Developer</legend>
            <label class="vortex07-settings-row">
              <input type="checkbox" id="vortex07-debugLogs" data-setting="debugLogs" />
              <span>Debug / API console logs</span>
            </label>
            <div class="vortex07-settings-field">
              <label for="vortex07-reputationApiUrl">Rep API override (optional)</label>
              <input
                type="text"
                id="vortex07-reputationApiUrl"
                data-setting="reputationApiUrl"
                placeholder="Default: vortex07.vercel.app/api"
                spellcheck="false"
              />
              <p class="vortex07-settings-hint" id="vortex07-repApiHint">
                Global reputation is always on. Override only for a custom sync server.
              </p>
            </div>
          </fieldset>

          <div class="vortex07-settings-community">
            <span class="vortex07-settings-community-label">Community</span>
            <a
              class="vortex07-settings-wiki"
              href="https://playvortex.wiki/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Official Wiki — guides · lore · game info
            </a>
            <a
              class="vortex07-settings-discord"
              href="https://discord.gg/bVq4fTeDVS"
              target="_blank"
              rel="noopener noreferrer"
            >
              Vortality Discord — updates · support · suggestions
            </a>
          </div>
        </div>

        <div class="vortex07-settings-statusbar">
          <span id="vortex07-saveStatus">Ready</span>
          <span>Changes save automatically</span>
        </div>
      </div>
    `;
  }

  function readSettingsFromRoot(root) {
    const settings = {};

    VORTEX07_CHECKBOX_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) settings[id] = Boolean(input.checked);
    });

    VORTEX07_TEXT_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) settings[id] = String(input.value || "").trim();
    });

    const navVisible = { ...VORTEX07_NAV_VISIBLE_DEFAULTS };
    VORTEX07_NAV_ITEMS.forEach(({ key }) => {
      const input = root.querySelector(`[data-nav-item="${key}"]`);
      if (input) navVisible[key] = Boolean(input.checked);
    });
    settings.navVisible = navVisible;
    settings.showForum = navVisible.forum;

    if (!isJVortexUnlockedInSettings()) {
      settings.johnVortexTheme = false;
    }

    return normalizeSettings(settings);
  }

  function applySettingsToRoot(root, settings) {
    const normalized = normalizeSettings(settings);

    VORTEX07_CHECKBOX_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) input.checked = Boolean(normalized[id]);
    });

    VORTEX07_TEXT_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) input.value = normalized[id] || "";
    });

    VORTEX07_NAV_ITEMS.forEach(({ key }) => {
      const input = root.querySelector(`[data-nav-item="${key}"]`);
      if (input) input.checked = normalized.navVisible[key] !== false;
    });

    applyMasterToggleState(root, normalized);
    updateRepApiHint(root, normalized);
    updateNavTabHint(root, normalized);
    syncSecretSection(root, normalized);
    return normalized;
  }

  function syncSecretSection(root, settings = null) {
    const secret = root.querySelector('[data-group="secret"]');
    if (!secret) return;

    const unlocked = isJVortexUnlockedInSettings();
    secret.hidden = !unlocked;

    const enabled = settings ? Boolean(settings.enabled) : true;
    const johnInput = root.querySelector('[data-setting="johnVortexTheme"]');
    if (johnInput) {
      johnInput.disabled = !enabled || !unlocked;
      if (!unlocked) johnInput.checked = false;
    }
  }

  function updateNavTabHint(root, settings) {
    const hint = root.querySelector("#vortex07-navTabHint");
    if (!hint) return;
    const visible = VORTEX07_NAV_ITEMS.filter(
      ({ key }) => settings.navVisible?.[key] !== false,
    ).length;
    hint.textContent = `${visible} tab${visible === 1 ? "" : "s"} visible in the top bar. J.Vortex stays hidden until you unlock it from the signal.`;
  }

  function applyNavPreset(root, preset) {
    const minimal = {
      home: true,
      games: true,
      social: true,
      profile: true,
      vortex07: true,
      catalog: false,
      download: false,
      discord: false,
      forum: false,
      admin: false,
    };

    VORTEX07_NAV_ITEMS.forEach(({ key }) => {
      const input = root.querySelector(`[data-nav-item="${key}"]`);
      if (!input) return;
      if (preset === "minimal") {
        input.checked = minimal[key] !== false;
        return;
      }
      input.checked = true;
    });
  }

  function applyMasterToggleState(root, settings) {
    const enabled = Boolean(settings.enabled);
    const shell = root.querySelector(".vortex07-settings-shell");
    const enabledHint = root.querySelector("#vortex07-enabledHint");

    VORTEX07_DEPENDENT_CHECKBOX_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) input.disabled = !enabled;
    });

    VORTEX07_TEXT_IDS.forEach((id) => {
      const input = root.querySelector(`[data-setting="${id}"]`);
      if (input) input.disabled = !enabled;
    });

    root.querySelectorAll("[data-nav-item]").forEach((input) => {
      input.disabled = !enabled;
    });

    root.querySelectorAll("[data-nav-preset]").forEach((btn) => {
      btn.disabled = !enabled;
    });

    shell?.classList.toggle("vortex07-settings-off", !enabled);
    if (enabledHint) enabledHint.hidden = enabled;
  }

  function updateRepApiHint(root, settings) {
    const hint = root.querySelector("#vortex07-repApiHint");
    if (!hint) return;

    const url = String(settings.reputationApiUrl || "").trim();
    if (!url) {
      hint.textContent =
        "Global rep sync: vortex07.vercel.app — shared by all Vortex07 users.";
      return;
    }

    hint.textContent = `Custom sync via ${url.replace(/^https?:\/\//, "")}`;
  }

  function setSaveStatus(root, text, type) {
    const el = root.querySelector("#vortex07-saveStatus");
    if (!el) return;

    el.textContent = text;
    el.classList.remove("save-ok", "save-err");
    if (type) el.classList.add(type);
  }

  function saveSettingsFromRoot(root) {
    const settings = readSettingsFromRoot(root);
    applyMasterToggleState(root, settings);
    updateRepApiHint(root, settings);
    updateNavTabHint(root, settings);
    syncSecretSection(root, settings);

    const save = global.Vortex07Ext?.storageSet;
    if (typeof save !== "function") {
      setSaveStatus(root, "Save failed", "save-err");
      return;
    }

    save("sync", { vortex07Settings: settings })
      .then(() => {
        setSaveStatus(
          root,
          settings.enabled ? "Settings saved" : "Disabled — refresh tab",
          "save-ok",
        );
      })
      .catch(() => {
        setSaveStatus(root, "Save failed", "save-err");
      });
  }

  function loadSettings(callback) {
    const load = global.Vortex07Ext?.storageGet;
    if (typeof load !== "function") {
      callback(normalizeSettings(VORTEX07_DEFAULT_SETTINGS));
      return;
    }

    load("sync", { vortex07Settings: VORTEX07_DEFAULT_SETTINGS })
      .then((data) => {
        callback(normalizeSettings(data.vortex07Settings));
      })
      .catch(() => {
        callback(normalizeSettings(VORTEX07_DEFAULT_SETTINGS));
      });
  }

  function wireSettingsPage(root) {
    if (!root || root.dataset.vortex07SettingsWired === "true") return;
    root.dataset.vortex07SettingsWired = "true";

    let saveTimer = null;
    const queueSave = () => {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => saveSettingsFromRoot(root), 120);
    };

    root.querySelectorAll('[data-setting]').forEach((input) => {
      input.addEventListener("change", queueSave);
      if (input.type === "text") input.addEventListener("input", queueSave);
    });

    root.querySelectorAll("[data-nav-item]").forEach((input) => {
      input.addEventListener("change", queueSave);
    });

    root.querySelectorAll("[data-nav-preset]").forEach((btn) => {
      btn.addEventListener("click", () => {
        applyNavPreset(root, btn.dataset.navPreset);
        queueSave();
      });
    });

    root.querySelector('[data-setting="enabled"]')?.addEventListener("change", () => {
      const live = readSettingsFromRoot(root);
      applyMasterToggleState(root, live);
      syncSecretSection(root, live);
    });

    document.addEventListener("vortex07-jvortex-unlocked", () => {
      syncSecretSection(root, readSettingsFromRoot(root));
    });

    global.Vortex07Ext?.onStorageChanged?.((changes, namespace) => {
      if (namespace === "sync" && changes.vortex07Settings) {
        applySettingsToRoot(root, normalizeSettings(changes.vortex07Settings.newValue));
      }
    });
  }

  function mountSettingsPage(root, version) {
    root.innerHTML = buildSettingsPageHtml(version);
    wireSettingsPage(root);
    loadSettings((settings) => {
      applySettingsToRoot(root, settings);
    });
  }

  global.Vortex07SettingsUi = {
    DEFAULT_SETTINGS: VORTEX07_DEFAULT_SETTINGS,
    normalizeSettings,
    buildSettingsPageHtml,
    mountSettingsPage,
    applySettingsToRoot,
    loadSettings,
    syncSecretSection: (root) => {
      if (!root) return;
      syncSecretSection(root, readSettingsFromRoot(root));
    },
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
