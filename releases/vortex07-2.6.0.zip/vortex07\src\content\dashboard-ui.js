/* Vortex07 developer admin — extension devs only. */
(function initVortex07DashboardUi(global) {
  const DEVELOPER_IDS = [15936, 18202];

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function buildDashboardHtml(version, session) {
    const ver = escapeHtml(version || "1.2.0");
    const name = session?.username ? `@${escapeHtml(session.username)}` : "Developer";
    const userId = session?.id ?? "—";

    return `
      <div class="vortex07-dashboard-shell">
        <div class="vortex07-dashboard-titlebar">
          <span class="vortex07-dashboard-glyph" aria-hidden="true">ADM</span>
          <h1 class="vortex07-dashboard-heading">Vortex07 Admin</h1>
          <span class="vortex07-dashboard-ver">v${ver}</span>
        </div>

        <div class="vortex07-dashboard-client">
          <fieldset class="vortex07-dashboard-group vortex07-dashboard-session-group">
            <legend>Session</legend>
            <p class="vortex07-dashboard-lead">
              Signed in as <strong>${name}</strong> (ID ${escapeHtml(userId)}) — developer access.
            </p>
            <p class="vortex07-dashboard-stat" id="vortex07-dashStatApi">API: checking…</p>
          </fieldset>

          <fieldset class="vortex07-dashboard-group">
            <legend>Stats</legend>
            <p class="vortex07-dashboard-stat" id="vortex07-dashStatVersion">Extension: v${ver}</p>
            <p class="vortex07-dashboard-stat" id="vortex07-dashStatTeam">Team: ${DEVELOPER_IDS.length} developers</p>
            <p class="vortex07-dashboard-stat" id="vortex07-dashStatSearch">Last search: —</p>
            <p class="vortex07-dashboard-stat" id="vortex07-dashStatRep">Rep cache: —</p>
          </fieldset>

          <fieldset class="vortex07-dashboard-group vortex07-dashboard-audit-group">
            <legend>Rep audit</legend>
            <p class="vortex07-dashboard-hint">
              Vote log from the API — spikes flag botting. Usernames resolve via playvortex.io.
            </p>
            <div class="vortex07-dashboard-audit-controls">
              <label class="vortex07-dashboard-audit-filter">
                <span>Filter (ID or @username)</span>
                <input type="text" id="vortex07-dashAuditFilter" placeholder="All users" spellcheck="false" autocomplete="off" />
              </label>
              <button type="button" class="vortex07-dashboard-btn" data-dash-action="refresh-audit">
                Refresh log
              </button>
              <button type="button" class="vortex07-dashboard-btn" data-dash-action="copy-audit">
                Copy JSON
              </button>
            </div>
            <div class="vortex07-dashboard-audit-spikes" id="vortex07-dashAuditSpikes" hidden></div>
            <div class="vortex07-dashboard-audit-table-wrap">
              <table class="vortex07-dashboard-audit-table">
                <thead>
                  <tr>
                    <th>Time</th>
                    <th>Actor</th>
                    <th>Target</th>
                    <th>Δ</th>
                  </tr>
                </thead>
                <tbody id="vortex07-dashAuditBody">
                  <tr><td colspan="4" class="vortex07-dashboard-audit-loading">Loading audit log…</td></tr>
                </tbody>
              </table>
            </div>
          </fieldset>

          <fieldset class="vortex07-dashboard-group">
            <legend>Top Players</legend>
            <ol class="vortex07-dashboard-leaderboard" id="vortex07-dashLeaderboard">
              <li class="vortex07-dashboard-leaderboard-loading">Loading leaderboard…</li>
            </ol>
          </fieldset>

          <fieldset class="vortex07-dashboard-group">
            <legend>Quick actions</legend>
            <div class="vortex07-dashboard-actions">
              <button type="button" class="vortex07-dashboard-btn" data-dash-action="settings">
                Vortex07 Settings
              </button>
              <button type="button" class="vortex07-dashboard-btn" data-dash-action="clear-rep-cache">
                Clear rep cache
              </button>
              <button type="button" class="vortex07-dashboard-btn" data-dash-action="reload">
                Reload page
              </button>
            </div>
            <p class="vortex07-dashboard-hint" id="vortex07-dashStatus">Ready.</p>
          </fieldset>
        </div>

        <div class="vortex07-dashboard-statusbar">
          <span>/admin#vortex07-dashboard</span>
          <span>Dev IDs: ${DEVELOPER_IDS.join(", ")}</span>
        </div>
      </div>
    `;
  }

  let lastAuditPayload = null;
  let auditFilterTimer = null;

  function collectAuditUserIds(events, spikes) {
    const ids = new Set();
    (events || []).forEach((event) => {
      if (event?.actorUserId) ids.add(Number(event.actorUserId));
      if (event?.targetUserId) ids.add(Number(event.targetUserId));
    });
    (spikes || []).forEach((row) => {
      if (row?.targetUserId) ids.add(Number(row.targetUserId));
    });
    return [...ids].filter((id) => Number.isFinite(id) && id > 0);
  }

  function formatDelta(event) {
    const delta = Number(event?.delta) || 0;
    if (event?.kind === "admin_purge") {
      return `PURGE ${delta}`;
    }
    return delta > 0 ? `+${delta}` : String(delta);
  }

  function appendUserCell(row, userId, usersMap) {
    const td = document.createElement("td");
    const id = Number(userId);
    if (!Number.isFinite(id) || id <= 0) {
      td.textContent = id === 0 ? "admin" : "—";
      row.appendChild(td);
      return;
    }

    const player = usersMap?.get(id);
    const username = player?.username;
    if (username) {
      const link = document.createElement("a");
      link.className = "vortex07-dashboard-user-link";
      link.href = `/users/${id}/profile`;
      link.textContent = `@${username}`;
      td.appendChild(link);
      const meta = document.createElement("span");
      meta.className = "vortex07-dashboard-user-id";
      meta.textContent = ` (${id})`;
      td.appendChild(meta);
    } else {
      td.textContent = String(id);
    }
    row.appendChild(td);
  }

  function renderAuditSpikes(root, spikes, usersMap) {
    const el = root.querySelector("#vortex07-dashAuditSpikes");
    if (!el) return;

    if (!spikes?.length) {
      el.hidden = true;
      el.textContent = "";
      return;
    }

    el.hidden = false;
    el.innerHTML = `<strong>Spike alerts:</strong> ${spikes
      .map((row) => {
        const id = Number(row.targetUserId);
        const player = usersMap?.get(id);
        const label = player?.username ? `@${player.username}` : `User ${id}`;
        return `${label} +${row.count} votes / 10 min`;
      })
      .join(" · ")}`;
  }

  function renderAuditRows(root, events, emptyMessage, usersMap) {
    const body = root.querySelector("#vortex07-dashAuditBody");
    if (!body) return;

    body.textContent = "";
    if (!events?.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");
      cell.colSpan = 4;
      cell.className = "vortex07-dashboard-audit-empty";
      cell.textContent = emptyMessage || "No audit events yet.";
      row.appendChild(cell);
      body.appendChild(row);
      return;
    }

    events.forEach((event) => {
      const row = document.createElement("tr");
      if (event?.kind === "admin_purge") {
        row.classList.add("vortex07-dashboard-audit-row-purge");
      }

      const at = Number(event.at) || 0;
      const timeCell = document.createElement("td");
      timeCell.textContent = at ? new Date(at).toLocaleString() : "—";
      row.appendChild(timeCell);

      appendUserCell(row, event.actorUserId, usersMap);
      appendUserCell(row, event.targetUserId, usersMap);

      const deltaCell = document.createElement("td");
      deltaCell.textContent = formatDelta(event);
      row.appendChild(deltaCell);

      body.appendChild(row);
    });
  }

  async function resolveUsersForDashboard(userIds, options = {}) {
    const api = global.Vortex07Api;
    if (!api?.fetchPlayvortexUsersByIds || !userIds.length) {
      return new Map();
    }
    try {
      const timeoutMs = options.timeoutMs || 6000;
      return await Promise.race([
        api.fetchPlayvortexUsersByIds(userIds, { force: false }),
        new Promise((resolve) => {
          setTimeout(() => resolve(new Map()), timeoutMs);
        }),
      ]);
    } catch {
      return new Map();
    }
  }

  async function loadRepAudit(root) {
    const filterInput = root.querySelector("#vortex07-dashAuditFilter");
    const targetRaw = String(filterInput?.value || "").trim();
    const api = global.Vortex07Api;
    const contextDead = global.Vortex07Ext?.isContextAlive?.() === false;
    const staleHint =
      "Vortex07 was reloaded — refresh this page (F5), then open Admin again.";

    if (contextDead) {
      renderAuditRows(root, [], staleHint, new Map());
      renderAuditSpikes(root, [], new Map());
      return;
    }

    if (!api?.fetchRepAudit) {
      renderAuditRows(root, [], "Audit API unavailable.", new Map());
      renderAuditSpikes(root, [], new Map());
      return;
    }

    renderAuditRows(root, [], "Loading audit log…", new Map());
    renderAuditSpikes(root, [], new Map());

    let targetUserId;
    if (/^\d+$/.test(targetRaw)) {
      targetUserId = targetRaw;
    } else if (targetRaw && api.resolveDashboardUserInput) {
      const resolved = await api.resolveDashboardUserInput(targetRaw);
      if (resolved === null) {
        renderAuditRows(root, [], `No user found for "${targetRaw}".`, new Map());
        renderAuditSpikes(root, [], new Map());
        return;
      }
      targetUserId = String(resolved);
      if (filterInput) filterInput.value = targetUserId;
    }

    try {
      const payload = await api.fetchRepAudit({ limit: 100, targetUserId });
      if (!payload) {
        lastAuditPayload = null;
        const hint =
          global.Vortex07Ext?.isContextAlive?.() === false
            ? staleHint
            : "Could not load audit log — reload the page, or run npm run api:deploy if endpoints are missing.";
        renderAuditRows(root, [], hint, new Map());
        renderAuditSpikes(root, [], new Map());
        return;
      }

      lastAuditPayload = payload;
      const events = payload?.events || [];
      const spikes = payload?.spikes || [];
      const usersMap = await resolveUsersForDashboard(
        collectAuditUserIds(events, spikes),
      );
      renderAuditRows(root, events, "No audit events yet.", usersMap);
      renderAuditSpikes(root, spikes, usersMap);
    } catch {
      lastAuditPayload = null;
      renderAuditRows(root, [], "Could not load audit log.", new Map());
      renderAuditSpikes(root, [], new Map());
    }
  }

  function updateDashboardStats(root) {
    const searchEl = root.querySelector("#vortex07-dashStatSearch");
    const repEl = root.querySelector("#vortex07-dashStatRep");

    global.Vortex07Ext?.storageGet?.(
      "local",
      ["vortex07LastPlayerSearch", "vortex07ReputationCache"],
    ).then((data) => {
        const last = data?.vortex07LastPlayerSearch;
        if (last?.query) {
          const when = last.savedAt
            ? new Date(last.savedAt).toLocaleString()
            : "recently";
          searchEl.textContent = `Last search: "${last.query}" · ${when}`;
        } else {
          searchEl.textContent = "Last search: —";
        }

        const cache = data?.vortex07ReputationCache;
        const count =
          cache && typeof cache === "object" ? Object.keys(cache).length : 0;
        repEl.textContent = `Rep cache: ${count} user${count === 1 ? "" : "s"}`;
    }).catch(() => {
      searchEl.textContent = "Last search: —";
      repEl.textContent = "Rep cache: —";
    });
  }

  async function updateApiStatus(root) {
    const el = root.querySelector("#vortex07-dashStatApi");
    if (!el) return;

    const api = global.Vortex07Api;
    if (!api?.fetchAdminApiStatus) {
      el.textContent = "API: status probe unavailable";
      return;
    }

    el.textContent = "API: checking…";
    const status = await api.fetchAdminApiStatus();
    const base = status.api || api.getApiBase?.() || "—";

    if (!status.ok) {
      el.textContent = `API: offline (${status.reason}) · ${base}`;
      el.classList.add("vortex07-dashboard-stat-bad");
      return;
    }

    if (status.admin) {
      el.textContent = `API: online · admin auth OK · ${base}`;
      el.classList.remove("vortex07-dashboard-stat-bad");
      el.classList.add("vortex07-dashboard-stat-good");
      return;
    }

    el.textContent = `API: online · admin auth failed (${status.reason}) · ${base}`;
    el.classList.add("vortex07-dashboard-stat-bad");
    el.classList.remove("vortex07-dashboard-stat-good");
  }

  function renderLeaderboardRows(root, rows, avatars, usersMap) {
    const list = root.querySelector("#vortex07-dashLeaderboard");
    if (!list) return;

    list.textContent = "";
    if (!rows.length) {
      const empty = document.createElement("li");
      empty.className = "vortex07-dashboard-leaderboard-empty";
      empty.textContent = "No leaderboard data yet.";
      list.appendChild(empty);
      return;
    }

    rows.forEach((row, index) => {
      const userId = Number(row.userId);
      if (!Number.isFinite(userId)) return;

      const li = document.createElement("li");
      li.className = "vortex07-dashboard-leaderboard-row";

      const rank = document.createElement("span");
      rank.className = "vortex07-dashboard-leaderboard-rank";
      rank.textContent = String(index + 1);

      const avatar = document.createElement("img");
      avatar.className = "vortex07-dashboard-leaderboard-avatar";
      avatar.alt = "";
      avatar.loading = "lazy";
      avatar.src =
        avatars?.get?.(userId) ||
        "https://playvortex.io/images/placeholder-avatar.png";

      const name = document.createElement("a");
      name.className = "vortex07-dashboard-leaderboard-name";
      name.href = `/users/${userId}/profile`;
      const player = usersMap?.get(userId);
      name.textContent = player?.username
        ? `@${player.username}`
        : `User ${userId}`;

      const count = document.createElement("span");
      count.className = "vortex07-dashboard-leaderboard-count";
      count.textContent = String(Number(row.count) || 0);

      li.append(rank, avatar, name, count);
      list.appendChild(li);
    });
  }

  function loadDashboardLeaderboard(root) {
    const api = global.Vortex07Api;
    const fetchRows = api?.fetchDashboardLeaderboard || api?.fetchLeaderboard;
    if (!fetchRows) {
      renderLeaderboardRows(root, [], new Map(), new Map());
      return;
    }

    void (async () => {
      try {
        const rows = await fetchRows(25);
        renderLeaderboardRows(root, rows, new Map(), new Map());

        if (!rows.length) return;

        const ids = rows.map((row) => row.userId);
        const enrichTimeout = 8000;
        const [avatars, usersMap] = await Promise.all([
          api.fetchPlayerAvatars
            ? Promise.race([
                api.fetchPlayerAvatars(ids, { userInitiated: true }),
                new Promise((resolve) => setTimeout(() => resolve(new Map()), enrichTimeout)),
              ])
            : Promise.resolve(new Map()),
          resolveUsersForDashboard(ids, { timeoutMs: enrichTimeout }),
        ]);
        renderLeaderboardRows(root, rows, avatars, usersMap);
      } catch {
        renderLeaderboardRows(root, [], new Map(), new Map());
      }
    })();
  }

  function refreshDashboardData(root) {
    updateDashboardStats(root);
    void updateApiStatus(root);
    loadDashboardLeaderboard(root);
    loadRepAudit(root);
  }

  function wireDashboardPage(root) {
    if (!root || root.dataset.vortex07DashboardWired === "true") return;
    root.dataset.vortex07DashboardWired = "true";

    const statusEl = root.querySelector("#vortex07-dashStatus");

    root.querySelectorAll("[data-dash-action]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const action = btn.dataset.dashAction;
        if (action === "settings") {
          window.location.href = "/home#vortex07-settings";
          if (statusEl) statusEl.textContent = "Opened Vortex07 Settings.";
          return;
        }
        if (action === "refresh-audit") {
          refreshDashboardData(root);
          if (statusEl) statusEl.textContent = "Admin panel refreshed.";
          return;
        }
        if (action === "copy-audit") {
          const text = JSON.stringify(lastAuditPayload || {}, null, 2);
          void navigator.clipboard?.writeText(text).then(() => {
            if (statusEl) statusEl.textContent = "Audit JSON copied.";
          });
          return;
        }
        if (action === "clear-rep-cache") {
          global.Vortex07Ext?.storageRemove?.(
            "local",
            ["vortex07ReputationCache", "vortex07ReputationPending"],
          ).then(() => {
            if (statusEl) statusEl.textContent = "Reputation cache cleared.";
            updateDashboardStats(root);
          });
          return;
        }
        if (action === "reload") {
          window.location.reload();
        }
      });
    });

    root.querySelector("#vortex07-dashAuditFilter")?.addEventListener("input", () => {
      if (auditFilterTimer) clearTimeout(auditFilterTimer);
      auditFilterTimer = setTimeout(() => loadRepAudit(root), 400);
    });

    root.querySelector("#vortex07-dashAuditFilter")?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        loadRepAudit(root);
      }
    });

    refreshDashboardData(root);
  }

  function mountDashboardPage(root, version, session) {
    root.innerHTML = buildDashboardHtml(version, session);
    delete root.dataset.vortex07DashboardWired;
    wireDashboardPage(root, session);
  }

  global.Vortex07DashboardUi = {
    DEVELOPER_IDS,
    mountDashboardPage,
    updateDashboardStats,
    refreshDashboardData,
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
