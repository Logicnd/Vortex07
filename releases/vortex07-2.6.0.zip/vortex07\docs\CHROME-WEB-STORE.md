# Chrome Web Store — Listing Copy

Ready-to-paste text for the CWS Developer Dashboard.  
See [CWS upload checklist](#upload-checklist) at the bottom for what to attach.

---

## Name

```
Vortex07
```

*(8 chars — well within the 45-char limit)*

---

## Summary (short description — 132 char max)

```
Restyles playvortex.io as a 2006–2007 Roblox classic — search, global rep, forum, guestbook, badges, and dark mode.
```

*(117 chars)*

---

## Detailed Description

```
Vortex07 transforms playvortex.io into a faithful recreation of the 2006–2008 Roblox look and feel — complete with the XP Luna chrome, retro nav, and era-appropriate typography — while adding community features that never existed in the original.

─────────────────────────────
FEATURES
─────────────────────────────

🔍 PLAYER SEARCH
Live fuzzy-match search in the top nav. Find any player by username, view their profile, check their rep score, and add them from a single dropdown — no page reload required.

⭐ GLOBAL REPUTATION SYSTEM
Give (or remove) a reputation point on any player's profile. Points are account-bound and HMAC-signed so duplicate voting is blocked server-side. A leaderboard shows the top-rated community members.

💬 COMMUNITY FORUM
A lightweight threaded forum embedded directly on playvortex.io. Post threads, reply, and like posts without leaving the site. Accessible via the nav or the #vortex07-forum hash.

📖 GUESTBOOK
Leave a short message on any player's profile. Classic 2006-era guestbook experience.

🏅 BADGES
Staff, Developer, Owner, and Booster badges rendered on profiles and in search results. Auto-detected from the Vortex API — no configuration required.

👥 FRIENDS CAROUSEL
Friends rows on home and profile pages are paginated (10 per page) with left/right arrows. Avoids the infinite scroll soup of the modern site.

🌙 DARK MODE (RETRO NIGHT)
Full token-driven dark palette — zero white panels, zero white inputs. Toggle in the popup or at /home#vortex07-settings. All UI surfaces, inputs, modals, forum, and dashboard follow the same dark tokens.

🎨 JOHN VORTEX THEME (Easter egg)
Unlock a Windows 95-inspired joke skin. Classic.

🛡 PRIVACY-FIRST DESIGN
No account login required. An anonymous voter ID (random UUID) is stored locally to de-duplicate rep votes. No user data is sent anywhere except to the official vortex07.vercel.app API that powers the community features.

─────────────────────────────
HOW IT WORKS
─────────────────────────────

The extension runs only on playvortex.io (and localhost for development). It injects a stylesheet that replaces the modern flat UI with the retro shell, then adds the custom nav, search box, and community panels via content scripts. The background service worker proxies HMAC-signed reputation API calls so the secret never leaves your browser.

─────────────────────────────
PERMISSIONS EXPLAINED
─────────────────────────────

• storage — saves your settings (dark mode, enabled/disabled toggles) and a voter ID for rep de-duplication
• tabs — detects page navigation to re-apply the shell on SPA route changes
• playvortex.io — the only host where the extension activates
• vortex07.vercel.app — the community API for rep, forum, guestbook, and leaderboard

─────────────────────────────
OPEN SOURCE
─────────────────────────────

Source code is available on GitHub. Contributions welcome.
```

---

## Category

**Appearance**

*(alt: Social & Communication — either fits)*

---

## Language

English

---

## Screenshots — Required (1280×800 px recommended, min 640×400)

Take at least **3 screenshots** on [playvortex.io](https://playvortex.io) with the extension active.

| # | Page | What to show |
|---|------|-------------|
| 1 | `/home` | Full 2007 shell — nav bar, friends carousel, search box visible |
| 2 | Profile page | Player profile with reputation panel, badges, guestbook |
| 3 | `/home` dark mode | Same home view with dark mode toggled on — use this to show the retro night palette |
| 4 | `/home#vortex07-forum` | Forum tab — thread list or open thread |
| 5 | Player search dropdown | Search dropdown open with results + badges visible |

**Tips:**
- Use Chrome DevTools device toolbar at 1280×800 for consistent framing.
- Zoom the browser to 100% before screenshotting.
- The retro shell looks best at 1280 px wide — don't take screenshots at phone widths.

---

## Promotional Images (optional but recommended)

| Size | Use |
|------|-----|
| 440×280 px | Small promo tile (shown in search results) |
| 920×680 px | Large promo tile (featured carousel if ever picked) |

**Suggested content:** A split image — left half light mode home page, right half dark mode — with the Vortex logo centred and the tagline *"playvortex.io — as it was meant to be."*

---

## Store Icon

`assets/icons/icon128.png` — 128×128 px PNG ✓  
*(Fixed in v2.6.0 — previously was a 1024×1024 file; now correctly sized)*

---

## Privacy Policy

CWS **requires** a privacy policy URL because the extension uses `storage`.

Create a simple one-page policy covering:
- What data is stored: extension settings (sync storage), an anonymous voter UUID (local storage)
- What is sent to vortex07.vercel.app: voter UUID, user ID of the target player — no name, no email
- No data is sold or shared with third parties
- Data can be cleared by removing the extension

Host it at a stable URL (GitHub Pages, or a `/privacy` page on your domain) and paste that URL into the **Privacy practices** field in the CWS dashboard.

---

## Upload Checklist

- [ ] Name: `Vortex07`
- [ ] Summary: paste from above
- [ ] Description: paste from above
- [ ] Category: **Appearance**
- [ ] Store icon: `assets/icons/icon128.png` (128×128 ✓)
- [ ] Screenshots: 3–5 at 1280×800 (see table above)
- [ ] Promo tile: 440×280 (optional)
- [ ] Website URL: your GitHub repo URL
- [ ] Privacy policy URL: hosted policy page (required)
- [ ] Single-purpose description: *"Restyles playvortex.io with a retro 2006–2007 theme and adds community features."*
- [ ] Justified permissions explanation: add one line per permission (see "Permissions Explained" section above)
