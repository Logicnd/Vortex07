#!/usr/bin/env node
/**
 * Build a clean extension zip for sharing (manifest + assets + src only).
 */
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const REPO_ROOT = path.resolve(__dirname, "..");
const STAGE = path.join(REPO_ROOT, ".pack-staging");
const manifest = JSON.parse(
  fs.readFileSync(path.join(REPO_ROOT, "manifest.json"), "utf8"),
);
const version = manifest.version || "0.0.0";
const zipName = `vortex07-${version}.zip`;
const zipPath = path.join(REPO_ROOT, "release", zipName);

function assetDir() {
  const lower = path.join(REPO_ROOT, "assets");
  const upper = path.join(REPO_ROOT, "Assets");
  if (fs.existsSync(lower)) return lower;
  if (fs.existsSync(upper)) return upper;
  throw new Error("Missing assets/ folder");
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const from = path.join(src, entry.name);
    const to = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(from, to);
    else fs.copyFileSync(from, to);
  }
}

function main() {
  if (fs.existsSync(STAGE)) fs.rmSync(STAGE, { recursive: true, force: true });
  fs.mkdirSync(STAGE, { recursive: true });
  fs.mkdirSync(path.join(REPO_ROOT, "release"), { recursive: true });

  fs.copyFileSync(path.join(REPO_ROOT, "manifest.json"), path.join(STAGE, "manifest.json"));
  copyDir(assetDir(), path.join(STAGE, "assets"));
  copyDir(path.join(REPO_ROOT, "src"), path.join(STAGE, "src"));

  if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

  if (process.platform === "win32") {
    spawnSync(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        `Compress-Archive -Path '${STAGE}\\*' -DestinationPath '${zipPath}' -Force`,
      ],
      { stdio: "inherit", shell: false },
    );
  } else {
    spawnSync("zip", ["-r", zipPath, "."], { cwd: STAGE, stdio: "inherit" });
  }

  fs.rmSync(STAGE, { recursive: true, force: true });

  if (!fs.existsSync(zipPath)) throw new Error("Zip creation failed");

  const kb = (fs.statSync(zipPath).size / 1024).toFixed(1);
  console.log(`Built: release/${zipName} (${kb} KB)`);
  console.log("Share that zip — recipients unzip and Load unpacked in chrome://extensions");
}

main();
