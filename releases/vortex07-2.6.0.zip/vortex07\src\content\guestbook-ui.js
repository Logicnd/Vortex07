// Vortex07 guestbook-ui.js — Profile guestbook, activity ticker, home leaderboard strip, global rep badges.
// Shares scope with content.js.

/* ========================================================= */
/* = SOCIAL HEAT (v1.12.0) — guestbook + activity ticker === */
/* ========================================================= */

function getGuestbookAnchor() {
  const page = document.querySelector("#Body > .page:has(.profile-header), #Body > .page:has(.vortex07-profile-header)");
  if (!page) return null;

  return (
    page.querySelector(".bio-box") ||
    page.querySelector(".profile-info-panel") ||
    page.querySelector(".friends-section") ||
    page.querySelector(".profile-header")
  );
}

function mountGuestbookSection(section, anchor) {
  const page = anchor?.closest(".page");
  const bio = page?.querySelector(".bio-box");
  if (bio) {
    bio.insertAdjacentElement("afterend", section);
    return;
  }
  anchor.insertAdjacentElement("beforebegin", section);
}

function formatGuestbookDate(timestamp) {
  const date = new Date(Number(timestamp) || Date.now());
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}

async function fetchGuestbookEntries(profileUserId, limit = 20) {
  const id = safeNumber(profileUserId);
  if (id === null) return [];

  const apiBase = getVortex07ApiBase();
  if (!apiBase || !isRepApiAvailable() || shouldSkipNonEssentialPolling()) {
    return [];
  }

  try {
    const voterId = await ensureVoterId();
    const url = `${apiBase}/guestbook?profileUserId=${encodeURIComponent(id)}&voterId=${encodeURIComponent(voterId)}&limit=${encodeURIComponent(limit)}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    return Array.isArray(json.entries) ? json.entries : [];
  } catch (err) {
    logRepFailureOnce("Guestbook fetch failed:", err);
    return [];
  }
}

function getForumAuthorInfo() {
  const session = cachedSessionUser || getSessionUserFromNav();
  const userId = getCurrentUserId();
  const authorName =
    safeString(session?.username) || (userId !== null ? `Player ${userId}` : "Guest");
  return {
    authorUserId: userId,
    authorName,
  };
}

function collectForumUserIds(...groups) {
  const ids = new Set();
  groups.flat().forEach((row) => {
    const id = safeNumber(row?.authorUserId);
    if (id !== null) ids.add(id);
  });
  return [...ids];
}

async function hydrateForumProfiles(userIds, authorsFromApi = {}) {
  const ids = [...new Set(userIds.map((id) => safeNumber(id)).filter((id) => id !== null))];
  if (!ids.length) {
    return { authors: { ...authorsFromApi }, avatars: {} };
  }

  const avatarMap = await fetchPlayerAvatars(ids, { userInitiated: true });
  const avatars = {};
  avatarMap.forEach((url, id) => {
    if (url) avatars[String(id)] = url;
  });

  return {
    authors: { ...authorsFromApi },
    avatars,
  };
}

async function fetchForumFeed(categoryId = "general", limit = 30, offset = 0) {
  const apiBase = getVortex07ApiBase();
  if (!apiBase) return { threads: [], authors: {}, avatars: {} };

  try {
    const voterId = await ensureVoterId();
    const url =
      `${apiBase}/forum?action=feed&category=${encodeURIComponent(categoryId)}` +
      `&limit=${encodeURIComponent(limit)}&offset=${encodeURIComponent(offset)}` +
      `&voterId=${encodeURIComponent(voterId)}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
      force: true,
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    const threads = Array.isArray(json.threads) ? json.threads : [];
    const profiles = await hydrateForumProfiles(
      collectForumUserIds(threads),
      json.authors || {},
    );
    return { threads, ...profiles };
  } catch (err) {
    logRepFailureOnce("Forum feed fetch failed:", err);
    return { threads: [], authors: {}, avatars: {} };
  }
}

async function fetchForumThreads(categoryId = "general", limit = 30, offset = 0) {
  const feed = await fetchForumFeed(categoryId, limit, offset);
  return feed.threads || [];
}

async function fetchForumThread(threadId) {
  const id = safeString(threadId);
  if (!id) return null;

  const apiBase = getVortex07ApiBase();
  if (!apiBase) return null;

  try {
    const voterId = await ensureVoterId();
    const url =
      `${apiBase}/forum?action=thread&threadId=${encodeURIComponent(id)}` +
      `&voterId=${encodeURIComponent(voterId)}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
      force: true,
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    const profiles = await hydrateForumProfiles(
      collectForumUserIds([json.thread, ...(json.posts || [])]),
      json.authors || {},
    );
    return { ...json, ...profiles };
  } catch (err) {
    logRepFailureOnce("Forum thread fetch failed:", err);
    return null;
  }
}

async function createForumThread({ categoryId, title, body }) {
  const apiBase = getVortex07ApiBase();
  if (!apiBase) return { ok: false, reason: "no-api" };

  const cleanTitle = safeString(title).slice(0, 120);
  const cleanBody = safeString(body).slice(0, 1000);
  if (!cleanTitle || !cleanBody) return { ok: false, reason: "empty" };

  try {
    const voterId = await ensureVoterId();
    const author = getForumAuthorInfo();
    const response = await fetchReputationRequest(`${apiBase}/forum`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "create-thread",
        voterId,
        categoryId,
        title: cleanTitle,
        body: cleanBody,
        authorUserId: author.authorUserId,
        authorName: author.authorName,
      }),
    });

    if (response.status === 429) return { ok: false, reason: "rate-limit" };
    if (response.status === 404) return { ok: false, reason: "not-deployed" };
    if (!response.ok) {
      let apiError = "";
      try {
        const errJson = await response.json();
        apiError = safeString(errJson?.error);
      } catch {
        /* ignore */
      }
      return { ok: false, reason: apiError || "error", status: response.status };
    }

    const json = await response.json();
    const threadView =
      json.thread && json.post ? { thread: json.thread, posts: [json.post] } : null;
    let profiles = null;
    if (threadView && author.authorUserId !== null) {
      profiles = await hydrateForumProfiles([author.authorUserId], {
        [String(author.authorUserId)]: { userId: author.authorUserId, rep: 0, status: "" },
      });
      if (threadView) {
        threadView.authors = profiles.authors;
        threadView.avatars = profiles.avatars;
      }
    }
    return {
      ok: true,
      thread: json.thread || null,
      post: json.post || null,
      threadView,
      profiles,
    };
  } catch (err) {
    logRepFailureOnce("Forum thread create failed:", err);
    return { ok: false, reason: "network" };
  }
}

async function replyToForumThread({ threadId, body, parentPostId = null }) {
  const id = safeString(threadId);
  if (!id) return { ok: false, reason: "invalid-thread" };

  const apiBase = getVortex07ApiBase();
  if (!apiBase) return { ok: false, reason: "no-api" };

  const cleanBody = safeString(body).slice(0, 1000);
  if (!cleanBody) return { ok: false, reason: "empty" };

  try {
    const voterId = await ensureVoterId();
    const author = getForumAuthorInfo();
    const payload = {
      action: "reply",
      voterId,
      threadId: id,
      body: cleanBody,
      authorUserId: author.authorUserId,
      authorName: author.authorName,
    };
    if (parentPostId) payload.parentPostId = safeString(parentPostId);
    const response = await fetchReputationRequest(`${apiBase}/forum`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (response.status === 429) return { ok: false, reason: "rate-limit" };
    if (response.status === 404) return { ok: false, reason: "not-deployed" };
    if (!response.ok) {
      let apiError = "";
      try {
        const errJson = await response.json();
        apiError = safeString(errJson?.error);
      } catch {
        /* ignore */
      }
      return { ok: false, reason: apiError || "error", status: response.status };
    }

    const json = await response.json();
    return { ok: true, post: json.post || null, thread: json.thread || null };
  } catch (err) {
    logRepFailureOnce("Forum reply failed:", err);
    return { ok: false, reason: "network" };
  }
}

async function likeForumPost({ threadId, postId }) {
  const tid = safeString(threadId);
  const pid = safeString(postId);
  if (!tid || !pid) return { ok: false, reason: "invalid-post" };

  const apiBase = getVortex07ApiBase();
  if (!apiBase) return { ok: false, reason: "no-api" };

  try {
    const voterId = await ensureVoterId();
    const response = await fetchReputationRequest(`${apiBase}/forum`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "like-post",
        voterId,
        threadId: tid,
        postId: pid,
      }),
    });

    if (response.status === 429) return { ok: false, reason: "rate-limit" };
    if (response.status === 404) return { ok: false, reason: "not-deployed" };
    if (!response.ok) {
      let apiError = "";
      try {
        const errJson = await response.json();
        apiError = safeString(errJson?.error);
      } catch {
        /* ignore */
      }
      return { ok: false, reason: apiError || "error", status: response.status };
    }

    const json = await response.json();
    return {
      ok: true,
      likeCount: Number(json.likeCount) || 0,
      myLike: Boolean(json.myLike),
    };
  } catch (err) {
    logRepFailureOnce("Forum like failed:", err);
    return { ok: false, reason: "network" };
  }
}

const VORTEX07_FORUM_API = {
  fetchFeed: fetchForumFeed,
  fetchThreads: fetchForumThreads,
  fetchThread: fetchForumThread,
  createThread: createForumThread,
  replyToThread: replyToForumThread,
  likePost: likeForumPost,
  buildAvatarHtml(userId, authorName, avatarUrl = "", compact = false) {
    const id = safeNumber(userId);
    const name = safeString(authorName) || "Guest";
    const letter = escapeHtml(initial(name));
    const color = avatarColor(name);
    const src = safeImageSrc(avatarUrl, "");
    const compactClass = compact ? " is-compact" : "";

    if (id === null) {
      return `<span class="vortex07-forum-avatar-wrap is-guest${compactClass}" style="background:${color}"><span class="vortex07-forum-avatar-letter">${letter}</span></span>`;
    }

    const imgTag = src
      ? `<img class="vortex07-forum-avatar-img is-loaded" src="${escapeHtml(src)}" data-vortex07-uid="${id}" alt="" loading="lazy" />`
      : `<img class="vortex07-forum-avatar-img" data-vortex07-uid="${id}" alt="" loading="lazy" />`;

    return `<a class="vortex07-forum-avatar-link" href="/users/${id}/profile" tabindex="-1"><span class="vortex07-forum-avatar-wrap${compactClass}" style="background:${color}">${imgTag}<span class="vortex07-forum-avatar-letter">${letter}</span></span></a>`;
  },
};

async function postGuestbookMessage(profileUserId, message) {
  const profileId = safeNumber(profileUserId);
  if (profileId === null) return { ok: false, reason: "invalid-profile" };

  const authorId = getLoggedInUserIdFromNav();
  if (authorId === null) return { ok: false, reason: "not-logged-in" };
  if (authorId === profileId) return { ok: false, reason: "self" };

  const clean = safeString(message).replace(/\s+/g, " ").trim().slice(0, GUESTBOOK_MAX_LEN);
  if (!clean) return { ok: false, reason: "empty" };

  const apiBase = getVortex07ApiBase();
  if (!apiBase) return { ok: false, reason: "no-api" };

  try {
    const voterId = await ensureVoterId();
    const session = cachedSessionUser || getSessionUserFromNav();
    const authorName =
      safeString(session?.displayName) ||
      safeString(session?.username) ||
      `User ${authorId}`;

    const response = await fetchReputationRequest(`${apiBase}/guestbook`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        profileUserId: profileId,
        authorId,
        voterId,
        authorName,
        message: clean,
      }),
    });

    if (response.status === 429) {
      return { ok: false, reason: "already-posted-today" };
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const json = await response.json();
    return { ok: true, entry: json.entry || null };
  } catch (err) {
    markRepApiFailure();
    logRepFailureOnce("Guestbook post failed:", err);
    return { ok: false, reason: "error" };
  }
}

function renderGuestbookEntries(listEl, entries) {
  listEl.textContent = "";
  if (!entries.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-guestbook-empty";
    empty.textContent = "No guestbook entries yet — be the first to sign.";
    listEl.appendChild(empty);
    return;
  }

  entries.forEach((entry) => {
    const li = document.createElement("li");
    li.className = "vortex07-guestbook-entry";

    const meta = document.createElement("div");
    meta.className = "vortex07-guestbook-entry-meta";

    const author = document.createElement(
      entry.authorId ? "a" : "span",
    );
    author.className = "vortex07-guestbook-author";
    author.textContent = safeString(entry.authorName) || `User ${entry.authorId}`;
    if (entry.authorId) {
      author.href = `/users/${entry.authorId}/profile`;
    }

    const date = document.createElement("span");
    date.className = "vortex07-guestbook-date";
    date.textContent = formatGuestbookDate(entry.createdAt);

    meta.append(author, date);

    const body = document.createElement("p");
    body.className = "vortex07-guestbook-message";
    body.textContent = safeString(entry.message);

    li.append(meta, body);
    listEl.appendChild(li);
  });
}

async function injectProfileGuestbook() {
  if (!currentSettings.enabled || !currentSettings.showGuestbook) return;

  const profileId = getProfileUserIdFromPage();
  const anchor = getGuestbookAnchor();
  if (profileId === null || !anchor) return;

  let section = document.querySelector(".vortex07-guestbook-section");
  if (!section) {
    section = document.createElement("section");
    section.className =
      "vortex07-guestbook-section vortex07-profile-guestbook home-section";
    section.innerHTML = `
      <div class="section-header">
        <h2 class="section-title">Guestbook</h2>
        <span class="section-link vortex07-guestbook-tag">Vortex07 only</span>
      </div>
      <ul class="vortex07-guestbook-list"></ul>
      <form class="vortex07-guestbook-form" hidden>
        <input type="text" class="vortex07-guestbook-input" maxlength="${GUESTBOOK_MAX_LEN}" placeholder="Leave a short message (once per day)…" autocomplete="off" />
        <button type="submit" class="vortex07-guestbook-submit rbx-2007-btn">Sign</button>
      </form>
      <p class="vortex07-guestbook-hint" hidden></p>
    `;
    mountGuestbookSection(section, anchor);

    const form = section.querySelector(".vortex07-guestbook-form");
    form?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const input = form.querySelector(".vortex07-guestbook-input");
      const hint = section.querySelector(".vortex07-guestbook-hint");
      const submit = form.querySelector(".vortex07-guestbook-submit");
      if (!input || !submit) return;

      submit.disabled = true;
      const result = await postGuestbookMessage(profileId, input.value);
      submit.disabled = false;

      if (result.ok) {
        input.value = "";
        form.hidden = true;
        if (hint) {
          hint.hidden = false;
          hint.textContent = "Signed! You can post again tomorrow.";
        }
        const list = section.querySelector(".vortex07-guestbook-list");
        const entries = await fetchGuestbookEntries(profileId, 20);
        if (list) renderGuestbookEntries(list, entries);
        return;
      }

      if (hint) {
        hint.hidden = false;
        hint.textContent =
          result.reason === "already-posted-today"
            ? "You already signed this guestbook today."
            : result.reason === "not-logged-in"
              ? "Log in to sign guestbooks."
              : "Could not post — try again later.";
      }
    });
  }

  const list = section.querySelector(".vortex07-guestbook-list");
  const form = section.querySelector(".vortex07-guestbook-form");
  const hint = section.querySelector(".vortex07-guestbook-hint");
  const loggedInId = getLoggedInUserIdFromNav();
  const canSign = loggedInId !== null && loggedInId !== profileId;

  if (form) form.hidden = !canSign;
  if (hint) hint.hidden = true;

  if (list) {
    list.innerHTML = '<li class="vortex07-guestbook-loading">Loading…</li>';
    const entries = await fetchGuestbookEntries(profileId, 20);
    renderGuestbookEntries(list, entries);
  }
}

async function pushLocalActivityEvent(userId, delta = 1) {
  const id = safeNumber(userId);
  if (id === null) return;

  const event = { type: "rep", userId: id, delta: Number(delta) || 1, at: Date.now() };
  const data = await storageGet("local", { [ACTIVITY_CACHE_KEY]: [] });
  const existing = Array.isArray(data[ACTIVITY_CACHE_KEY]) ? data[ACTIVITY_CACHE_KEY] : [];
  const next = [event, ...existing].slice(0, 40);
  await storageSet("local", { [ACTIVITY_CACHE_KEY]: next });
}

async function fetchActivityFeed(limit = 12) {
  const cap = Math.min(Math.max(Number(limit) || 12, 1), 30);
  const data = await storageGet("local", { [ACTIVITY_CACHE_KEY]: [] });
  const localEvents = Array.isArray(data[ACTIVITY_CACHE_KEY]) ? data[ACTIVITY_CACHE_KEY] : [];

  const apiBase = getVortex07ApiBase();
  if (!apiBase || !isRepApiAvailable() || shouldSkipNonEssentialPolling()) {
    return localEvents.slice(0, cap);
  }

  try {
    const voterId = await ensureVoterId();
    const url = `${apiBase}/activity?limit=${encodeURIComponent(cap)}&voterId=${encodeURIComponent(voterId)}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    const remote = Array.isArray(json.events) ? json.events : [];
    const merged = [...remote, ...localEvents]
      .sort((a, b) => (Number(b.at) || 0) - (Number(a.at) || 0))
      .filter((event, index, arr) => {
        const key = `${event.type}:${event.userId}:${event.at}`;
        return arr.findIndex((row) => `${row.type}:${row.userId}:${row.at}` === key) === index;
      })
      .slice(0, cap);
    return merged;
  } catch (err) {
    logRepFailureOnce("Activity feed fetch failed:", err);
    return localEvents.slice(0, cap);
  }
}

async function formatActivityEvent(event, nameMap) {
  const userId = safeNumber(event?.userId);
  if (userId === null) return null;

  const label = nameMap.get(userId) || `@user${userId}`;
  const delta = Number(event.delta) || 1;
  if (event.type === "rep") {
    return `${label} got +${delta} rep`;
  }
  return null;
}

let homeActivityInjected = false;

async function injectHomeActivityTicker() {
  if (!currentSettings.enabled || !currentSettings.showActivityTicker) return;

  const path = window.location.pathname;
  if (path !== "/home" && path !== "/") return;

  if (document.querySelector(".vortex07-activity-ticker")) {
    homeActivityInjected = true;
    return;
  }
  if (homeActivityInjected) return;

  const gamesSection = document.querySelector("#Container .games-section");
  if (!gamesSection) return;

  homeActivityInjected = true;

  const ticker = document.createElement("div");
  ticker.className = "vortex07-activity-ticker";
  ticker.innerHTML =
    '<div class="vortex07-activity-head"><span class="vortex07-activity-title">Vortex07 Activity</span><span class="vortex07-activity-sub">Recent rep</span></div><ul class="vortex07-activity-list"><li class="vortex07-activity-loading">Loading…</li></ul>';
  gamesSection.insertAdjacentElement("afterend", ticker);

  const list = ticker.querySelector(".vortex07-activity-list");
  const events = await fetchActivityFeed(12);
  list.textContent = "";

  if (!events.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-activity-empty";
    empty.textContent = "No recent rep yet — give someone +1 on a profile.";
    list.appendChild(empty);
    return;
  }

  const userIds = events
    .map((event) => safeNumber(event.userId))
    .filter((id) => id !== null);
  const names = await resolveLeaderboardDisplayNames(userIds);

  for (const event of events) {
    const text = await formatActivityEvent(event, names);
    if (!text) continue;

    const li = document.createElement("li");
    li.className = "vortex07-activity-item";
    const userId = safeNumber(event.userId);
    if (userId !== null) {
      const link = document.createElement("a");
      link.href = `/users/${userId}/profile`;
      link.className = "vortex07-activity-link";
      link.textContent = text;
      li.appendChild(link);
    } else {
      li.textContent = text;
    }
    list.appendChild(li);
  }

  if (!list.children.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-activity-empty";
    empty.textContent = "No recent rep yet — give someone +1 on a profile.";
    list.appendChild(empty);
  }
}

async function syncPendingReputationVotes() {
  const apiBase = getReputationApiBase();
  if (!apiBase || shouldSkipNonEssentialPolling()) return;

  const actorId = getActorUserId();
  if (actorId === null) return;

  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  if (pending.length === 0) return;

  const remaining = [];

  for (const userId of pending) {
    try {
      const response = await fetchReputationRequest(`${apiBase}/reputation`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId, actorUserId: actorId }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      await cacheReputation(userId, json.count, true);
      invalidateRepApiCache(userId);
    } catch {
      remaining.push(userId);
    }
  }

  await storageSet("local", { [REPUTATION_PENDING_KEY]: remaining });
}

async function unqueuePendingReputationVote(userId) {
  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  const next = pending.filter((id) => Number(id) !== Number(userId));
  if (next.length === pending.length) return;
  await storageSet("local", { [REPUTATION_PENDING_KEY]: next });
}

async function queuePendingReputationVote(userId) {
  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  if (!pending.includes(Number(userId))) pending.push(Number(userId));
  await storageSet("local", { [REPUTATION_PENDING_KEY]: pending });
}

function getUserIdFromRepNode(node) {
  if (!node) return null;
  if (node.dataset?.vortex07UserId) return safeNumber(node.dataset.vortex07UserId);
  const href =
    node.getAttribute("href") ||
    node.querySelector("a[href*='/users/']")?.getAttribute("href") ||
    "";
  return extractUserIdFromHref(href);
}

function resolveGlobalRepHost(parentEl) {
  if (!parentEl) return null;

  if (parentEl.classList.contains("friend-card")) {
    let meta = parentEl.querySelector(".vortex07-friend-meta");
    if (!meta) {
      meta = document.createElement("span");
      meta.className = "vortex07-friend-meta";
      const nameEl = parentEl.querySelector(".friend-name");
      if (nameEl) nameEl.insertAdjacentElement("afterend", meta);
      else parentEl.appendChild(meta);
    }
    return meta;
  }

  if (parentEl.classList.contains("user-card")) {
    let meta = parentEl.querySelector(".vortex07-user-card-meta");
    if (!meta) {
      meta = document.createElement("span");
      meta.className = "vortex07-user-card-meta";
      const nameEl = parentEl.querySelector(".user-card-name");
      if (nameEl) nameEl.insertAdjacentElement("afterend", meta);
      else parentEl.appendChild(meta);
    }
    return meta;
  }

  if (parentEl.classList.contains("vortex07-player-result")) {
    let repRow = parentEl.querySelector(".vortex07-user-rep-row");
    if (!repRow) {
      repRow = document.createElement("span");
      repRow.className = "vortex07-user-rep-row";
      const info = parentEl.querySelector(".vortex07-user-info");
      if (info) info.appendChild(repRow);
      else parentEl.appendChild(repRow);
    }
    return repRow;
  }

  return parentEl;
}

function decorateGlobalRepBadge(parentEl, userId, count) {
  if (!currentSettings.enabled || !parentEl) return;
  const numeric = safeNumber(userId);
  if (numeric === null) return;

  const numericCount = Number(count) || 0;
  const isCompactTile =
    parentEl.classList.contains("friend-card") ||
    parentEl.classList.contains("user-card");

  const host = resolveGlobalRepHost(parentEl) || parentEl;

  if (isCompactTile && numericCount <= 0) {
    host.querySelector(".vortex07-global-rep")?.remove();
    return;
  }

  let badge = host.querySelector(".vortex07-global-rep");
  if (!badge) {
    badge = document.createElement("span");
    badge.className = "vortex07-global-rep";
    if (isCompactTile) badge.classList.add("vortex07-global-rep-compact");
    badge.title = "Global Vortex07 reputation";
    badge.innerHTML = `<span class="vortex07-global-rep-icon" aria-hidden="true">${repThumbUpSvg(isCompactTile ? 8 : 10)}</span><span class="vortex07-global-rep-num"></span>${isCompactTile ? "" : '<span class="vortex07-global-rep-label">rep</span>'}`;
    host.appendChild(badge);
  }

  const numEl = badge.querySelector(".vortex07-global-rep-num");
  if (numEl) numEl.textContent = String(numericCount);

  if (numericCount > 0) {
    host.querySelector(".vortex07-rep-milestone")?.remove();
    const milestone = createRepMilestoneEl(numericCount);
    if (milestone) host.appendChild(milestone);
  } else {
    host.querySelector(".vortex07-rep-milestone")?.remove();
  }
}

async function applyGlobalRepBadges(root = document) {
  if (!currentSettings.enabled) return;

  const nodes = root.querySelectorAll(
    ".friend-card, .user-card, .vortex07-player-result, .user-row",
  );
  if (nodes.length === 0) return;

  const ids = [];
  nodes.forEach((node) => {
    const id = getUserIdFromRepNode(node);
    if (id !== null) ids.push(id);
  });

  const repMap = isExtensionContextAlive()
    ? await fetchReputationCountsBulk(ids)
    : await buildRepMapFromCache(ids);
  nodes.forEach((node) => {
    const id = getUserIdFromRepNode(node);
    if (id === null) return;
    const rep = repMap.get(id);
    const cached = rep || null;
    decorateGlobalRepBadge(
      node,
      id,
      cached ? cached.count : 0,
    );
  });

  scheduleExtensionMetaDecorations(root);
}

let globalRepScheduled = false;

function scheduleGlobalRepBadges(root = document) {
  if (globalRepScheduled || !currentSettings.enabled) {
    return;
  }
  globalRepScheduled = true;

  requestAnimationFrame(async () => {
    globalRepScheduled = false;
    await applyGlobalRepBadges(root);
  });
}

let homeLeaderboardInjected = false;

async function injectHomeLeaderboardStrip() {
  if (!currentSettings.enabled) return;

  const path = window.location.pathname;
  if (path !== "/home" && path !== "/") return;

  if (document.querySelector(".vortex07-home-leaderboard")) {
    homeLeaderboardInjected = true;
    return;
  }

  if (homeLeaderboardInjected) return;

  const gamesSection = document.querySelector("#Container .games-section");
  if (!gamesSection) return;

  homeLeaderboardInjected = true;

  const strip = document.createElement("div");
  strip.className = "vortex07-home-leaderboard";
  strip.innerHTML =
    '<div class="vortex07-home-leaderboard-head"><span class="vortex07-home-leaderboard-title">Vortex07 Rep Leaderboard</span><span class="vortex07-home-leaderboard-sub">Extension users only</span></div><ol class="vortex07-home-leaderboard-list"><li class="vortex07-home-leaderboard-loading">Loading…</li></ol><div class="vortex07-home-leaderboard-foot" hidden><span class="vortex07-home-leaderboard-foot-text">Give rep on profiles to climb the board</span></div>';

  const activityTicker = document.querySelector(".vortex07-activity-ticker");
  if (activityTicker) {
    activityTicker.insertAdjacentElement("afterend", strip);
  } else {
    gamesSection.insertAdjacentElement("afterend", strip);
  }

  const list = strip.querySelector(".vortex07-home-leaderboard-list");
  const rows = await fetchLeaderboard(10);
  list.textContent = "";

  if (!rows.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-home-leaderboard-empty";
    empty.textContent = "No rep yet — be the first to give rep on a profile.";
    list.appendChild(empty);
    return;
  }

  const userIds = rows
    .map((row) => safeNumber(row.userId))
    .filter((id) => id !== null);
  const avatars = await fetchPlayerAvatars(userIds);
  const displayNames = await resolveLeaderboardDisplayNames(userIds);
  const rankClasses = [
    "vortex07-home-leaderboard-row--gold",
    "vortex07-home-leaderboard-row--silver",
    "vortex07-home-leaderboard-row--bronze",
  ];

  rows.forEach((row, index) => {
    const userId = safeNumber(row.userId);
    if (userId === null) return;

    const li = document.createElement("li");
    li.className = "vortex07-home-leaderboard-row";
    if (rankClasses[index]) li.classList.add(rankClasses[index]);

    const rank = document.createElement("span");
    rank.className = "vortex07-home-leaderboard-rank";
    rank.textContent = String(index + 1);

    const avatar = document.createElement("img");
    avatar.className = "vortex07-home-leaderboard-avatar";
    avatar.alt = "";
    avatar.loading = "lazy";
    avatar.src =
      avatars.get(userId) ||
      `${VORTEX_ORIGIN}/images/placeholder-avatar.png`;

    const nameWrap = document.createElement("span");
    nameWrap.className = "vortex07-home-leaderboard-name-wrap";

    const name = document.createElement("a");
    name.className = "vortex07-home-leaderboard-name";
    name.href = `/users/${userId}/profile`;
    name.textContent =
      displayNames.get(userId) || `@user${userId}`;
    nameWrap.appendChild(name);
    appendUsernameBadges(nameWrap, userId);

    const count = document.createElement("span");
    count.className = "vortex07-home-leaderboard-count";
    count.innerHTML = `<span class="vortex07-global-rep-icon" aria-hidden="true">${repThumbUpSvg(10)}</span><span class="vortex07-global-rep-num">${Number(row.count) || 0}</span>`;

    li.append(rank, avatar, nameWrap, count);
    list.appendChild(li);
  });

  const foot = strip.querySelector(".vortex07-home-leaderboard-foot");
  if (foot) foot.hidden = false;

  enhanceRetroBadges(strip);
}

async function hydrateProfileAvatar(header, profileId) {
  if (!header || profileId === null) return;

  const avatar = header.querySelector(".profile-avatar");
  if (!avatar || avatar.dataset.vortex07AvatarHydrated === "1") return;

  const currentSrc = extractAvatarUrl(avatar.getAttribute("src") || "");
  const needsFetch = !currentSrc;

  const applyAvatarUrl = (url) => {
    if (!url) return false;
    avatar.src = url;
    avatar.alt = "";
    avatar.decoding = "async";
    avatar.referrerPolicy = "no-referrer";
    avatar.dataset.vortex07AvatarHydrated = "1";
    return true;
  };

  if (!needsFetch) {
    avatar.decoding = "async";
    avatar.referrerPolicy = "no-referrer";
    avatar.addEventListener(
      "error",
      () => {
        void fetchPlayerAvatars([profileId], { userInitiated: true }).then((map) => {
          const url = map.get(profileId);
          if (url) applyAvatarUrl(url);
        });
      },
      { once: true },
    );
    return;
  }

  const map = await fetchPlayerAvatars([profileId], { userInitiated: true });
  applyAvatarUrl(map.get(profileId));
}

function normalizeProfileLayout() {
  const header = document.querySelector(".profile-header");
  if (!header) return;

  header.classList.add("vortex07-profile-header");

  const avatarWrap = header.querySelector(".profile-avatar-wrap");
  if (avatarWrap) avatarWrap.classList.add("vortex07-profile-avatar-slot");

  const avatar = header.querySelector(".profile-avatar");
  const profileId = getProfileUserIdFromPage();
  if (avatarWrap && profileId !== null) {
    applyAvatarFrameClasses(avatarWrap, profileId);
  }

  if (avatar) {
    const framed =
      avatarWrap?.classList.contains("vortex07-rainbow-avatar-frame") ||
      avatarWrap?.classList.contains("vortex07-dev-avatar-frame");

    if (framed) {
      avatar.style.width = "100%";
      avatar.style.height = "100%";
      avatar.style.maxWidth = "none";
      avatar.style.maxHeight = "none";
      avatar.style.objectFit = "cover";
    } else {
      avatar.style.width = "100px";
      avatar.style.height = "100px";
      avatar.style.maxWidth = "100px";
      avatar.style.maxHeight = "100px";
      avatar.style.objectFit = "contain";
    }
  }

  if (profileId !== null) {
    void hydrateProfileAvatar(header, profileId);
  }

  ensureProfileMetaStack(header);
}

function applyAvatarFramesToPage(root = document) {
  const profileId = getProfileUserIdFromPage();
  if (profileId !== null) {
    const profileWrap = root.querySelector(".profile-avatar-wrap");
    if (profileWrap) applyAvatarFrameClasses(profileWrap, profileId);
  }

  root
    .querySelectorAll(".friend-card, .user-card, .user-row")
    .forEach((card) => {
      const userId = getUserIdFromRepNode(card);
      if (userId === null) return;

      const wrap =
        card.querySelector(
          ".friend-avatar-wrap, .user-row-avatar-wrap, [class*='avatar-wrap']",
        ) || card.querySelector(".friend-avatar, .user-row-avatar")?.parentElement;

      if (wrap) applyAvatarFrameClasses(wrap, userId);
    });
}

function normalizeOnlineIndicators() {
  document
    .querySelectorAll(
      ".friend-card, .profile-header, .user-row, .user-card",
    )
    .forEach((card) => {
      const indicators = card.querySelectorAll(
        ".status-dot, [class*='online-status'], [class*='status-indicator'], [data-online], [data-status]",
      );

      indicators.forEach((el) => {
        if (el.closest(".vortex07-reputation-panel")) return;
        if (el.matches("a, button, input, select, textarea")) return;

        el.classList.add("vortex07-status-pill");

        const text = safeLower(
          el.textContent ||
            el.getAttribute("data-status") ||
            el.getAttribute("data-online") ||
            el.className,
        );

        const isOnline =
          text.includes("online") ||
          text.includes("in-game") ||
          text.includes("ingame") ||
          el.classList.contains("online") ||
          el.getAttribute("data-online") === "true" ||
          el.getAttribute("data-status") === "online";

        const isOffline =
          text.includes("offline") ||
          el.classList.contains("offline") ||
          el.getAttribute("data-status") === "offline";

        el.classList.toggle("vortex07-status-online", isOnline);
        el.classList.toggle("vortex07-status-offline", isOffline && !isOnline);
      });
    });
}

