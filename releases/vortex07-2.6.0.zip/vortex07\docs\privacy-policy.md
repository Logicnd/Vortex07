# Vortex07 Privacy Policy

**Last updated:** June 28, 2026

Public URL: https://vortex07.vercel.app/privacy

Vortex07 is a browser extension that restyles [playvortex.io](https://playvortex.io). This policy describes what data the extension and its optional community API collect.

## What we collect

- **Local storage** — Extension settings, termed-player archive snapshots, and queued reputation votes are stored in your browser via Chrome storage APIs.
- **Community reputation API** — When you give reputation, the extension sends your Playvortex user ID, the target user ID, and a signed request to `vortex07.vercel.app`. No passwords or cookies are transmitted.
- **Guestbook, status, forum, activity** — Optional social features may store public-facing content and a voter identifier.

## What we do not collect

- Passwords, payment information, or login credentials
- Browsing history outside playvortex.io
- Precise location or contact lists

## Third parties

The community API runs on Vercel with Upstash Redis.

## Contact

[github.com/Logicnd/Vortex07](https://github.com/Logicnd/Vortex07)
