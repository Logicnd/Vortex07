#!/usr/bin/env node
/**
 * Smoke-test all Vortex07 API endpoints on production (or VORTEX07_API_URL).
 */
const { PROJECT } = require("./config.js");

const BASE =
  String(process.env.VORTEX07_API_URL || PROJECT.productionUrl).replace(/\/$/, "") +
  "/api";

const TEST_VOTER = "vortex07-verify-00000001";
const TEST_USER = "1";

async function request(method, path, body) {
  const url = `${BASE}${path}`;
  const options = {
    method,
    headers: { Accept: "application/json" },
  };

  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  const text = await response.text();
  let json;
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { raw: text.slice(0, 200) };
  }

  return { ok: response.ok, status: response.status, json };
}

async function check(name, fn) {
  try {
    const result = await fn();
    const pass = result.ok !== false;
    console.log(`${pass ? "✓" : "✗"} ${name}${result.detail ? ` — ${result.detail}` : ""}`);
    if (!pass) process.exitCode = 1;
    return pass;
  } catch (err) {
    console.log(`✗ ${name} — ${err.message}`);
    process.exitCode = 1;
    return false;
  }
}

async function main() {
  console.log(`Verifying ${BASE}\n`);

  await check("GET /health", async () => {
    const res = await request("GET", "/health");
    return {
      ok: res.ok && res.json.ok === true,
      detail: res.json.version ? `v${res.json.version}` : `HTTP ${res.status}`,
    };
  });

  await check("GET /reputation", async () => {
    const res = await request(
      "GET",
      `/reputation?userId=${TEST_USER}&voterId=${TEST_VOTER}`,
    );
    return {
      ok: res.ok && typeof res.json.count === "number",
      detail: `count=${res.json.count}`,
    };
  });

  await check("GET /leaderboard", async () => {
    const res = await request("GET", "/leaderboard?limit=5");
    return {
      ok: res.ok && Array.isArray(res.json.results),
      detail: `${res.json.results?.length || 0} rows`,
    };
  });

  await check("GET /players/batch", async () => {
    const res = await request(
      "GET",
      `/players/batch?ids=${TEST_USER}&voterId=${TEST_VOTER}`,
    );
    return {
      ok: res.ok && Array.isArray(res.json.results),
      detail: `${res.json.results?.length || 0} results`,
    };
  });

  await check("GET /status", async () => {
    const res = await request(
      "GET",
      `/status?userId=${TEST_USER}&voterId=${TEST_VOTER}`,
    );
    return { ok: res.ok && "status" in res.json, detail: res.json.persistent ? "persistent" : "memory" };
  });

  await check("GET /profile-views", async () => {
    const res = await request(
      "GET",
      `/profile-views?userId=${TEST_USER}&voterId=${TEST_VOTER}`,
    );
    return { ok: res.ok && typeof res.json.count === "number", detail: `count=${res.json.count}` };
  });

  await check("GET /guestbook", async () => {
    const res = await request(
      "GET",
      `/guestbook?profileUserId=${TEST_USER}&voterId=${TEST_VOTER}&limit=5`,
    );
    return {
      ok: res.ok && Array.isArray(res.json.entries),
      detail: `${res.json.entries?.length || 0} entries`,
    };
  });

  await check("GET /activity", async () => {
    const res = await request("GET", `/activity?limit=5&voterId=${TEST_VOTER}`);
    return {
      ok: res.ok && Array.isArray(res.json.events),
      detail: `${res.json.events?.length || 0} events`,
    };
  });

  await check("GET /forum feed", async () => {
    const res = await request(
      "GET",
      `/forum?action=feed&category=general&voterId=${TEST_VOTER}&limit=5`,
    );
    return {
      ok: res.ok && Array.isArray(res.json.threads) && res.json.authors,
      detail: res.status === 404 ? "not deployed" : `${res.json.threads?.length || 0} threads`,
    };
  });

  await check("GET /rep-audit (admin)", async () => {
    const res = await fetch(`${BASE}/rep-audit?limit=5`, {
      headers: {
        Accept: "application/json",
        "X-Vortex07-Admin": "vortex07-admin-audit-v2-5-0",
      },
    });
    const text = await res.text();
    let json;
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      json = {};
    }
    return {
      ok: res.ok && Array.isArray(json.events),
      detail: res.status === 403 ? "admin secret mismatch" : `${json.events?.length || 0} events`,
    };
  });

  await check("GET /game-votes", async () => {
    const res = await request(
      "GET",
      `/game-votes?gameId=1&voterId=${TEST_VOTER}`,
    );
    return {
      ok: res.ok && typeof res.json.likes === "number",
      detail: res.status === 404 ? "not deployed — run api:deploy" : `likes=${res.json.likes}`,
    };
  });

  await check("OPTIONS /guestbook (CORS preflight)", async () => {
    const res = await fetch(`${BASE}/guestbook`, { method: "OPTIONS" });
    const cors = res.headers.get("access-control-allow-origin");
    return {
      ok: res.status === 204 && cors === "*",
      detail: cors ? `origin=${cors}` : "missing CORS header",
    };
  });

  await check("OPTIONS /reputation (playvortex origin)", async () => {
    const res = await fetch(`${BASE}/reputation`, {
      method: "OPTIONS",
      headers: { Origin: "https://playvortex.io" },
    });
    const cors = res.headers.get("access-control-allow-origin");
    return {
      ok: res.status === 204 && cors === "https://playvortex.io",
      detail: cors ? `origin=${cors}` : "missing CORS header",
    };
  });

  await check("POST /rep-admin without auth (403)", async () => {
    const res = await fetch(`${BASE}/rep-admin`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: "1" }),
    });
    return {
      ok: res.status === 403,
      detail: res.status === 404 ? "not deployed — run api:deploy" : `status=${res.status}`,
    };
  });

  console.log(process.exitCode ? "\nSome checks failed." : "\nAll checks passed.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
