const fs = require("fs");
const path = require("path");

const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
const message = process.argv.slice(2).join(" ").trim();

const manifestPath = path.join(__dirname, "..", "manifest.json");
const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
const version = String(manifest.version || "?").trim();

if (!webhookUrl) {
  console.error("Missing DISCORD_WEBHOOK_URL");
  process.exit(1);
}

if (!message) {
  console.error(
    `Missing message. Example: npm run publish -- "v${version} | Updated search UI | Fixed profile layout"`,
  );
  process.exit(1);
}

function makeDescription(text) {
  return text
    .split("|")
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => `• ${part}`)
    .join("\n");
}

const description = makeDescription(message);

const payload = {
  content: `🚀 **Vortex07 v${version}**`,
  embeds: [
    {
      title: "What's new",
      description: description || `• ${message}`,
      color: 5793266,
      footer: {
        text: `Vortex07 v${version}`,
      },
      timestamp: new Date().toISOString(),
    },
  ],
};

fetch(webhookUrl, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(payload),
})
  .then((res) => {
    if (!res.ok) {
      throw new Error(`Discord webhook failed: ${res.status}`);
    }

    console.log(`Sick embed sent to Discord (v${version}).`);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
