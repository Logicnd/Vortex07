// Vortex07 friends-ui.js — Friends carousel, carousel helpers, layout normalizers (flattenCarousels, compressHero).
// Shares scope with content.js.

function enhanceLegacyStatusLabels() {
  // Status text labels intentionally disabled.
  // Native site status dots may remain styled by CSS if needed.
}

function flattenCarousels() {
  document
    .querySelectorAll(
      ".carousel-wrap, .carousel-track, .carousel-inner, .carousel-slider, [class*='carousel']",
    )
    .forEach((el) => {
      if (isInsideVortexShell(el) && el.closest("#Header, #Banner, .Navigation"))
        return;
      if (el.closest(".friends-section")) return;

      el.style.transform = "none";
      el.style.transition = "none";
      el.style.animation = "none";
      el.style.overflow = "visible";
      el.style.width = "100%";
      el.style.maxWidth = "100%";
    });

  document
    .querySelectorAll(".carousel-arrow, .carousel-btn, [class*='carousel-prev'], [class*='carousel-next']")
    .forEach((el) => {
      if (el.closest(".friends-section")) return;

      el.style.display = "none";
      el.setAttribute("aria-hidden", "true");
      el.tabIndex = -1;
    });

  document.querySelectorAll(".carousel-wrap").forEach((wrap) => {
    if (wrap.closest(".friends-section")) return;
    wrap.dataset.vortex07Flattened = "true";
  });
}

function isDedicatedFriendsPage() {
  if (resolvePageRouteKey() !== "social") return false;

  const page = document.querySelector("#Body > .page, #Body > .catalog-container");
  if (!page) return true;

  const activeTab = page.querySelector(
    ".tab-bar .active, .tab-bar [aria-selected='true'], .tab-bar .tab-active",
  );
  if (activeTab && safeLower(activeTab.textContent).includes("friend")) return true;

  const hasHomeSections = page.querySelector(".home-section, .games-section");
  const hasFriendsMain = page.querySelector(
    ".friends-list, .friends-page, [class*='friends-page'], .friends-tab-panel",
  );
  return Boolean(hasFriendsMain && !hasHomeSections);
}

function shouldEnhanceFriendCarousels() {
  if (!currentSettings.friendRowCarousels) return false;
  if (isDedicatedFriendsPage()) return false;
  return true;
}

function removeFriendCarousels(root = document) {
  const wraps = root instanceof Element
    ? Array.from(root.querySelectorAll(".vortex07-friends-carousel-wrap"))
    : Array.from(document.querySelectorAll(".vortex07-friends-carousel-wrap"));

  wraps.forEach((wrap) => {
    const row = wrap.querySelector(".friends-row, .friends-grid");
    if (row && wrap.parentNode) {
      wrap.parentNode.insertBefore(row, wrap);
      wrap.remove();
    }
  });
}

function getFriendCardSortName(card) {
  const nameEl = card.querySelector(".friend-name-text, .friend-name");
  return safeLower(nameEl?.textContent || card.textContent || "");
}

function getFriendsRowCards(row) {
  return [
    ...row.querySelectorAll(
      ".friend-card, .friends-grid > a[href*='/users/'], .friends-row > a[href*='/users/']",
    ),
  ];
}

function sortFriendsRowAlphabetically(row) {
  const cards = getFriendsRowCards(row);
  if (cards.length < 2) return;
  cards.sort((a, b) =>
    getFriendCardSortName(a).localeCompare(getFriendCardSortName(b), undefined, {
      sensitivity: "base",
    }),
  );
  cards.forEach((card) => row.appendChild(card));
}

function renderFriendsRowPage(wrap, pageIndex) {
  const row = wrap.querySelector(".friends-row, .friends-grid");
  if (!row) return;

  const cards = getFriendsRowCards(row);
  const totalPages = Math.max(1, Math.ceil(cards.length / FRIENDS_ROW_PAGE_SIZE));
  const page = Math.min(Math.max(pageIndex, 0), totalPages - 1);
  wrap.dataset.vortex07FriendsPage = String(page);

  cards.forEach((card, index) => {
    const pageForCard = Math.floor(index / FRIENDS_ROW_PAGE_SIZE);
    card.classList.toggle("vortex07-friend-page-hidden", pageForCard !== page);
  });

  let indicator = wrap.querySelector(".vortex07-friends-page-indicator");
  if (!indicator) {
    indicator = document.createElement("span");
    indicator.className = "vortex07-friends-page-indicator";
    wrap.appendChild(indicator);
  }
  indicator.hidden = totalPages <= 1;
  indicator.textContent = `${page + 1} / ${totalPages}`;
  syncFriendsCarouselArrows(wrap);
}

function changeFriendsCarouselPage(wrap, direction) {
  const current = Number(wrap.dataset.vortex07FriendsPage) || 0;
  renderFriendsRowPage(wrap, current + direction);
}

function scrollFriendsCarouselRow(row, direction) {
  const wrap = row.closest(".carousel-wrap, .vortex07-friends-carousel-wrap");
  if (wrap) {
    changeFriendsCarouselPage(wrap, direction);
    return;
  }
  const amount = Math.max(120, Math.round(row.clientWidth * 0.85));
  row.scrollBy({ left: direction * amount, behavior: "smooth" });
}

function ensureFriendsSectionCarousel(section) {
  if (!shouldEnhanceFriendCarousels()) return null;
  if (section.dataset.vortex07FriendsSkip === "1") return null;

  if (
    section.querySelector(".carousel-wrap, .vortex07-friends-carousel-wrap")
  ) {
    return section.querySelector(
      ".carousel-wrap, .vortex07-friends-carousel-wrap",
    );
  }

  const row = section.querySelector(".friends-grid, .friends-row");
  if (!row) return null;

  // Bug fix: if .friends-grid is nested inside a .section-header move it out
  // before wrapping so the carousel sits at the right DOM level.
  const sectionHeader = row.closest(".section-header");
  if (sectionHeader && sectionHeader.parentNode) {
    sectionHeader.parentNode.insertBefore(row, sectionHeader.nextSibling);
  }

  const wrap = document.createElement("div");
  wrap.className = "carousel-wrap vortex07-friends-carousel-wrap";

  const prevBtn = document.createElement("button");
  prevBtn.type = "button";
  prevBtn.className = "carousel-arrow carousel-prev vortex07-carousel-btn";
  prevBtn.textContent = "‹";
  prevBtn.setAttribute("aria-label", "Previous friends page");

  const nextBtn = document.createElement("button");
  nextBtn.type = "button";
  nextBtn.className = "carousel-arrow carousel-next vortex07-carousel-btn";
  nextBtn.textContent = "›";
  nextBtn.setAttribute("aria-label", "Next friends page");

  row.classList.add("friends-row");
  row.setAttribute("tabindex", "0");
  row.setAttribute("role", "region");
  row.setAttribute("aria-label", "Friends row");
  row.parentNode.insertBefore(wrap, row);
  wrap.append(prevBtn, row, nextBtn);

  return wrap;
}

function syncFriendsCarouselArrows(wrap) {
  const row = wrap.querySelector(".friends-row, .friends-grid");
  const prevBtn = wrap.querySelector(".carousel-prev, [class*='carousel-prev']");
  const nextBtn = wrap.querySelector(".carousel-next, [class*='carousel-next']");
  if (!row || !prevBtn || !nextBtn) return;

  const cards = getFriendsRowCards(row);
  const totalPages = Math.max(1, Math.ceil(cards.length / FRIENDS_ROW_PAGE_SIZE));
  const page = Number(wrap.dataset.vortex07FriendsPage) || 0;
  const scrollable = totalPages > 1;
  const atStart = page <= 0;
  const atEnd = page >= totalPages - 1;

  prevBtn.hidden = !scrollable;
  nextBtn.hidden = !scrollable;
  prevBtn.style.display = scrollable ? "" : "none";
  nextBtn.style.display = scrollable ? "" : "none";

  prevBtn.classList.toggle("vortex07-carousel-disabled", !scrollable || atStart);
  nextBtn.classList.toggle("vortex07-carousel-disabled", !scrollable || atEnd);
  prevBtn.disabled = !scrollable || atStart;
  nextBtn.disabled = !scrollable || atEnd;
  prevBtn.setAttribute("aria-disabled", String(!scrollable || atStart));
  nextBtn.setAttribute("aria-disabled", String(!scrollable || atEnd));

  if (!scrollable || atStart) {
    prevBtn.setAttribute("aria-hidden", "true");
    prevBtn.tabIndex = -1;
  } else {
    prevBtn.removeAttribute("aria-hidden");
    prevBtn.tabIndex = 0;
  }

  if (!scrollable || atEnd) {
    nextBtn.setAttribute("aria-hidden", "true");
    nextBtn.tabIndex = -1;
  } else {
    nextBtn.removeAttribute("aria-hidden");
    nextBtn.tabIndex = 0;
  }
}

function enhanceFriendsCarousels(root = document) {
  if (!shouldEnhanceFriendCarousels()) {
    if (isDedicatedFriendsPage()) removeFriendCarousels(root);
    return;
  }

  const sections =
    root instanceof Element
      ? [root.closest(".friends-section")].filter(Boolean)
      : Array.from(document.querySelectorAll(".friends-section"));

  sections.forEach((section) => {
    if (isDedicatedFriendsPage()) {
      section.dataset.vortex07FriendsSkip = "1";
      return;
    }
    delete section.dataset.vortex07FriendsSkip;
    ensureFriendsSectionCarousel(section);
  });

  const wraps =
    root instanceof Element
      ? Array.from(
          root.querySelectorAll(
            ".friends-section .carousel-wrap, .friends-section .vortex07-friends-carousel-wrap",
          ),
        )
      : Array.from(
          document.querySelectorAll(
            ".friends-section .carousel-wrap, .friends-section .vortex07-friends-carousel-wrap",
          ),
        );

  wraps.forEach((wrap) => {
    const row = wrap.querySelector(".friends-row, .friends-grid");
    const prevBtn = wrap.querySelector(
      ".carousel-prev, [class*='carousel-prev']",
    );
    const nextBtn = wrap.querySelector(
      ".carousel-next, [class*='carousel-next']",
    );
    if (!row || !prevBtn || !nextBtn) return;

    row.classList.add("vortex07-friends-row-paged");
    row.style.removeProperty("overflow");
    row.style.overflowX = "hidden";

    sortFriendsRowAlphabetically(row);
    renderFriendsRowPage(wrap, Number(wrap.dataset.vortex07FriendsPage) || 0);

    if (prevBtn.textContent.trim() === "<") prevBtn.textContent = "‹";
    if (nextBtn.textContent.trim() === ">") nextBtn.textContent = "›";

    if (wrap.dataset.vortex07FriendsCarousel !== "1") {
      wrap.dataset.vortex07FriendsCarousel = "1";

      prevBtn.addEventListener("click", () => {
        if (prevBtn.disabled) return;
        changeFriendsCarouselPage(wrap, -1);
      });
      nextBtn.addEventListener("click", () => {
        if (nextBtn.disabled) return;
        changeFriendsCarouselPage(wrap, 1);
      });
      row.addEventListener("keydown", (event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          changeFriendsCarouselPage(wrap, -1);
        } else if (event.key === "ArrowRight") {
          event.preventDefault();
          changeFriendsCarouselPage(wrap, 1);
        }
      });

      if (typeof ResizeObserver !== "undefined") {
        const observer = new ResizeObserver(() => {
          sortFriendsRowAlphabetically(row);
          renderFriendsRowPage(wrap, Number(wrap.dataset.vortex07FriendsPage) || 0);
        });
        observer.observe(row);
      }
    }

    sortFriendsRowAlphabetically(row);
    renderFriendsRowPage(wrap, Number(wrap.dataset.vortex07FriendsPage) || 0);
  });
}

function compressHeroSections() {
  document
    .querySelectorAll(
      ".hero, .page-hero, .home-hero, .site-hero, .banner-hero, [class*='hero-banner'], [class*='Hero']",
    )
    .forEach((el) => {
      if (el.closest("#Banner, #Header, #Logo")) return;
      el.classList.add("vortex07-hero-compressed");
    });

  document.querySelectorAll(".dl-hero").forEach((el) => {
    el.classList.add("vortex07-dl-hero-compact");
  });
}

function normalizeFriendTiles() {
  const grids = document.querySelectorAll(
    ".friends-grid, .friends-section, .friends-list, [class*='friends-grid'], [class*='friend-list']",
  );

  grids.forEach((grid) => {
    grid.style.removeProperty("display");
    grid.style.removeProperty("grid-template-columns");
    grid.style.removeProperty("grid-template-rows");
    grid.style.removeProperty("gap");
  });

  document
    .querySelectorAll(
      ".friend-card, .user-card, .friends-grid > a, .friends-section > a, .friends-list > a",
    )
    .forEach((card) => {
      card.classList.add("vortex07-friend-tile");

      const friendId = getUserIdFromRepNode(card);
      if (friendId !== null) {
        card.dataset.vortex07UserId = String(friendId);
      }

      [
        "width",
        "min-width",
        "max-width",
        "flex",
        "flex-direction",
        "align-items",
        "align-self",
        "grid-column",
        "grid-row",
        "justify-content",
      ].forEach((prop) => card.style.removeProperty(prop));

      card.querySelectorAll(".friend-name, span, p").forEach((label) => {
        if (label.closest(".friend-avatar, [class*='avatar']")) return;
        if (label.querySelector("img")) return;

        label.style.removeProperty("position");
        label.style.removeProperty("top");
        label.style.removeProperty("right");
        label.style.removeProperty("bottom");
        label.style.removeProperty("left");
        label.style.removeProperty("align-self");
      });
    });

  if (getProfileUserIdFromPage() !== null) {
    void injectProfileMutualIndicator();
  }
}

