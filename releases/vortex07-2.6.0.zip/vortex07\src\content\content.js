// Vortex07 content.js
// Clean stable build: 2007 layout + smart player search + safe hover preview.
// IMPORTANT: keep this as plain JavaScript. Do not paste HTML-escaped text like &gt; or &amp;.

const ext = globalThis.Vortex07Ext?.api || (typeof browser !== "undefined" ? browser : chrome);

const VORTEX07_VERSION = "2.5.0";
const VORTEX07_ROUTE_CLASS_PREFIX = "vortex07-route-";

const VORTEX_LOGO_SVG =
  '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="48" viewBox="0 0 160 48"><rect x="1" y="1" width="158" height="46" fill="#5c4a9e" stroke="#000" stroke-width="2"/><rect x="5" y="5" width="150" height="36" fill="#7a68bc" stroke="#2f2558" stroke-width="1"/><text x="80" y="27" font-family="Arial Black, Arial Bold, Arial, Helvetica, sans-serif" font-size="21" font-weight="700" fill="#fff" stroke="#1d1033" stroke-width="0.5" text-anchor="middle" paint-order="stroke">VORTEX</text><text x="80" y="39" font-family="Tahoma, MS Sans Serif, Arial, sans-serif" font-size="7" letter-spacing="0.12em" fill="#e8d4ff" text-anchor="middle">ONLINE BUILDING TOY</text></svg>';
const VORTEX_LOGO_DATA_URI = `data:image/svg+xml,${encodeURIComponent(VORTEX_LOGO_SVG)}`;
const VORTEX_ORIGIN = "https://playvortex.io";
const PLAYVORTEX_WIKI_URL = "https://playvortex.wiki/";
const VORTEX07_SETTINGS_HASH = "#vortex07-settings";
const VORTEX07_DASHBOARD_HASH = "#vortex07-dashboard";
const VORTEX07_FORUM_HASH = "#vortex07-forum";
const VORTEX07_DEVELOPER_IDS = new Set([15936, 18202]);
const VORTEX07_HALO_DEVELOPER_ID = 1;
const VORTEX07_RECENT_PLAYERS_KEY = "vortex07RecentPlayers";
const VORTEX07_PLAYER_ARCHIVE_KEY = "vortex07PlayerArchive";
const VORTEX07_BOOSTER_IDS_KEY = "vortex07BoosterIds";
const VORTEX07_RECENT_PLAYERS_MAX = 10;
const VORTEX07_PLAYER_ARCHIVE_MAX = 500;
const API_TIMEOUT_MS = 5000;
const REPUTATION_VOTER_KEY = "vortex07VoterId";
const REPUTATION_MY_VOTES_KEY = "vortex07MyReputationVotes";
const REPUTATION_CACHE_KEY = "vortex07ReputationCache";
const REPUTATION_PENDING_KEY = "vortex07ReputationPending";
const GAME_VOTES_CACHE_KEY = "vortex07GameVotesCache";
const GAME_MY_VOTES_KEY = "vortex07MyGameVotes";
const COMMUNITY_REPUTATION_API = "https://vortex07.vercel.app/api";
const VORTEX07_API_BASE = COMMUNITY_REPUTATION_API;
const LEADERBOARD_CACHE_KEY = "vortex07LeaderboardCache";
const STATUS_CACHE_KEY = "vortex07StatusCache";
const ACTIVITY_CACHE_KEY = "vortex07ActivityCache";
const GUESTBOOK_MAX_LEN = 120;
const STATUS_MAX_LEN = 80;
const VORTEX07_ROULETTE_LAST_KEY = "vortex07RouletteLastId";
const VORTEX07_FRIEND_IDS_CACHE_KEY = "vortex07FriendIdsCache";
const REP_MILESTONE_TIERS = [
  { min: 500, tier: "platinum", label: "500+ rep" },
  { min: 100, tier: "gold", label: "100+ rep" },
  { min: 50, tier: "silver", label: "50+ rep" },
  { min: 10, tier: "bronze", label: "10+ rep" },
];

const defaultSettings = {
  enabled: true,
  customNav: true,
  classicFooter: true,
  retroButtons: true,
  userSearch: true,
  friendRowCarousels: true,
  darkMode: false,
  iconCache: true,
  reputationApiUrl: "",
  showExtensionStatus: true,
  showGuestbook: true,
  showForum: true,
  showActivityTicker: true,
  debugLogs: false,
  themePreset: "classic",
};

let currentSettings = { ...defaultSettings };
let is2007Applied = false;
let bodyContainer = null;
let pageObserverStarted = false;
let layoutGuardStarted = false;
let searchDebounceTimer = null;
let lastSearchQuery = "";
let documentClickAttached = false;
let searchPositionListenersAttached = false;
let searchInputRef = null;
let searchHostRef = null;
let extensionContextValid = true;
let layoutGuardObserver = null;
let pageLayoutObserver = null;
let lastRepPanelUserId = null;
let lastGameRatingGameId = null;
let lastGlobalRepFetchAt = 0;
let lastGlobalRepIdsKey = "";
let lastLayoutEnhanceAt = 0;
let layoutEnhanceDebounceTimer = null;
let lastObserverEnhanceAt = 0;
let lastSessionFetchAt = 0;
let sessionUserFetchInFlight = null;
let repApiDownUntil = 0;
let lastRepFailureLogAt = 0;
let playvortexApiDownUntil = 0;
let playvortexRateLimitedUntil = 0;
let lastPlayvortexFailureLogAt = 0;
let sessionApiDownUntil = 0;
let profileBadgeEnhanceTimer = null;
let profileBadgeHydrateToken = 0;
let friendBadgeHydrateTimer = null;
let friendBadgeHydrateToken = 0;
let profileBadgeObserverStarted = false;
const profileRoleCache = new Map();
const playvortexUserRoleCacheAt = new Map();
const playvortexUserFetchInflight = new Map();
const playvortexInterceptorIngestedIds = new Set();
const knownBoosterIds = new Set();
let knownBoosterIdsLoaded = false;
let roleIngestRefreshTimer = null;
let playvortexUserFetchQueue = [];
let playvortexUserFetchActive = 0;
let playvortexUserFetchQueueTimer = null;
let lastPlayvortexUserFetchStartAt = 0;
let lastFriendBadgePageKey = "";
let friendBadgeApiFetchBudget = 0;
let lastProfileBadgeRefreshUserId = null;
let profileBadgeFastEnhanceTimer = null;
let initialLayoutBuildTimer = null;
let profileBadgeObserver = null;
let observerMutationsPaused = 0;
let isEnhancingBadges = false;
let isRunningLayoutEnhancements = false;
let lastEnhancedProfileKey = "";
let lastKnownPathname = "";

const extensionAssetUrlCache = new Map();
const apiRequestState = {
  queue: [],
  active: 0,
  lastGlobalAt: 0,
  endpointLastAt: new Map(),
  cache: new Map(),
  inflight: new Map(),
};

const GLOBAL_REP_MIN_INTERVAL_MS = 60000;
const PROFILE_BADGE_DEBOUNCE_MS = 200;
const FRIEND_BADGE_DEBOUNCE_MS = 800;
const FRIEND_BADGE_QUEUE_MAX = 3;
const FRIEND_BADGE_QUEUE_SPACING_MS = 3000;
const FRIENDS_ROW_PAGE_SIZE = 10;
const PLAYVORTEX_USER_ROLE_CACHE_TTL_MS = 600000;
const PLAYVORTEX_USER_FETCH_MAX_CONCURRENT = 1;
const PLAYVORTEX_USER_FETCH_QUEUE_SPACING_MS = 1200;
const ROLE_INGEST_REFRESH_DEBOUNCE_MS = 500;
const LAYOUT_ENHANCE_INTERVAL_MS = 12000;
const LAYOUT_OBSERVER_DEBOUNCE_MS = 2000;
const SESSION_FETCH_MIN_INTERVAL_MS = 600000;
const REP_API_COOLDOWN_MS = 90000;
const REP_FETCH_TIMEOUT_MS = 8000;
const PLAYVORTEX_API_COOLDOWN_MS = 120000;
const PLAYVORTEX_RATE_LIMIT_COOLDOWN_MS = 900000;

const API_MAX_CONCURRENT_REQUESTS = 2;
const API_GLOBAL_MIN_DELAY_MS = 350;
const API_ENDPOINT_MIN_DELAY_MS = 800;
const API_CACHE_TTL_MS = 120000;
const API_MAX_RETRIES = 0;
const API_REQUEST_TIMEOUT_MS = 5000;
const SEARCH_DEBOUNCE_MS = 300;
const SEARCH_CACHE_TTL_MS = 45000;

const RESILIENCE_SLOW_MS = 8000;
const RESILIENCE_MAX_RETRIES = 2;
const CIRCUIT_FAILURE_THRESHOLD = 3;
const CIRCUIT_FAILURE_WINDOW_MS = 60000;
const ATTACK_MODE_DURATION_MS = 90000;
const ATTACK_MODE_REP_CACHE_MS = 300000;
const ATTACK_MODE_LEADERBOARD_CACHE_MS = 300000;

const RESILIENCE_CIRCUITS = {
  playvortex: { failures: [], attackModeUntil: 0 },
  vortex07_api: { failures: [], attackModeUntil: 0 },
};

const RETRYABLE_HTTP_STATUSES = new Set([429, 502, 503, 504]);

const sessionMemoryStore = {
  voterId: "",
  myVotes: {},
  repCache: {},
  statusCache: {},
  pendingVotes: [],
  repWeek: null,
};

const avatarMemoryCache = new Map();
let lastRecordedProfileVisitId = null;

let extensionPausedForSite = false;
let layoutRevealFailsafeTimer = null;
let compareAnchor = null;

/* ========================================================= */
/* ================= LOGGING =============================== */
/* ========================================================= */

function logDebug(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][DEBUG]", ...args);
}

function logApi(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][API]", ...args);
}

function logSearch(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][SEARCH]", ...args);
}

function logAvatar(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][AVATAR]", ...args);
}

function logBanned(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][BANNED]", ...args);
}

function logRep(...args) {
  if (currentSettings.debugLogs) console.log("[Vortex07][REP]", ...args);
}

function logWarn(...args) {
  if (currentSettings.debugLogs) console.warn("[Vortex07][WARN]", ...args);
}

function logCritical(...args) {
  console.warn("[Vortex07]", ...args);
}

function logError(...args) {
  console.error("[Vortex07][ERROR]", ...args);
}

/* ========================================================= */
/* ================= HELPERS =============================== */
/* ========================================================= */

function revealBody() {
  document.getElementById("vortex-2007-hide")?.remove();
  if (document.body) {
    document.body.style.visibility = "visible";
    document.body.style.opacity = "1";
  }
}

function syncNativeSiteStylesheets(enabled) {
  const pattern = /(?:^|\/)social\.css|(?:^|\/)catalog\.css|(?:^|\/)auth\.css/i;

  document.querySelectorAll('link[rel="stylesheet"]').forEach((link) => {
    const href = link.getAttribute("href") || "";
    if (!pattern.test(href)) return;

    if (enabled) {
      link.disabled = true;
      link.dataset.vortex07Disabled = "1";
    } else if (link.dataset.vortex07Disabled === "1") {
      link.disabled = false;
      delete link.dataset.vortex07Disabled;
    }
  });
}

// Injected individually so each request is made by the content script (bypassing page CSP),
// rather than relying on CSS @import which inherits the page's CSP and blocks chrome-extension:// URLs.
const VORTEX07_CSS_FILES = [
  "src/styles/tokens.css",
  "src/styles/reset.css",
  "src/styles/layout.css",
  "src/styles/components.css",
  "src/styles/friends.css",
  "src/styles/profile.css",
  "src/styles/forum.css",
  "src/styles/jvortex.css",
  "src/styles/dark.css",
];

function syncThemeStylesheet(enabled) {
  if (!enabled) {
    document.querySelectorAll("[data-vortex07-css]").forEach((el) => el.remove());
    syncNativeSiteStylesheets(false);
    return Promise.resolve();
  }

  syncNativeSiteStylesheets(true);

  const head = document.head || document.documentElement;
  const pending = [];

  for (const cssPath of VORTEX07_CSS_FILES) {
    const id = "vortex07-css-" + cssPath.replace(/[^a-z0-9]/gi, "-");
    const url = extensionAssetUrl(cssPath);
    if (!url) continue;

    const existing = document.getElementById(id);
    if (existing) {
      if (existing.href !== url) existing.href = url;
      continue;
    }

    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href = url;
    link.dataset.vortex07Css = "1";

    pending.push(
      new Promise((resolve) => {
        link.onload = resolve;
        link.onerror = () => {
          logError("Failed to load Vortex07 CSS:", cssPath);
          resolve();
        };
      }),
    );

    head.appendChild(link);
  }

  return pending.length ? Promise.all(pending).then(() => {}) : Promise.resolve();
}

function extensionAssetUrl(relativePath) {
  if (currentSettings.iconCache !== false && extensionAssetUrlCache.has(relativePath)) {
    return extensionAssetUrlCache.get(relativePath);
  }
  try {
    const base = ext.runtime.getURL(relativePath);
    const url = `${base}?v=${encodeURIComponent(VORTEX07_VERSION)}`;
    if (currentSettings.iconCache !== false) extensionAssetUrlCache.set(relativePath, url);
    return url;
  } catch (_err) {
    return "";
  }
}

function applyThemePreferences(settings = currentSettings) {
  const root = document.documentElement;
  if (!root) return;
  root.classList.toggle("vortex07-dark", Boolean(settings.darkMode));
  root.dataset.vortex07Theme = settings.darkMode ? "dark" : "light";
}

function normalizeSearchText(value) {
  return safeLower(value)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9_\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function fuzzyMatchScore(haystack, needle) {
  const h = normalizeSearchText(haystack);
  const n = normalizeSearchText(needle);
  if (!n || n.length < 2) return 0;
  if (h === n) return 100;
  if (h.startsWith(n)) return 90;
  if (h.includes(n)) return 75;

  const tokens = n.split(" ").filter(Boolean);
  if (tokens.length > 1 && tokens.every((token) => h.includes(token))) return 65;

  let hi = 0;
  let score = 0;
  for (let ni = 0; ni < n.length; ni += 1) {
    const ch = n[ni];
    while (hi < h.length && h[hi] !== ch) hi += 1;
    if (hi >= h.length) return 0;
    score += 1;
    hi += 1;
  }
  return Math.round((score / n.length) * 55);
}

function getBrandLogoUrls() {
  if (!isExtensionContextAlive()) return [VORTEX_LOGO_DATA_URI];
  return [
    extensionAssetUrl("assets/logo.png"),
    extensionAssetUrl("assets/logo.svg"),
    VORTEX_LOGO_DATA_URI,
  ];
}

function applyBrandLogo(targetEl) {
  if (!targetEl) return;

  let link = targetEl.matches?.("a")
    ? targetEl
    : targetEl.querySelector("a, .navbar-logo");

  if (!link) {
    link = document.createElement("a");
    link.href = "/";
    link.className = "navbar-logo vortex07-logo-link";
    clearElement(targetEl);
    targetEl.appendChild(link);
  } else {
    link.classList.add("vortex07-logo-link");
  }

  link.href = "/";

  const logoUrls = getBrandLogoUrls();
  let img = link.querySelector(".vortex07-logo-img");

  if (!img) {
    img = document.createElement("img");
    img.className = "vortex07-logo-img";
    img.alt = "Vortex";
    link.textContent = "";
    link.appendChild(img);
  }

  const fallbackIndex = Number(img.dataset.vortex07LogoFallback || 0);
  img.src = logoUrls[Math.min(fallbackIndex, logoUrls.length - 1)];
  img.dataset.vortex07LogoAsset = fallbackIndex === 0 ? "png" : "fallback";

  img.onerror = () => {
    const next = fallbackIndex + 1;
    if (next < logoUrls.length) {
      img.dataset.vortex07LogoFallback = String(next);
      img.src = logoUrls[next];
      return;
    }
    img.onerror = null;
  };
}

const VORTEX07_BADGE_INLINE_SVG = {
  booster:
    '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><rect width="14" height="14" fill="#eb459e"/><path d="M7 1.75 L10.05 3.55 L10.05 10.45 L7 12.25 L3.95 10.45 L3.95 3.55 Z" fill="#fff" fill-opacity="0.95"/></svg>',
  owner:
    '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><rect width="14" height="14" fill="#ffd700"/><path d="M3 10 L7 2 L11 10 Z" fill="#c9a227"/></svg>',
  developer:
    '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><rect width="14" height="14" fill="#5c4a9e"/><path d="M4 10 L7 4 L10 10 Z" fill="#c9a227"/></svg>',
  staff:
    '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><rect width="14" height="14" fill="#4a90d9"/><path d="M7 2 L9 6 L7 12 L5 6 Z" fill="#fff"/></svg>',
};

function wireBadgeIconFallback(img, kind) {
  if (!img || img.dataset.vortex07BadgeFallback === "1") return;
  img.addEventListener("error", () => {
    if (img.dataset.vortex07BadgeFallback === "1") return;
    img.dataset.vortex07BadgeFallback = "1";
    const file = VORTEX07_BADGE_ASSETS[kind];
    if (!file) return;
    const url = badgeAssetUrl(file);
    if (url && img.src !== url) {
      img.src = url;
      return;
    }
    const inline = VORTEX07_BADGE_INLINE_SVG[kind];
    const wrap = img.closest(".vortex07-retro-badge-wrap");
    if (inline && wrap) {
      wrap.innerHTML = inline;
      wrap.dataset.vortex07BadgeKind = kind;
    }
  }, { once: true });
}

function ensureShellLogo() {
  const logoSlot = document.querySelector("#Container #Logo");
  if (!logoSlot) return;

  const img = logoSlot.querySelector(".vortex07-logo-img");
  const wantsPng =
    isExtensionContextAlive() &&
    img?.dataset.vortex07LogoAsset === "png" &&
    img.src.includes("logo.png");

  if (!img || !wantsPng) applyBrandLogo(logoSlot);
}

function isPlayvortexUnavailable() {
  const root = document.documentElement;
  const body = document.body;

  if (root?.classList.contains("neterror") || body?.classList.contains("neterror")) {
    return true;
  }

  const errorCode = safeString(document.querySelector(".error-code")?.textContent);
  if (/HTTP ERROR [45]\d\d|ERR_[A-Z_]+|\b52[0-9]\b/i.test(errorCode)) {
    return true;
  }

  const title = safeString(document.title);
  if (
    /connection timed out|error 52[0-9]|error 1200|rate limit|cloudflare/i.test(
      title,
    ) &&
    !document.querySelector(".page, .catalog-container, .navbar, #Container")
  ) {
    return true;
  }

  if (
    document.querySelector("#cf-wrapper, .cf-error-overview, #cf-error-details") &&
    !document.querySelector(".page, .catalog-container, .navbar, #Container")
  ) {
    return true;
  }

  if (
    /^this site can't be reached|^this page isn't working/i.test(title) &&
    !document.querySelector(".page, .catalog-container, .navbar, #Container")
  ) {
    return true;
  }

  if (
    /error 1200|rate limit/i.test(title) &&
    document.querySelector(".error-code, #main-message") &&
    !document.querySelector(".page, .catalog-container, .navbar, #Container")
  ) {
    return true;
  }

  return false;
}

function enableLayoutLoadingHide() {
  if (document.getElementById("vortex-2007-hide")) return;

  const style = document.createElement("style");
  style.id = "vortex-2007-hide";
  style.textContent = "body { opacity: 0; }";
  (document.head || document.documentElement).appendChild(style);

  if (layoutRevealFailsafeTimer) clearTimeout(layoutRevealFailsafeTimer);
  layoutRevealFailsafeTimer = setTimeout(() => {
    revealBody();
    layoutRevealFailsafeTimer = null;
  }, 3000);
}

function pauseExtensionForBrokenSite() {
  if (extensionPausedForSite) return true;
  if (!isPlayvortexUnavailable()) return false;

  extensionPausedForSite = true;

  if (layoutBootTimer) {
    clearTimeout(layoutBootTimer);
    layoutBootTimer = null;
  }

  if (layoutRevealFailsafeTimer) {
    clearTimeout(layoutRevealFailsafeTimer);
    layoutRevealFailsafeTimer = null;
  }

  if (layoutGuardObserver) {
    layoutGuardObserver.disconnect();
    layoutGuardObserver = null;
  }

  if (pageLayoutObserver) {
    pageLayoutObserver.disconnect();
    pageLayoutObserver = null;
  }

  if (profileBadgeObserver) {
    profileBadgeObserver.disconnect();
    profileBadgeObserver = null;
  }

  layoutGuardStarted = false;
  pageObserverStarted = false;
  profileBadgeObserverStarted = false;

  revealBody();
  document.documentElement.classList.remove("vortex07-active");
  syncThemeStylesheet(false);

  logCritical(
    "Playvortex is down or unreachable (server/network error). Vortex07 stepped aside — reload when the site works again.",
  );

  return true;
}

function shouldDeferExtensionWork() {
  if (extensionPausedForSite) return true;
  return pauseExtensionForBrokenSite();
}

function normalizeSettings(settings) {
  const merged = { ...defaultSettings, ...(settings || {}) };
  delete merged.reputation;
  delete merged.banArchive;
  return merged;
}

function clearElement(el) {
  while (el.firstChild) el.removeChild(el.firstChild);
}

function safeNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function safeString(value) {
  return String(value || "").trim();
}

function safeLower(value) {
  return safeString(value).toLowerCase();
}

function extractUserIdFromHref(href) {
  const match = safeString(href).match(/\/users\/(\d+)(?:\/|$)/i);
  return match ? safeNumber(match[1]) : null;
}

function escapeHtml(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function highlightMatch(text, query) {
  const cleanText = escapeHtml(text);
  const cleanQuery = safeString(query);

  if (!cleanQuery) return cleanText;

  const escapedQuery = cleanQuery.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regex = new RegExp(`(${escapedQuery})`, "ig");

  return cleanText.replace(
    regex,
    '<span class="vortex07-search-highlight">$1</span>',
  );
}

function safeImageSrc(value, fallback = "") {
  const src = safeString(value);
  if (!src) return fallback;
  if (src.startsWith("data:image/")) return src;
  if (src.startsWith("https://")) return src;
  if (src.startsWith("http://")) return src;
  if (src.startsWith("/")) return `${VORTEX_ORIGIN}${src}`;
  if (src.length > 80 && /^[A-Za-z0-9+/=]+$/.test(src)) {
    return `data:image/png;base64,${src}`;
  }
  return fallback;
}

function extractAvatarUrl(value) {
  if (!value) return "";
  if (typeof value === "string") return safeString(value);
  if (typeof value !== "object") return "";

  const direct = safeString(
    value.dataUri ||
      value.data_uri ||
      value.url ||
      value.image ||
      value.picture ||
      value.avatarUrl ||
      value.avatar_url ||
      value.avatar ||
      value.src,
  );
  if (direct) return direct;

  const base64 = safeString(value.base64 || value.data);
  if (!base64) return "";

  const mime = safeString(value.mime || value.contentType || "image/png");
  if (base64.startsWith("data:image/")) return base64;
  return `data:${mime};base64,${base64}`;
}

function logRepFailureOnce(...args) {
  const now = Date.now();
  if (now - lastRepFailureLogAt < 30000) return;
  lastRepFailureLogAt = now;
  logWarn(...args);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function pruneCircuitFailures(circuit) {
  const now = Date.now();
  circuit.failures = circuit.failures.filter(
    (entry) => now - entry.at < CIRCUIT_FAILURE_WINDOW_MS,
  );
}

function isResilienceFailureStatus(status) {
  return (
    status === 429 ||
    status === 502 ||
    status === 503 ||
    status === 504 ||
    status >= 500
  );
}

function isRetryableResilienceStatus(status) {
  return RETRYABLE_HTTP_STATUSES.has(status);
}

function getResilienceCircuit(name) {
  if (!RESILIENCE_CIRCUITS[name]) {
    RESILIENCE_CIRCUITS[name] = { failures: [], attackModeUntil: 0 };
  }
  return RESILIENCE_CIRCUITS[name];
}

function recordCircuitFailure(circuitName, reason) {
  const circuit = getResilienceCircuit(circuitName);
  const now = Date.now();
  pruneCircuitFailures(circuit);
  circuit.failures.push({ at: now, reason });

  if (circuit.failures.length >= CIRCUIT_FAILURE_THRESHOLD) {
    circuit.attackModeUntil = now + ATTACK_MODE_DURATION_MS;
    circuit.failures = [];
    syncAttackModeBanner();
    logWarn(`Attack mode active for ${circuitName} (${ATTACK_MODE_DURATION_MS / 1000}s)`);
  }

  if (circuitName === "vortex07_api") {
    markRepApiFailure();
  } else if (circuitName === "playvortex") {
    const status = typeof reason === "number" ? reason : 503;
    markPlayvortexApiFailure(status);
  }
}

function recordCircuitSuccess(circuitName) {
  const circuit = getResilienceCircuit(circuitName);
  pruneCircuitFailures(circuit);
  if (Date.now() >= circuit.attackModeUntil) {
    circuit.failures = [];
  }
}

function isCircuitInAttackMode(circuitName) {
  const circuit = getResilienceCircuit(circuitName);
  if (Date.now() < circuit.attackModeUntil) return true;
  if (circuit.attackModeUntil > 0) {
    circuit.attackModeUntil = 0;
    syncAttackModeBanner();
  }
  return false;
}

function isAttackModeActive() {
  return (
    isCircuitInAttackMode("playvortex") || isCircuitInAttackMode("vortex07_api")
  );
}

function shouldSkipNonEssentialPolling() {
  return isAttackModeActive();
}

function getEffectiveGlobalRepIntervalMs() {
  return shouldSkipNonEssentialPolling()
    ? ATTACK_MODE_REP_CACHE_MS
    : GLOBAL_REP_MIN_INTERVAL_MS;
}

function getAttackModeState() {
  return {
    active: isAttackModeActive(),
    playvortex: isCircuitInAttackMode("playvortex"),
    vortex07Api: isCircuitInAttackMode("vortex07_api"),
    until: Math.max(
      getResilienceCircuit("playvortex").attackModeUntil,
      getResilienceCircuit("vortex07_api").attackModeUntil,
    ),
  };
}

function syncAttackModeBanner() {
  const existing = document.getElementById("vortex07-attack-banner");
  if (!isAttackModeActive()) {
    existing?.remove();
    return;
  }

  if (existing) return;

  const alerts = document.getElementById("Alerts");
  if (!alerts) return;

  const banner = document.createElement("div");
  banner.id = "vortex07-attack-banner";
  banner.className = "vortex07-attack-banner";
  banner.textContent =
    "Vortex07: playvortex rate limited — extra requests paused";
  banner.title =
    "Cloudflare limited this tab. Vortex07 will back off for ~15 minutes.";
  alerts.insertAdjacentElement("afterbegin", banner);
}

async function fetchWithResilience(url, options = {}) {
  const {
    circuit = "vortex07_api",
    method = "GET",
    retries = method === "GET" ? RESILIENCE_MAX_RETRIES : 0,
    slowMs = RESILIENCE_SLOW_MS,
    timeoutMs = REP_FETCH_TIMEOUT_MS,
    credentials,
    headers,
    body,
    force = false,
  } = options;

  const effectiveRetries = circuit === "playvortex" ? 0 : retries;

  if (!force && method === "GET" && isCircuitInAttackMode(circuit)) {
    throw new Error(`circuit_open:${circuit}`);
  }

  let lastResponse = null;
  let lastError = null;

  for (let attempt = 0; attempt <= effectiveRetries; attempt += 1) {
    if (attempt > 0) {
      const backoff = Math.min(1000 * 2 ** (attempt - 1), 8000);
      const jitter = Math.floor(Math.random() * 400);
      await sleep(backoff + jitter);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    const startedAt = Date.now();

    try {
      const response = await fetch(url, {
        method,
        credentials,
        headers,
        body,
        signal: controller.signal,
      });

      const elapsed = Date.now() - startedAt;
      lastResponse = response;

      if (elapsed > slowMs) {
        recordCircuitFailure(circuit, "slow");
      } else if (isResilienceFailureStatus(response.status)) {
        recordCircuitFailure(circuit, response.status);
        if (
          attempt < effectiveRetries &&
          method === "GET" &&
          isRetryableResilienceStatus(response.status)
        ) {
          continue;
        }
      } else if (response.ok) {
        recordCircuitSuccess(circuit);
      }

      return response;
    } catch (err) {
      lastError = err;
      const reason = err?.name === "AbortError" ? "timeout" : "network";
      recordCircuitFailure(circuit, reason);
      if (attempt < effectiveRetries && method === "GET") continue;
      throw err;
    } finally {
      clearTimeout(timeoutId);
    }
  }

  if (lastResponse) return lastResponse;
  throw lastError || new Error("fetch failed");
}

function isRepApiAvailable() {
  return Date.now() >= repApiDownUntil;
}

function markRepApiFailure() {
  repApiDownUntil = Date.now() + REP_API_COOLDOWN_MS;
}

function logPlayvortexFailureOnce(...args) {
  const now = Date.now();
  if (now - lastPlayvortexFailureLogAt < 60000) return;
  lastPlayvortexFailureLogAt = now;
  logCritical(...args);
}

function isPlayvortexApiAvailable() {
  return Date.now() >= playvortexApiDownUntil;
}

function isSessionApiAvailable() {
  return Date.now() >= sessionApiDownUntil;
}

function isCloudflareRateLimitText(text) {
  const sample = safeString(text).slice(0, 5000).toLowerCase();
  if (!sample) return false;
  return (
    sample.includes("error 1200") ||
    sample.includes("temporarily rate limited") ||
    (sample.includes("too many requests") &&
      (sample.includes("cloudflare") || sample.includes("ray id")))
  );
}

function parsePlayvortexJsonPayload(text) {
  const raw = safeString(text).trim();
  if (!raw || isCloudflareRateLimitText(raw)) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function markPlayvortexApiFailure(status, options = {}) {
  const severe = Boolean(options.severe || status === 429);
  const cooldown = severe ? PLAYVORTEX_RATE_LIMIT_COOLDOWN_MS : PLAYVORTEX_API_COOLDOWN_MS;

  playvortexApiDownUntil = Date.now() + cooldown;

  if (severe || status === 429) {
    playvortexRateLimitedUntil = Date.now() + cooldown;
    const circuit = getResilienceCircuit("playvortex");
    circuit.attackModeUntil = Date.now() + cooldown;
    circuit.failures = [];
    syncAttackModeBanner();
    logPlayvortexFailureOnce(
      `Playvortex rate limited — pausing extra requests for ${Math.round(cooldown / 60000)} min.`,
    );
    return;
  }

  if (status === 403 || status >= 500) {
    logPlayvortexFailureOnce(
      "Playvortex is having trouble — background requests paused briefly.",
    );
  }
}

function isPlayvortexUserFetchBlocked() {
  return (
    Date.now() < playvortexRateLimitedUntil ||
    Date.now() < playvortexApiDownUntil ||
    isCircuitInAttackMode("playvortex")
  );
}

function isPlayvortexUserRecordPath(path) {
  return /^\/api\/users\/\d+\/?$/.test(String(path || "").split("?")[0]);
}

function rolesSnapshotEqual(a, b) {
  if (!a && !b) return true;
  if (!a || !b) return false;
  return (
    Boolean(a.isStaff) === Boolean(b.isStaff) &&
    Boolean(a.isModerator) === Boolean(b.isModerator) &&
    Boolean(a.isBooster) === Boolean(b.isBooster)
  );
}

function hasFreshUserRolesInCache(userId) {
  const id = safeNumber(userId);
  if (id === null || !profileRoleCache.has(id)) return false;
  const cachedAt = playvortexUserRoleCacheAt.get(id) || 0;
  return Date.now() - cachedAt < PLAYVORTEX_USER_ROLE_CACHE_TTL_MS;
}

function resetFriendBadgeBudgetIfPageChanged() {
  const pageKey = safeString(window.location.pathname);
  if (pageKey === lastFriendBadgePageKey) return;
  lastFriendBadgePageKey = pageKey;
  friendBadgeApiFetchBudget = FRIEND_BADGE_QUEUE_MAX;
}

function drainPlayvortexUserFetchQueue() {
  if (isPlayvortexUserFetchBlocked()) return;
  if (playvortexUserFetchActive >= PLAYVORTEX_USER_FETCH_MAX_CONCURRENT) return;
  if (playvortexUserFetchQueue.length === 0) return;

  const sinceLast = Date.now() - lastPlayvortexUserFetchStartAt;
  if (
    lastPlayvortexUserFetchStartAt > 0 &&
    sinceLast < PLAYVORTEX_USER_FETCH_QUEUE_SPACING_MS
  ) {
    if (playvortexUserFetchQueueTimer) return;
    playvortexUserFetchQueueTimer = setTimeout(() => {
      playvortexUserFetchQueueTimer = null;
      drainPlayvortexUserFetchQueue();
    }, PLAYVORTEX_USER_FETCH_QUEUE_SPACING_MS - sinceLast);
    return;
  }

  const item = playvortexUserFetchQueue.shift();
  if (!item) return;

  playvortexUserFetchActive += 1;
  lastPlayvortexUserFetchStartAt = Date.now();

  void (async () => {
    try {
      item.resolve(await item.run());
    } catch (err) {
      item.reject(err);
    } finally {
      playvortexUserFetchActive -= 1;
      drainPlayvortexUserFetchQueue();
    }
  })();

  if (playvortexUserFetchActive < PLAYVORTEX_USER_FETCH_MAX_CONCURRENT) {
    drainPlayvortexUserFetchQueue();
  }
}

function enqueuePlayvortexUserFetch(run) {
  return new Promise((resolve, reject) => {
    playvortexUserFetchQueue.push({ run, resolve, reject });
    drainPlayvortexUserFetchQueue();
  });
}

function markSessionApiFailure(status) {
  sessionApiDownUntil = Date.now() + SESSION_FETCH_MIN_INTERVAL_MS;
  if (status === 429 || status === 403 || status >= 500) {
    logPlayvortexFailureOnce(
      "Playvortex is rate-limiting session checks — username lookup paused.",
    );
  }
}

async function fetchViaExtensionProxy(url, options = {}) {
  const ext = globalThis.Vortex07Ext?.api || chrome;
  if (typeof ext.runtime?.sendMessage !== "function") {
    throw new Error("extension messaging unavailable");
  }

  const payload = await ext.runtime.sendMessage({
    type: "vortex07-api-fetch",
    url,
    method: options.method || "GET",
    headers: options.headers,
    body: options.body,
    adminAuth: Boolean(options.adminAuth),
  });

  if (!payload || payload.error) {
    throw new Error(payload?.error || "extension api proxy failed");
  }

  return new Response(payload.body, {
    status: payload.status || 0,
    statusText: payload.statusText || "",
    headers: payload.headers || {},
  });
}

function shouldProxyVortexApiUrl(url) {
  try {
    const parsed = new URL(String(url));
    if (parsed.protocol !== "https:") return false;
    if (parsed.hostname === "vortex07.vercel.app") return true;
    return parsed.hostname.endsWith(".vercel.app") && parsed.pathname.startsWith("/api");
  } catch {
    return false;
  }
}

async function fetchReputationRequest(url, options = {}) {
  const method = String(options.method || "GET").toUpperCase();
  const isRepMutation =
    (method === "POST" || method === "DELETE") &&
    String(url).includes("/reputation");
  const noCache =
    Boolean(options.force) ||
    String(url).includes("/reputation") ||
    String(url).includes("/players/batch");

  if (isExtensionContextAlive() && shouldProxyVortexApiUrl(url)) {
    try {
      return await fetchViaExtensionProxy(url, options);
    } catch (err) {
      logRepFailureOnce("Extension API proxy failed, retrying direct:", err);
    }
  }

  if (isRepMutation) {
    throw new Error("Reputation votes must use the extension proxy");
  }

  return fetchWithResilience(url, {
    circuit: "vortex07_api",
    method,
    timeoutMs: REP_FETCH_TIMEOUT_MS,
    credentials: options.credentials,
    headers: options.headers,
    body: options.body,
    force: noCache,
  });
}

function isContextInvalidatedError(err) {
  const msg = String(err?.message || err || "").toLowerCase();
  return msg.includes("extension context invalidated");
}

function isExtensionContextAlive() {
  if (!extensionContextValid) return false;

  const check = globalThis.Vortex07Ext?.isContextAlive;
  if (typeof check === "function") {
    const alive = check();
    if (!alive) extensionContextValid = false;
    return alive;
  }

  try {
    if (!ext.runtime?.id) {
      extensionContextValid = false;
      return false;
    }
    return true;
  } catch (err) {
    if (isContextInvalidatedError(err)) extensionContextValid = false;
    return false;
  }
}

function shutdownStaleContentScript(reason) {
  if (!extensionContextValid && !layoutGuardObserver && !pageLayoutObserver) {
    return;
  }

  extensionContextValid = false;
  layoutGuardStarted = false;
  pageObserverStarted = false;

  if (layoutGuardObserver) {
    layoutGuardObserver.disconnect();
    layoutGuardObserver = null;
  }

  if (pageLayoutObserver) {
    pageLayoutObserver.disconnect();
    pageLayoutObserver = null;
  }

  if (searchDebounceTimer) {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = null;
  }

  logDebug("Content script halted:", reason);
  maybeShowRefreshBanner();
}

function maybeShowRefreshBanner() {
  if (document.getElementById("vortex07-refresh-banner")) return;

  const banner = document.createElement("div");
  banner.id = "vortex07-refresh-banner";
  banner.textContent = "Vortex07 updated — refresh this page (F5)";
  banner.style.cssText =
    "position:fixed;bottom:0;left:0;right:0;z-index:2147483646;background:#d8d3ec;border-top:1px solid #808080;padding:4px 8px;text-align:center;color:#000;cursor:pointer;";
  banner.addEventListener("click", () => location.reload());

  (document.body || document.documentElement).appendChild(banner);
}

function mergeSessionStorageDefaults(defaults) {
  const out = { ...defaults };

  if (Object.prototype.hasOwnProperty.call(defaults, REPUTATION_VOTER_KEY)) {
    out[REPUTATION_VOTER_KEY] =
      sessionMemoryStore.voterId || defaults[REPUTATION_VOTER_KEY];
  }

  if (Object.prototype.hasOwnProperty.call(defaults, REPUTATION_MY_VOTES_KEY)) {
    out[REPUTATION_MY_VOTES_KEY] = {
      ...(defaults[REPUTATION_MY_VOTES_KEY] || {}),
      ...sessionMemoryStore.myVotes,
    };
  }

  if (Object.prototype.hasOwnProperty.call(defaults, REPUTATION_CACHE_KEY)) {
    out[REPUTATION_CACHE_KEY] = {
      ...(defaults[REPUTATION_CACHE_KEY] || {}),
      ...sessionMemoryStore.repCache,
    };
  }

  if (Object.prototype.hasOwnProperty.call(defaults, REPUTATION_PENDING_KEY)) {
    out[REPUTATION_PENDING_KEY] = sessionMemoryStore.pendingVotes.length
      ? [...sessionMemoryStore.pendingVotes]
      : defaults[REPUTATION_PENDING_KEY];
  }

  return out;
}

function applySessionStorageSet(payload) {
  if (payload[REPUTATION_VOTER_KEY]) {
    sessionMemoryStore.voterId = payload[REPUTATION_VOTER_KEY];
  }

  if (payload[REPUTATION_MY_VOTES_KEY]) {
    sessionMemoryStore.myVotes = {
      ...sessionMemoryStore.myVotes,
      ...payload[REPUTATION_MY_VOTES_KEY],
    };
  }

  if (payload[REPUTATION_CACHE_KEY]) {
    sessionMemoryStore.repCache = {
      ...sessionMemoryStore.repCache,
      ...payload[REPUTATION_CACHE_KEY],
    };
  }

  if (payload[REPUTATION_PENDING_KEY]) {
    sessionMemoryStore.pendingVotes = Array.isArray(payload[REPUTATION_PENDING_KEY])
      ? [...payload[REPUTATION_PENDING_KEY]]
      : sessionMemoryStore.pendingVotes;
  }
}

function storageGet(area, defaults) {
  if (area === "local") {
    defaults = mergeSessionStorageDefaults(defaults);
  }

  if (!isExtensionContextAlive()) {
    return Promise.resolve(defaults);
  }

  const extStorage = globalThis.Vortex07Ext?.storageGet;
  if (typeof extStorage !== "function") {
    logWarn(`storage.${area} unavailable`);
    return Promise.resolve(defaults);
  }

  return extStorage(area, defaults).catch((err) => {
    if (isContextInvalidatedError(err)) {
      shutdownStaleContentScript("storage.get promise");
    } else {
      logWarn(`storage.${area}.get failed:`, err);
    }
    return defaults;
  });
}

function storageSet(area, payload) {
  if (area === "local") applySessionStorageSet(payload);

  if (!isExtensionContextAlive()) {
    return Promise.resolve();
  }

  const extStorage = globalThis.Vortex07Ext?.storageSet;
  if (typeof extStorage !== "function") {
    logWarn(`storage.${area} unavailable`);
    return Promise.resolve();
  }

  return extStorage(area, payload).catch((err) => {
    if (isContextInvalidatedError(err)) {
      shutdownStaleContentScript("storage.set promise");
    } else {
      logWarn(`storage.${area}.set failed:`, err);
    }
  });
}

function isElementInDocument(el) {
  return Boolean(el && document.documentElement.contains(el));
}

function isInsideVortexShell(el) {
  const container = document.getElementById("Container");
  return Boolean(container && el && container.contains(el));
}

function areObserverMutationsPaused() {
  return observerMutationsPaused > 0;
}

function withDomEnhancementPaused(fn) {
  observerMutationsPaused += 1;
  try {
    return fn();
  } finally {
    observerMutationsPaused = Math.max(0, observerMutationsPaused - 1);
  }
}

function notePathnameChange() {
  const path = safeString(window.location.pathname);
  if (path === lastKnownPathname) return false;
  lastKnownPathname = path;
  lastEnhancedProfileKey = "";
  lastProfileBadgeRefreshUserId = null;
  lastGameRatingGameId = null;
  resetFriendBadgeBudgetIfPageChanged();
  if (path !== "/home" && path !== "/") {
    homeLeaderboardInjected = false;
    homeActivityInjected = false;
  }
  return true;
}

function resolvePageRouteKey() {
  const path = window.location.pathname.replace(/\/+$/, "") || "/";
  if (path === "/" || path === "/home") return "home";
  if (path === "/social") return "social";
  if (path.startsWith("/catalog")) return "catalog";
  if (path.includes("/profile")) return "profile";
  if (path === "/download") return "download";
  if (path === "/settings") return "settings";
  if (path.startsWith("/games/")) return "game";
  return "page";
}

function stripRouteClasses(el) {
  if (!el?.classList) return;
  [...el.classList].forEach((cls) => {
    if (cls.startsWith(VORTEX07_ROUTE_CLASS_PREFIX)) {
      el.classList.remove(cls);
    }
  });
}

function syncPageRouteClasses() {
  const container = document.getElementById("Container");
  if (!container) return;

  const routeKey = resolvePageRouteKey();
  stripRouteClasses(container);
  container.classList.add(`${VORTEX07_ROUTE_CLASS_PREFIX}${routeKey}`);

  const page = document.querySelector("#Body > .page, #Body > .catalog-container");
  if (!page) return;

  stripRouteClasses(page);
  page.classList.add(`${VORTEX07_ROUTE_CLASS_PREFIX}${routeKey}`, "vortex07-page-shell");
}

function enhanceSurfaceChrome() {
  document
    .querySelectorAll(
      "#Container .games-section .section-link, #Container .home-section .section-link, #Container .friends-section .section-link",
    )
    .forEach((link) => {
      link.classList.add("vortex07-section-action");
    });

  const socialPage = document.querySelector("#Body > .page:has(.tab-bar)");
  if (socialPage) {
    socialPage.classList.add("vortex07-social-shell");
  }

  const catalogPage = document.querySelector("#Body > .catalog-container");
  if (catalogPage) {
    catalogPage.classList.add("vortex07-catalog-shell");
  }

  const gamePage = document.querySelector(
    "#Body > .page:has(.game-detail-header), #Body > .page:has(.game-banner), #Body > .page:has(.game-stat)",
  );
  if (gamePage) {
    gamePage.classList.add("vortex07-game-shell");
  }

  const downloadPage = document.querySelector(
    "#Body > .page:has(.dl-card-platform), #Body > .page:has(.btn-download), #Body > .page:has([class*='dl-'])",
  );
  if (downloadPage) {
    downloadPage.classList.add("vortex07-download-shell");
  }

  document
    .querySelectorAll("#Container .tab-bar, #Container .user-grid, #Container .user-list")
    .forEach((el) => {
      el.classList.add("vortex07-social-surface");
    });

  enhanceSocialPage();
}

function resolveSocialEmptyMessage(page) {
  const activeTab = page.querySelector(".tab-btn.active");
  const tabText = safeLower(activeTab?.textContent || "");

  if (tabText.includes("request")) return "No pending requests";
  if (tabText.includes("friend")) return "No friends yet";
  if (tabText.includes("following")) return "Not following anyone yet";
  if (tabText.includes("follower")) return "No followers yet";
  if (tabText.includes("blocked")) return "No blocked users";
  return "Nothing here yet";
}

function enhanceSocialEmptyStates(page) {
  const emptyMessage = resolveSocialEmptyMessage(page);

  page.querySelectorAll(".empty-msg").forEach((el) => {
    el.classList.add("vortex07-social-empty");
  });

  page.querySelectorAll(".user-list, .user-grid, .friends-grid").forEach((container) => {
    const hasContent = container.querySelector(
      ".user-row, .user-card, .friend-card, .empty-msg, .vortex07-social-empty",
    );
    if (hasContent) return;

    if (container.dataset.vortex07EmptyInjected === "1") return;
    container.dataset.vortex07EmptyInjected = "1";

    const empty = document.createElement("div");
    empty.className = "vortex07-social-empty";
    empty.textContent = emptyMessage;
    container.appendChild(empty);
  });
}

function enhanceSocialPage() {
  if (!currentSettings.enabled) return;

  const socialPage = document.querySelector("#Body > .page:has(.tab-bar)");
  if (!socialPage) return;

  socialPage.classList.add("vortex07-social-shell");

  socialPage.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.add("vortex07-social-tab");
    btn.classList.toggle("vortex07-social-tab-active", btn.classList.contains("active"));
  });

  ensureSocialFriendSearch(socialPage);

  socialPage.querySelectorAll("#req-badge, .tab-btn .badge").forEach((badge) => {
    badge.classList.add("vortex07-pending-badge");
  });

  socialPage
    .querySelectorAll("#tab-content, .tab-content, .user-list, .user-grid")
    .forEach((el) => {
      el.classList.add("vortex07-social-tab-panel");
    });

  socialPage.querySelectorAll(".user-list .user-row, .user-row").forEach((row) => {
    row.classList.add("vortex07-social-user-row");

    const userId = getUserIdFromRepNode(row);
    if (userId !== null) row.dataset.vortex07UserId = String(userId);

    const actions = row.querySelector(".user-row-actions");
    const actionText = safeLower(actions?.textContent || "");
    const activeTab = socialPage.querySelector(".tab-btn.active");
    const onRequestsTab = safeLower(activeTab?.textContent || "").includes("request");
    const isRequest =
      onRequestsTab ||
      /accept|decline|cancel request|remove request/.test(actionText);
    row.classList.toggle("vortex07-friend-request-row", isRequest);

    const nameEl = row.querySelector(".user-row-name");
    if (nameEl) nameEl.classList.add("vortex07-user-name-row");
  });

  socialPage.querySelectorAll(".user-card").forEach((card) => {
    card.classList.add("vortex07-social-user-card", "vortex07-friend-tile");

    const userId = getUserIdFromRepNode(card);
    if (userId !== null) card.dataset.vortex07UserId = String(userId);

    const nameEl = card.querySelector(".user-card-name");
    if (nameEl) nameEl.classList.add("vortex07-user-name-row");
  });

  socialPage.querySelectorAll(".pagination").forEach((pagination) => {
    pagination.classList.add("vortex07-social-pagination");
    pagination.querySelectorAll("button").forEach((btn) => {
      if (currentSettings.retroButtons) btn.classList.add("rbx-2007-btn");
    });
  });

  enhanceSocialEmptyStates(socialPage);
}

function ensureSocialFriendSearch(socialPage) {
  const friendsTab = [...socialPage.querySelectorAll(".tab-btn")].find((btn) =>
    safeLower(btn.textContent).includes("friend") &&
    !safeLower(btn.textContent).includes("request"),
  );
  if (!friendsTab) return;

  let searchWrap = socialPage.querySelector(".vortex07-social-friend-search-wrap");
  if (!searchWrap) {
    searchWrap = document.createElement("div");
    searchWrap.className = "vortex07-social-friend-search-wrap";
    searchWrap.innerHTML =
      '<label class="vortex07-social-friend-search-label" for="vortex07-socialFriendSearch">Search friends</label><input type="search" id="vortex07-socialFriendSearch" class="vortex07-social-friend-search" placeholder="Search friends by name…" autocomplete="off" spellcheck="false" />';

    const tabPanel =
      socialPage.querySelector("#tab-content, .tab-content") ||
      friendsTab.parentElement;
    tabPanel?.insertAdjacentElement("afterbegin", searchWrap);

    const input = searchWrap.querySelector("#vortex07-socialFriendSearch");
    input?.addEventListener("input", () => {
      filterSocialFriendsList(socialPage, input.value);
    });
  }

  filterSocialFriendsList(
    socialPage,
    searchWrap.querySelector("#vortex07-socialFriendSearch")?.value || "",
  );
}

function getSocialFriendSearchText(node) {
  const nameEl = node.querySelector(".user-row-name, .user-card-name, .friend-name");
  return safeLower(nameEl?.textContent || node.textContent || "");
}

function filterSocialFriendsList(socialPage, query) {
  const needle = safeLower(query).trim();
  const rows = socialPage.querySelectorAll(".user-list .user-row, .user-grid .user-card");
  let visible = 0;

  rows.forEach((row) => {
    if (row.classList.contains("vortex07-friend-request-row")) return;
    const haystack = getSocialFriendSearchText(row);
    const match = !needle || haystack.includes(needle);
    row.classList.toggle("vortex07-social-friend-hidden", !match);
    if (match) visible += 1;
  });

  let empty = socialPage.querySelector(".vortex07-social-friend-search-empty");
  if (needle && visible === 0) {
    if (!empty) {
      empty = document.createElement("p");
      empty.className = "vortex07-social-friend-search-empty vortex07-social-empty";
      socialPage.querySelector(".user-list, .user-grid")?.appendChild(empty);
    }
    empty.textContent = `No friends match "${query.trim()}".`;
    empty.hidden = false;
  } else {
    empty?.remove();
  }
}

function formatArchiveLastSeen(timestamp) {
  const value = Number(timestamp);
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return `Last seen ${date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  })}`;
}

function profileEnhanceKey(userId) {
  const id = safeNumber(userId);
  if (id === null) return "";
  notePathnameChange();
  return `${lastKnownPathname || window.location.pathname}:${id}`;
}

function hasUnreplacedNativeBadges(root) {
  if (!root?.querySelector) return false;

  const selector = [
    `${VORTEX07_NATIVE_STAFF_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
    `${VORTEX07_NATIVE_BOOSTER_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
    `${VORTEX07_NATIVE_MODERATOR_SELECTOR}:not([data-vortex07-retro]):not(.vortex07-retro-badge-wrap)`,
  ].join(", ");

  return Boolean(root.querySelector(selector));
}

function resolveProfileBadgeHost(header) {
  const usernameEl = header?.querySelector(".profile-username");
  if (!usernameEl) return null;
  return usernameEl.querySelector(".profile-badges") || usernameEl;
}

function profileBadgesNeedRefresh(header, userId) {
  if (!header || userId === null) return true;
  if (hasUnreplacedNativeBadges(header)) return true;

  const badgeHost = resolveProfileBadgeHost(header);
  if (!badgeHost) return true;

  const mergedRoles = resolvePlayerRoles(userId, readRolesFromScope(header));
  const desiredKinds = resolveBadgeKinds(userId, mergedRoles);

  if (!badgesMatchDesiredState(badgeHost, desiredKinds)) return true;

  return desiredKinds.some((kind) => {
    const wrap = badgeHost.querySelector(`[data-vortex07-badge-kind="${kind}"]`);
    const img = wrap?.querySelector(".vortex07-retro-badge-img");
    return !img?.getAttribute("src");
  });
}

function isProfileBadgeRelevantMutation(mutation) {
  if (!(mutation.target instanceof Element)) return false;

  if (
    mutation.target.closest(
      ".vortex07-retro-badge-wrap, .vortex07-reputation-panel, #vortex07-hover-preview",
    )
  ) {
    return false;
  }

  const profileScope =
    ".profile-header, .profile-username, .profile-badges, .friend-card, .user-card, .user-row, .friend-name";

  if (mutation.type === "childList") {
    const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
    return nodes.some((node) => {
      if (node instanceof Element) {
        return (
          node.matches?.(
            ".profile-header, .profile-username, .profile-badges, .staff-badge-icon, .boost-badge-icon, .moderator-badge-icon, .friend-name",
          ) || Boolean(node.closest?.(profileScope))
        );
      }
      return Boolean(node.parentElement?.closest?.(profileScope));
    });
  }

  if (mutation.type === "attributes") {
    return Boolean(mutation.target.closest?.(profileScope));
  }

  return false;
}

/* ========================================================= */
/* ================= API QUEUE / CACHE ===================== */
/* ========================================================= */

function apiEndpointKey(urlString) {
  try {
    const url = new URL(urlString);
    return `${url.origin}${url.pathname}`;
  } catch {
    return safeString(urlString);
  }
}

function apiCacheKey(method, urlString) {
  try {
    const url = new URL(urlString);
    return `${method}:${url.pathname}${url.search}`;
  } catch {
    return `${method}:${urlString}`;
  }
}

function readApiCacheEntry(key) {
  const entry = apiRequestState.cache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.at > API_CACHE_TTL_MS) {
    apiRequestState.cache.delete(key);
    return null;
  }
  return entry;
}

function writeApiCacheEntry(key, value) {
  apiRequestState.cache.set(key, { at: Date.now(), value });
}

function drainApiRequestQueue() {
  if (apiRequestState.active >= API_MAX_CONCURRENT_REQUESTS) return;
  if (apiRequestState.queue.length === 0) return;

  const sinceGlobal = Date.now() - apiRequestState.lastGlobalAt;
  if (sinceGlobal < API_GLOBAL_MIN_DELAY_MS) {
    setTimeout(drainApiRequestQueue, API_GLOBAL_MIN_DELAY_MS - sinceGlobal);
    return;
  }

  const item = apiRequestState.queue.shift();
  if (!item) return;

  const endpoint = apiEndpointKey(item.url);
  const sinceEndpoint = Date.now() - (apiRequestState.endpointLastAt.get(endpoint) || 0);
  if (sinceEndpoint < API_ENDPOINT_MIN_DELAY_MS) {
    apiRequestState.queue.unshift(item);
    setTimeout(drainApiRequestQueue, API_ENDPOINT_MIN_DELAY_MS - sinceEndpoint);
    return;
  }

  apiRequestState.active += 1;
  apiRequestState.lastGlobalAt = Date.now();
  apiRequestState.endpointLastAt.set(endpoint, Date.now());

  void (async () => {
    try {
      item.resolve(await item.run());
    } catch (err) {
      item.reject(err);
    } finally {
      apiRequestState.active -= 1;
      drainApiRequestQueue();
    }
  })();
}

function enqueueManagedApiRequest(url, run) {
  const cacheKey = apiCacheKey("GET", url);
  if (apiRequestState.inflight.has(cacheKey)) {
    return apiRequestState.inflight.get(cacheKey);
  }

  const promise = new Promise((resolve, reject) => {
    apiRequestState.queue.push({ url, run, resolve, reject });
    drainApiRequestQueue();
  }).finally(() => {
    apiRequestState.inflight.delete(cacheKey);
  });

  apiRequestState.inflight.set(cacheKey, promise);
  return promise;
}

async function managedPlayvortexGet(urlString, fetchOptions = {}, cacheOptions = {}) {
  const cacheKey = apiCacheKey("GET", urlString);
  const cached = readApiCacheEntry(cacheKey);
  const allowStale = cacheOptions.allowStale !== false;

  if (cached && !cacheOptions.forceRefresh) {
    if (allowStale && Date.now() - cached.at > API_CACHE_TTL_MS * 0.5) {
      void enqueueManagedApiRequest(urlString, async () => {
        try {
          const fresh = await fetchWithResilience(urlString, fetchOptions);
          if (fresh?.ok) {
            const text = await fresh.clone().text();
            const json = parsePlayvortexJsonPayload(text);
            if (json !== null) writeApiCacheEntry(cacheKey, json);
          }
        } catch {
          /* stale-while-revalidate — ignore background refresh errors */
        }
      }).catch(() => {});
    }
    return cached.value;
  }

  return enqueueManagedApiRequest(urlString, async () => {
    const response = await fetchWithResilience(urlString, fetchOptions);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const rawText = await response.text();
    if (isCloudflareRateLimitText(rawText)) {
      markPlayvortexApiFailure(429, { severe: true });
      throw new Error("rate_limited");
    }
    const json = parsePlayvortexJsonPayload(rawText);
    if (json === null) throw new Error("Invalid JSON response");
    writeApiCacheEntry(cacheKey, json);
    return json;
  });
}

/* ========================================================= */
/* ================= API SUBSYSTEM ========================= */
/* ========================================================= */

const vortexApi = {
  async get(path, params = {}, options = {}) {
    const userInitiated = Boolean(options.userInitiated);
    const userRecordPath = isPlayvortexUserRecordPath(path);

    if (userRecordPath && isPlayvortexUserFetchBlocked()) {
      logApi("GET skipped (playvortex user cooldown):", path);
      return null;
    }

    if (!userInitiated && !isPlayvortexApiAvailable()) {
      logApi("GET skipped (playvortex cooldown):", path);
      return null;
    }

    const url = new URL(path, VORTEX_ORIGIN);
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "")
        url.searchParams.set(key, String(value));
    });

    logApi("GET", url.pathname + url.search);

    const cacheKey = apiCacheKey("GET", url.toString());
    const cached = readApiCacheEntry(cacheKey);
    if (cached && !options.forceRefresh) {
      logApi(`${url.pathname} cache hit`);
      if (Date.now() - cached.at > API_CACHE_TTL_MS * 0.5) {
        void managedPlayvortexGet(
          url.toString(),
          {
            circuit: "playvortex",
            method: "GET",
            timeoutMs: API_REQUEST_TIMEOUT_MS,
            credentials: "include",
            headers: { Accept: "application/json" },
            force: userInitiated,
            retries: API_MAX_RETRIES,
          },
          { allowStale: true, forceRefresh: true },
        ).catch(() => {});
      }
      return cached.value;
    }

    try {
      const json = await managedPlayvortexGet(
        url.toString(),
        {
          circuit: "playvortex",
          method: "GET",
          timeoutMs: API_REQUEST_TIMEOUT_MS,
          credentials: "include",
          headers: { Accept: "application/json" },
          force: userInitiated,
          retries: API_MAX_RETRIES,
        },
        { forceRefresh: Boolean(options.forceRefresh) },
      );

      logApi(`${url.pathname} response:`, json);
      return json;
    } catch (err) {
      if (err?.message === "rate_limited") {
        return null;
      }
      if (err?.message?.startsWith("HTTP ")) {
        const status = Number(err.message.replace("HTTP ", ""));
        if (status === 429 || status === 403 || status >= 500) {
          markPlayvortexApiFailure(status, { severe: status === 429 });
        }
      }
      if (err?.message?.startsWith("circuit_open:")) {
        logApi("GET skipped (attack mode):", path);
        return null;
      }
      if (err.name === "AbortError") logWarn(`API timeout: ${url.pathname}`);
      else logWarn(`API failed: ${url.pathname}`, err);
      return null;
    }
  },
};

function normalizePlayer(rawPlayer) {
  if (!rawPlayer || typeof rawPlayer !== "object") return null;

  const id = safeNumber(rawPlayer.id ?? rawPlayer.userId ?? rawPlayer.user_id);
  if (id === null) return null;

  const username = safeString(
    rawPlayer.username ||
      rawPlayer.name ||
      rawPlayer.userName ||
      rawPlayer.user_name,
  );
  const displayName = safeString(
    rawPlayer.displayName ||
      rawPlayer.display_name ||
      rawPlayer.nickname ||
      username,
  );
  if (!username) return null;

  const detection = detectBannedStatus(rawPlayer);
  const player = {
    id,
    username,
    displayName: displayName || username,
    isBanned: detection.isBanned,
    bannedDetectedBy: detection.detectedBy,
    bannedRawValue: detection.rawValue,
    onlineStatus: readOnlineStatus(rawPlayer),
    roles: readPlayerRoles(rawPlayer),
    avatarUrl: extractAvatarUrl(
      rawPlayer.avatarUrl ||
        rawPlayer.avatar_url ||
        rawPlayer.avatar ||
        rawPlayer.picture ||
        rawPlayer.profilePicture ||
        rawPlayer.profile_picture ||
        rawPlayer.headshot,
    ),
  };

  logBannedCandidate(rawPlayer, player, detection);
  if (playerPayloadHasRoleSignals(rawPlayer)) {
    rememberPlayvortexUserRoles(rawPlayer);
  }
  player.roles = resolvePlayerRoles(id, readPlayerRoles(rawPlayer));
  return player;
}

function normalizeAvatarMap(rawAvatarResponse) {
  const avatarMap = new Map();
  if (!rawAvatarResponse) return avatarMap;

  if (Array.isArray(rawAvatarResponse)) {
    rawAvatarResponse.forEach((entry) => {
      if (!entry || typeof entry !== "object") return;
      const numericId = Number(
        entry.id ?? entry.userId ?? entry.user_id ?? entry.uid,
      );
      const avatarUrl = extractAvatarUrl(
        entry.dataUri ||
          entry.avatarUrl ||
          entry.avatar ||
          entry.picture ||
          entry.image ||
          entry.url ||
          entry,
      );
      if (!Number.isFinite(numericId) || !avatarUrl) return;
      avatarMap.set(numericId, avatarUrl);
    });
    return avatarMap;
  }

  if (typeof rawAvatarResponse !== "object") return avatarMap;

  const source =
    rawAvatarResponse.avatars ||
    rawAvatarResponse.pictures ||
    rawAvatarResponse.data ||
    rawAvatarResponse;

  if (!source || typeof source !== "object" || Array.isArray(source))
    return avatarMap;

  Object.entries(source).forEach(([id, value]) => {
    const numericId = Number(id);
    const avatarUrl = extractAvatarUrl(value);
    if (!Number.isFinite(numericId) || !avatarUrl) return;
    avatarMap.set(numericId, avatarUrl);
  });

  return avatarMap;
}

/* ========================================================= */
/* ================= INIT ================================== */
/* ========================================================= */

async function fetchRepAudit(options = {}) {
  const apiBase = getVortex07ApiBase();
  if (!apiBase || !isVortex07DeveloperSession()) return null;

  const limit = Math.min(Math.max(Number(options.limit) || 100, 1), 500);
  const params = new URLSearchParams({ limit: String(limit) });
  if (options.targetUserId) {
    params.set("targetUserId", String(options.targetUserId));
  }

  try {
    const response = await fetchViaExtensionProxy(
      `${apiBase}/rep-audit?${params.toString()}`,
      {
        headers: { Accept: "application/json" },
        adminAuth: true,
      },
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (err) {
    logWarn("Rep audit fetch failed:", err);
    return null;
  }
}

globalThis.Vortex07Api = {
  getApiBase: getVortex07ApiBase,
  fetchBatchPlayerData,
  fetchLeaderboard,
  fetchPlayerAvatars,
  fetchRepAudit,
  fetchWithResilience,
  getAttackModeState,
  isAttackModeActive,
  clearApiCache: () => apiRequestState.cache.clear(),
};

async function initVortex07() {
  logDebug("Starting Vortex07", VORTEX07_VERSION);

  lastKnownPathname = safeString(window.location.pathname);

  await loadKnownBoosterIds();
  preloadBadgeAssets();

  const data = await storageGet("sync", { vortex07Settings: defaultSettings });
  currentSettings = normalizeSettings(data.vortex07Settings);
  logDebug("Loaded settings:", currentSettings);

  const enabled = Boolean(currentSettings.enabled);

  document.documentElement.classList.toggle("vortex07-active", enabled);
  applyThemePreferences(currentSettings);
  await syncThemeStylesheet(enabled);

  if (!enabled) {
    revealBody();
    logCritical(
      "Vortex07 is OFF in the popup — enable it to restore the 2007 shell, search, and reputation.",
    );
    return;
  }

  if (shouldDeferExtensionWork()) return;

  enableLayoutLoadingHide();
  startHoverLoop();
  startObserver();
  startProfileBadgeObserver();
  startLayoutBootRetry();

  void syncPendingReputationVotes().catch((err) => {
    logRepFailureOnce("Pending rep sync on init failed:", err);
  });
}

let layoutBootTimer = null;

function startLayoutBootRetry() {
  if (layoutBootTimer) return;

  let attempts = 0;
  const maxAttempts = 45;

  const tick = () => {
    if (!currentSettings.enabled || is2007Applied) {
      layoutBootTimer = null;
      return;
    }

    if (shouldDeferExtensionWork()) {
      layoutBootTimer = null;
      revealBody();
      return;
    }

    attempts += 1;
    build2007Layout();

    if (is2007Applied) {
      layoutBootTimer = null;
      logDebug("Layout boot succeeded on attempt", attempts);
      return;
    }

    if (attempts >= maxAttempts) {
      layoutBootTimer = null;
      logCritical(
        "Layout shell delayed — running search, rep, and layout fixes in fallback mode.",
      );
      bootstrapFeaturesWithoutShell();
      return;
    }

    layoutBootTimer = setTimeout(tick, 1000);
  };

  tick();
}

if (globalThis.Vortex07Ext?.onStorageChanged) {
  try {
    globalThis.Vortex07Ext.onStorageChanged((changes, namespace) => {
      if (!isExtensionContextAlive()) return;
      if (namespace !== "sync" || !changes.vortex07Settings) return;

    const oldSettings = currentSettings;
    const newSettings = normalizeSettings(changes.vortex07Settings.newValue);

    currentSettings = newSettings;

    logDebug("Settings changed:", currentSettings);

    const enabledChanged = oldSettings.enabled !== newSettings.enabled;
    const navChanged = oldSettings.customNav !== newSettings.customNav;
    const themeChanged = oldSettings.darkMode !== newSettings.darkMode;

    if (enabledChanged || navChanged) {
      location.reload();
      return;
    }

    if (themeChanged) {
      applyThemePreferences(newSettings);
    }

    if (oldSettings.iconCache !== newSettings.iconCache) {
      extensionAssetUrlCache.clear();
    }

    updateFooterState();
    updateRetroButtonState();

    if (oldSettings.friendRowCarousels !== newSettings.friendRowCarousels) {
      if (newSettings.friendRowCarousels) enhanceFriendsCarousels();
      else removeFriendCarousels();
    }

    if (currentSettings.userSearch) ensureSearchSystem();
    else removeUserSearch();

    const forumChanged = oldSettings.showForum !== newSettings.showForum;
    if (forumChanged) {
      const navActions = document.querySelector(
        "#Container .Navigation .navbar-actions",
      );
      injectVortex07ExtensionNavs(navActions);
      syncVortex07ExtensionVisibility();
    }
  });
  } catch (err) {
    if (isContextInvalidatedError(err)) shutdownStaleContentScript("storage.onChanged");
  }
}

(async () => {
  installPlayvortexFetchInterceptor();
  try {
    await initVortex07();
  } catch (err) {
    logError("Init failed:", err);
  } finally {
    revealBody();
  }
})();
