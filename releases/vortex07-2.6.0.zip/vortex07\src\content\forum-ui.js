/* Vortex07 forum — General board, nested replies, reply likes. */
(function initVortex07ForumUi(global) {
  const FORUM_CATEGORY = "general";
  const TITLE_MAX = 120;
  const BODY_MAX = 1000;

  let activeThreadId = null;
  let showNewThread = false;
  let threadSearch = "";
  let threadSort = "active";
  let replyTargetPostId = null;
  let cachedFeed = { threads: [], authors: {}, avatars: {} };

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function formatRelativeWhen(ts) {
    const n = Number(ts);
    if (!Number.isFinite(n) || n <= 0) return "—";
    const diff = Date.now() - n;
    const sec = Math.floor(diff / 1000);
    if (sec < 60) return "now";
    const min = Math.floor(sec / 60);
    if (min < 60) return `${min}m`;
    const hr = Math.floor(min / 60);
    if (hr < 48) return `${hr}h`;
    const day = Math.floor(hr / 24);
    if (day < 14) return `${day}d`;
    return new Date(n).toLocaleDateString(undefined, { month: "short", day: "numeric" });
  }

  function formatWhen(ts) {
    const n = Number(ts);
    if (!Number.isFinite(n) || n <= 0) return "—";
    return new Date(n).toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  }

  function renderBody(body) {
    return escapeHtml(body).replace(/\n/g, "<br>");
  }

  function profileFor(userId) {
    const key = String(userId || "");
    return {
      author: cachedFeed.authors[key] || cachedFeed.authors[Number(userId)] || null,
      avatar:
        cachedFeed.avatars[key] ||
        cachedFeed.avatars[Number(userId)] ||
        "",
    };
  }

  function setFeedContext(feed) {
    cachedFeed = {
      threads: feed?.threads || [],
      authors: feed?.authors || {},
      avatars: feed?.avatars || {},
    };
  }

  function avatarHtml(api, userId, authorName, compact = false) {
    const { avatar } = profileFor(userId);
    if (typeof api?.buildAvatarHtml === "function") {
      return api.buildAvatarHtml(userId, authorName, avatar, compact);
    }
    const name = escapeHtml(authorName || "Guest");
    const cls = compact ? "vortex07-forum-avatar-wrap is-guest is-compact" : "vortex07-forum-avatar-wrap is-guest";
    return `<span class="${cls}"><span class="vortex07-forum-avatar-letter">${name.charAt(0).toUpperCase()}</span></span>`;
  }

  function authorLink(authorName, authorUserId) {
    const name = escapeHtml(authorName || "Guest");
    if (authorUserId) {
      return `<a class="vortex07-forum-author" href="/users/${Number(authorUserId)}/profile">${name}</a>`;
    }
    return `<span class="vortex07-forum-author">${name}</span>`;
  }

  function bindCharCounter(root, selector, max) {
    root.querySelectorAll(selector).forEach((textarea) => {
      const field = textarea.closest(".vortex07-forum-field");
      let counter = field?.querySelector(".vortex07-forum-char-count");
      if (!counter && field) {
        counter = document.createElement("span");
        counter.className = "vortex07-forum-char-count";
        field.appendChild(counter);
      }
      const update = () => {
        const len = textarea.value.length;
        if (counter) counter.textContent = `${len}/${max}`;
      };
      textarea.addEventListener("input", update);
      update();
    });
  }

  function buildShellHtml() {
    return `
      <div class="vortex07-forum-shell">
        <header class="vortex07-forum-titlebar">
          <h1 class="vortex07-forum-heading">Forum</h1>
          <span class="vortex07-forum-board-tag">General</span>
        </header>
        <div class="vortex07-forum-client">
          <div class="vortex07-forum-toolbar" id="vortex07-forumToolbar"></div>
          <div class="vortex07-forum-body" id="vortex07-forumBody">
            <p class="vortex07-forum-loading">Loading…</p>
          </div>
        </div>
        <footer class="vortex07-forum-statusbar">
          <span id="vortex07-forumStatus">Vortex07</span>
        </footer>
      </div>
    `;
  }

  function forumErrorMessage(result, fallback) {
    const reason = result?.reason;
    if (reason === "rate-limit") return "Rate limited.";
    if (reason === "no-api") return "Forum unavailable.";
    if (reason === "not-deployed") return "Deploy API: npm run api:deploy";
    if (reason === "network") return "Network error.";
    if (reason === "empty-title" || reason === "empty-body" || reason === "empty") {
      return "Title and message required.";
    }
    if (reason && reason !== "error") return `Error: ${reason}`;
    return fallback;
  }

  function sortThreads(threads) {
    const rows = [...threads];
    if (threadSort === "newest") {
      rows.sort((a, b) => (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0));
      return rows;
    }
    if (threadSort === "replies") {
      rows.sort(
        (a, b) =>
          (Number(b.replyCount) || 0) - (Number(a.replyCount) || 0) ||
          (Number(b.lastReplyAt) || 0) - (Number(a.lastReplyAt) || 0),
      );
      return rows;
    }
    rows.sort((a, b) => (Number(b.lastReplyAt) || 0) - (Number(a.lastReplyAt) || 0));
    return rows;
  }

  function filterThreads(threads) {
    const q = threadSearch.trim().toLowerCase();
    if (!q) return threads;
    return threads.filter((thread) => {
      const hay = `${thread.title || ""} ${thread.authorName || ""}`.toLowerCase();
      return hay.includes(q);
    });
  }

  function flattenThreadPosts(posts) {
    const op = posts.find((p) => p.isOp) || posts[0];
    if (!op) return [];

    const byParent = new Map();
    posts
      .filter((p) => !p.isOp)
      .forEach((post) => {
        const pid = String(post.parentPostId || op.id);
        if (!byParent.has(pid)) byParent.set(pid, []);
        byParent.get(pid).push(post);
      });

    for (const list of byParent.values()) {
      list.sort((a, b) => (Number(a.createdAt) || 0) - (Number(b.createdAt) || 0));
    }

    const out = [{ post: op, depth: 0 }];
    function walk(parentId, depth) {
      for (const child of byParent.get(String(parentId)) || []) {
        out.push({ post: child, depth });
        walk(child.id, depth + 1);
      }
    }
    walk(op.id, 0);
    return out;
  }

  function replyFormHtml({ postId, threadId, placeholder, compact }) {
    const id = escapeHtml(postId);
    const tid = escapeHtml(threadId);
    return `
      <form class="vortex07-forum-form vortex07-forum-inline-reply${compact ? " is-compact" : ""}" data-reply-form="${id}" data-thread-id="${tid}" data-parent-id="${id}">
        <label class="vortex07-forum-field">
          <span class="vortex07-forum-sr-only">Reply</span>
          <textarea name="body" maxlength="${BODY_MAX}" rows="${compact ? 3 : 4}" required class="vortex07-forum-input" placeholder="${escapeHtml(placeholder || "Write a reply…")}"></textarea>
        </label>
        <div class="vortex07-forum-form-actions">
          <button type="submit" class="vortex07-forum-submit">Post</button>
          <button type="button" class="vortex07-forum-cancel-reply" data-cancel-reply="${id}">Cancel</button>
        </div>
        <p class="vortex07-forum-hint" data-reply-hint="${id}"></p>
      </form>
    `;
  }

  function postActionsHtml(post, threadId, showInlineForm) {
    const pid = escapeHtml(post.id);
    const tid = escapeHtml(threadId);
    const likeCount = Number(post.likeCount) || 0;
    const myLike = Boolean(post.myLike);
    const parts = [];

    if (post.canLike) {
      const label = likeCount > 0 ? `▲ ${likeCount}` : "▲";
      parts.push(
        `<button type="button" class="vortex07-forum-like-btn${myLike ? " is-liked" : ""}" data-like-post="${pid}" data-thread-id="${tid}" aria-pressed="${myLike ? "true" : "false"}">${label}</button>`,
      );
    }

    parts.push(
      `<button type="button" class="vortex07-forum-reply-btn" data-reply-to="${pid}">Reply</button>`,
    );

    let html = `<div class="vortex07-forum-post-actions">${parts.join("")}</div>`;
    if (showInlineForm) {
      html += replyFormHtml({
        postId: post.id,
        threadId,
        placeholder: "Reply…",
        compact: true,
      });
    }
    return html;
  }

  function opPostHtml(api, post, threadId) {
    return `
      <article class="vortex07-forum-post is-op" data-post-id="${escapeHtml(post.id)}">
        <aside class="vortex07-forum-post-user">
          ${avatarHtml(api, post.authorUserId, post.authorName)}
          <div class="vortex07-forum-post-user-name">${authorLink(post.authorName, post.authorUserId)}</div>
        </aside>
        <div class="vortex07-forum-post-panel">
          <header class="vortex07-forum-post-head">
            <time title="${escapeHtml(formatWhen(post.createdAt))}">${formatRelativeWhen(post.createdAt)}</time>
          </header>
          <div class="vortex07-forum-post-body">${renderBody(post.body)}</div>
          ${postActionsHtml(post, threadId, replyTargetPostId === String(post.id))}
        </div>
      </article>
    `;
  }

  function replyPostHtml(api, post, depth, threadId) {
  const showForm = replyTargetPostId === String(post.id);
    return `
      <article class="vortex07-forum-post is-reply" data-post-id="${escapeHtml(post.id)}" data-depth="${depth}" style="--forum-depth:${depth}">
        <div class="vortex07-forum-reply-rail">
          ${avatarHtml(api, post.authorUserId, post.authorName, true)}
          <div class="vortex07-forum-reply-main">
            <header class="vortex07-forum-reply-head">
              ${authorLink(post.authorName, post.authorUserId)}
              <span class="vortex07-forum-reply-dot">·</span>
              <time title="${escapeHtml(formatWhen(post.createdAt))}">${formatRelativeWhen(post.createdAt)}</time>
            </header>
            <div class="vortex07-forum-post-body">${renderBody(post.body)}</div>
            ${postActionsHtml(post, threadId, showForm)}
          </div>
        </div>
      </article>
    `;
  }

  function renderToolbar(root) {
    const toolbar = root.querySelector("#vortex07-forumToolbar");
    if (!toolbar) return;

    if (activeThreadId || showNewThread) {
      toolbar.innerHTML = `<button type="button" class="vortex07-forum-back" id="vortex07-forumBack">← Threads</button>`;
      toolbar.querySelector("#vortex07-forumBack")?.addEventListener("click", () => {
        activeThreadId = null;
        showNewThread = false;
        replyTargetPostId = null;
        renderForum(root);
      });
      return;
    }

    toolbar.innerHTML = `
      <input type="search" class="vortex07-forum-search" id="vortex07-forumSearch" placeholder="Search" value="${escapeHtml(threadSearch)}" autocomplete="off" />
      <select class="vortex07-forum-sort" id="vortex07-forumSort" aria-label="Sort">
        <option value="active"${threadSort === "active" ? " selected" : ""}>Latest</option>
        <option value="newest"${threadSort === "newest" ? " selected" : ""}>New</option>
        <option value="replies"${threadSort === "replies" ? " selected" : ""}>Replies</option>
      </select>
      <button type="button" class="vortex07-forum-new-btn" id="vortex07-forumNewThread">New thread</button>
    `;

    toolbar.querySelector("#vortex07-forumSearch")?.addEventListener("input", (event) => {
      threadSearch = event.currentTarget.value || "";
      renderThreadList(root, filterThreads(sortThreads(cachedFeed.threads)));
    });

    toolbar.querySelector("#vortex07-forumSort")?.addEventListener("change", (event) => {
      threadSort = event.currentTarget.value || "active";
      renderThreadList(root, filterThreads(sortThreads(cachedFeed.threads)));
    });

    toolbar.querySelector("#vortex07-forumNewThread")?.addEventListener("click", () => {
      showNewThread = true;
      renderForum(root);
    });
  }

  function renderThreadList(root, threads, api) {
    const body = root.querySelector("#vortex07-forumBody");
    const status = root.querySelector("#vortex07-forumStatus");
    if (!body) return;

    if (!threads.length) {
      body.innerHTML = `<div class="vortex07-forum-empty"><p>${threadSearch.trim() ? "No matches." : "No threads yet."}</p></div>`;
      if (status) status.textContent = "General";
      return;
    }

    const rows = threads
      .map(
        (thread) => `
          <div class="vortex07-forum-thread-row" role="button" tabindex="0" data-thread-id="${escapeHtml(thread.id)}">
            <div class="vortex07-forum-col vortex07-forum-col-avatar">${avatarHtml(api, thread.authorUserId, thread.authorName)}</div>
            <div class="vortex07-forum-col vortex07-forum-col-topic">
              <div class="vortex07-forum-thread-title">${escapeHtml(thread.title)}</div>
            </div>
            <div class="vortex07-forum-col vortex07-forum-col-author">${authorLink(thread.authorName, thread.authorUserId)}</div>
            <div class="vortex07-forum-col vortex07-forum-col-replies">${Number(thread.replyCount) || 0}</div>
            <div class="vortex07-forum-col vortex07-forum-col-time" title="${escapeHtml(formatWhen(thread.lastReplyAt || thread.createdAt))}">${formatRelativeWhen(thread.lastReplyAt || thread.createdAt)}</div>
          </div>
        `,
      )
      .join("");

    body.innerHTML = `
      <div class="vortex07-forum-table">
        <div class="vortex07-forum-table-head">
          <span class="vortex07-forum-col vortex07-forum-col-avatar"></span>
          <span class="vortex07-forum-col vortex07-forum-col-topic">Topic</span>
          <span class="vortex07-forum-col vortex07-forum-col-author">Author</span>
          <span class="vortex07-forum-col vortex07-forum-col-replies">Replies</span>
          <span class="vortex07-forum-col vortex07-forum-col-time">Last</span>
        </div>
        <div class="vortex07-forum-thread-list">${rows}</div>
      </div>
    `;

    if (status) status.textContent = `${threads.length} thread${threads.length === 1 ? "" : "s"}`;

    body.querySelectorAll("[data-thread-id]").forEach((row) => {
      const open = () => {
        activeThreadId = row.dataset.threadId || null;
        replyTargetPostId = null;
        renderForum(root);
      };
      row.addEventListener("click", (event) => {
        if (event.target.closest("a")) return;
        open();
      });
      row.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          open();
        }
      });
    });
  }

  function renderNewThreadForm(root, api) {
    const body = root.querySelector("#vortex07-forumBody");
    const status = root.querySelector("#vortex07-forumStatus");
    if (!body) return;

    body.innerHTML = `
      <form class="vortex07-forum-form" id="vortex07-forumNewForm">
        <label class="vortex07-forum-field">
          <span>Title</span>
          <input type="text" name="title" maxlength="${TITLE_MAX}" required class="vortex07-forum-input" />
        </label>
        <label class="vortex07-forum-field">
          <span>Message <span class="vortex07-forum-limit-hint">(max ${BODY_MAX})</span></span>
          <textarea name="body" maxlength="${BODY_MAX}" rows="6" required class="vortex07-forum-input"></textarea>
        </label>
        <div class="vortex07-forum-form-actions">
          <button type="submit" class="vortex07-forum-submit">Post</button>
        </div>
        <p class="vortex07-forum-hint" id="vortex07-forumFormHint"></p>
      </form>
    `;

    bindCharCounter(body, "#vortex07-forumNewForm textarea", BODY_MAX);

    body.querySelector("#vortex07-forumNewForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const hint = body.querySelector("#vortex07-forumFormHint");
      const submit = form.querySelector(".vortex07-forum-submit");

      submit.disabled = true;
      if (status) status.textContent = "Posting…";

      const result = await api.createThread({
        categoryId: FORUM_CATEGORY,
        title: form.title?.value || "",
        body: form.body?.value || "",
      });

      submit.disabled = false;

      if (!result.ok) {
        const msg = forumErrorMessage(result, "Could not post.");
        if (hint) hint.textContent = msg;
        if (status) status.textContent = msg;
        return;
      }

      showNewThread = false;
      activeThreadId = result.thread?.id || null;
      replyTargetPostId = null;
      if (result.threadView) {
        root.__vortex07ForumThreadCache = result.threadView;
        if (result.profiles) setFeedContext({ ...cachedFeed, ...result.profiles });
      }
      renderForum(root);
    });
  }

  function bindThreadInteractions(root, data, api) {
    const body = root.querySelector("#vortex07-forumBody");
    const { thread } = data;
    if (!body || !thread) return;

    bindCharCounter(body, "textarea", BODY_MAX);

    body.querySelectorAll("[data-reply-to]").forEach((btn) => {
      btn.addEventListener("click", () => {
        replyTargetPostId = btn.dataset.replyTo || null;
        renderThreadView(root, data, api);
        const target = body.querySelector(`[data-post-id="${replyTargetPostId}"] textarea`);
        target?.focus();
      });
    });

    body.querySelectorAll("[data-cancel-reply]").forEach((btn) => {
      btn.addEventListener("click", () => {
        replyTargetPostId = null;
        renderThreadView(root, data, api);
      });
    });

    body.querySelectorAll("[data-like-post]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        if (typeof api.likePost !== "function") return;
        btn.disabled = true;
        const result = await api.likePost({
          threadId: btn.dataset.threadId || thread.id,
          postId: btn.dataset.likePost,
        });
        btn.disabled = false;
        if (!result.ok) return;
        renderForum(root);
      });
    });

    body.querySelectorAll("[data-reply-form]").forEach((form) => {
      form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const hint = form.querySelector("[data-reply-hint]") || form.querySelector(".vortex07-forum-hint");
        const submit = form.querySelector(".vortex07-forum-submit");
        submit.disabled = true;

        const result = await api.replyToThread({
          threadId: form.dataset.threadId || thread.id,
          parentPostId: form.dataset.parentId || null,
          body: form.body?.value || "",
        });

        submit.disabled = false;

        if (!result.ok) {
          if (hint) hint.textContent = forumErrorMessage(result, "Could not reply.");
          return;
        }

        replyTargetPostId = null;
        delete root.__vortex07ForumThreadCache;
        renderForum(root);
      });
    });

    body.querySelector("#vortex07-forumReplyForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      const hint = body.querySelector("#vortex07-forumReplyHint");
      const submit = form.querySelector(".vortex07-forum-submit");
      const opId = form.dataset.parentId || "";

      submit.disabled = true;
      const result = await api.replyToThread({
        threadId: thread.id,
        parentPostId: opId || null,
        body: form.body?.value || "",
      });
      submit.disabled = false;

      if (!result.ok) {
        if (hint) hint.textContent = forumErrorMessage(result, "Could not reply.");
        return;
      }

      form.reset();
      bindCharCounter(body, "#vortex07-forumReplyForm textarea", BODY_MAX);
      delete root.__vortex07ForumThreadCache;
      renderForum(root);
    });
  }

  function renderThreadView(root, data, api) {
    const body = root.querySelector("#vortex07-forumBody");
    const status = root.querySelector("#vortex07-forumStatus");
    if (!body || !data?.thread) return;

    const { thread, posts = [] } = data;
    const flat = flattenThreadPosts(posts);
    const op = flat[0]?.post;
    const opId = op ? String(op.id) : "";

    const postBlocks = flat
      .map(({ post, depth }) => {
        if (post.isOp || depth === 0) return opPostHtml(api, post, thread.id);
        return replyPostHtml(api, post, depth, thread.id);
      })
      .join("");

    body.innerHTML = `
      <div class="vortex07-forum-thread-view">
        <h2 class="vortex07-forum-thread-heading">${escapeHtml(thread.title)}</h2>
        <div class="vortex07-forum-posts">${postBlocks}</div>
        <form class="vortex07-forum-form vortex07-forum-reply-form" id="vortex07-forumReplyForm" data-parent-id="${escapeHtml(opId)}">
          <label class="vortex07-forum-field">
            <span>Reply to thread <span class="vortex07-forum-limit-hint">(max ${BODY_MAX})</span></span>
            <textarea name="body" maxlength="${BODY_MAX}" rows="4" required class="vortex07-forum-input" placeholder="Join the discussion…"></textarea>
          </label>
          <div class="vortex07-forum-form-actions">
            <button type="submit" class="vortex07-forum-submit">Post reply</button>
          </div>
          <p class="vortex07-forum-hint" id="vortex07-forumReplyHint"></p>
        </form>
      </div>
    `;

    if (status) status.textContent = thread.title;
    bindThreadInteractions(root, data, api);
  }

  async function renderForum(root) {
    const api = root.__vortex07ForumApi;
    const body = root.querySelector("#vortex07-forumBody");
    if (!api || !body) return;

    renderToolbar(root);

    if (showNewThread) {
      renderNewThreadForm(root, api);
      return;
    }

    if (activeThreadId) {
      const cached = root.__vortex07ForumThreadCache;
      if (cached?.thread?.id === activeThreadId) {
        delete root.__vortex07ForumThreadCache;
        if (cached.authors) {
          setFeedContext({
            ...cachedFeed,
            authors: { ...cachedFeed.authors, ...cached.authors },
            avatars: { ...cachedFeed.avatars, ...(cached.avatars || {}) },
          });
        }
        renderThreadView(root, cached, api);
        return;
      }

      body.innerHTML = '<p class="vortex07-forum-loading">Loading…</p>';
      const data = await api.fetchThread(activeThreadId);
      if (!data?.thread) {
        body.innerHTML = '<p class="vortex07-forum-empty">Thread not found.</p>';
        return;
      }
      setFeedContext({
        threads: cachedFeed.threads,
        authors: data.authors || {},
        avatars: data.avatars || {},
      });
      renderThreadView(root, data, api);
      return;
    }

    body.innerHTML = '<p class="vortex07-forum-loading">Loading…</p>';
    const payload =
      typeof api.fetchFeed === "function"
        ? await api.fetchFeed(FORUM_CATEGORY)
        : { threads: await api.fetchThreads(FORUM_CATEGORY), authors: {}, avatars: {} };

    setFeedContext(payload);
    renderThreadList(root, filterThreads(sortThreads(payload.threads || [])), api);
  }

  function mountForumPage(root, version, api) {
    if (!root) return;
    root.__vortex07ForumApi = api;
    root.innerHTML = buildShellHtml(version);
    activeThreadId = null;
    showNewThread = false;
    replyTargetPostId = null;
    threadSearch = "";
    threadSort = "active";
    cachedFeed = { threads: [], authors: {}, avatars: {} };
    renderForum(root);
  }

  global.Vortex07ForumUi = {
    mountForumPage,
    renderForum,
  };
})(typeof globalThis !== "undefined" ? globalThis : window);
