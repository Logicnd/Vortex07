// Vortex07 home-ui.js — Home page: activity ticker, leaderboard strip, global rep badges, avatar frames.
// Extracted from content.js. Depends on content.js globals.


  const list = section.querySelector(".vortex07-guestbook-list");
  const form = section.querySelector(".vortex07-guestbook-form");
  const hint = section.querySelector(".vortex07-guestbook-hint");
  const loggedInId = getLoggedInUserIdFromNav();
  const canSign = loggedInId !== null && loggedInId !== profileId;

  if (form) form.hidden = !canSign;
  if (hint) hint.hidden = true;

  if (list) {
    list.innerHTML = '<li class="vortex07-guestbook-loading">Loading…</li>';
    const entries = await fetchGuestbookEntries(profileId, 20);
    renderGuestbookEntries(list, entries);
  }
}

async function pushLocalActivityEvent(userId, delta = 1) {
  const id = safeNumber(userId);
  if (id === null) return;

  const event = { type: "rep", userId: id, delta: Number(delta) || 1, at: Date.now() };
  const data = await storageGet("local", { [ACTIVITY_CACHE_KEY]: [] });
  const existing = Array.isArray(data[ACTIVITY_CACHE_KEY]) ? data[ACTIVITY_CACHE_KEY] : [];
  const next = [event, ...existing].slice(0, 40);
  await storageSet("local", { [ACTIVITY_CACHE_KEY]: next });
}

async function fetchActivityFeed(limit = 12) {
  const cap = Math.min(Math.max(Number(limit) || 12, 1), 30);
  const data = await storageGet("local", { [ACTIVITY_CACHE_KEY]: [] });
  const localEvents = Array.isArray(data[ACTIVITY_CACHE_KEY]) ? data[ACTIVITY_CACHE_KEY] : [];

  const apiBase = getVortex07ApiBase();
  if (!apiBase || !isRepApiAvailable() || shouldSkipNonEssentialPolling()) {
    return localEvents.slice(0, cap);
  }

  try {
    const voterId = await ensureVoterId();
    const url = `${apiBase}/activity?limit=${encodeURIComponent(cap)}&voterId=${encodeURIComponent(voterId)}`;
    const response = await fetchReputationRequest(url, {
      headers: { Accept: "application/json" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const json = await response.json();
    const remote = Array.isArray(json.events) ? json.events : [];
    const merged = [...remote, ...localEvents]
      .sort((a, b) => (Number(b.at) || 0) - (Number(a.at) || 0))
      .filter((event, index, arr) => {
        const key = `${event.type}:${event.userId}:${event.at}`;
        return arr.findIndex((row) => `${row.type}:${row.userId}:${row.at}` === key) === index;
      })
      .slice(0, cap);
    return merged;
  } catch (err) {
    logRepFailureOnce("Activity feed fetch failed:", err);
    return localEvents.slice(0, cap);
  }
}

async function formatActivityEvent(event, nameMap) {
  const userId = safeNumber(event?.userId);
  if (userId === null) return null;

  const label = nameMap.get(userId) || `@user${userId}`;
  const delta = Number(event.delta) || 1;
  if (event.type === "rep") {
    return `${label} got +${delta} rep`;
  }
  return null;
}

let homeActivityInjected = false;

async function injectHomeActivityTicker() {
  if (!currentSettings.enabled || !currentSettings.showActivityTicker) return;

  const path = window.location.pathname;
  if (path !== "/home" && path !== "/") return;

  if (document.querySelector(".vortex07-activity-ticker")) {
    homeActivityInjected = true;
    return;
  }
  if (homeActivityInjected) return;

  const gamesSection = document.querySelector("#Container .games-section");
  if (!gamesSection) return;

  homeActivityInjected = true;

  const ticker = document.createElement("div");
  ticker.className = "vortex07-activity-ticker";
  ticker.innerHTML =
    '<div class="vortex07-activity-head"><span class="vortex07-activity-title">Vortex07 Activity</span><span class="vortex07-activity-sub">Recent rep</span></div><ul class="vortex07-activity-list"><li class="vortex07-activity-loading">Loading…</li></ul>';
  gamesSection.insertAdjacentElement("afterend", ticker);

  const list = ticker.querySelector(".vortex07-activity-list");
  const events = await fetchActivityFeed(12);
  list.textContent = "";

  if (!events.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-activity-empty";
    empty.textContent = "No recent rep yet — give someone +1 on a profile.";
    list.appendChild(empty);
    return;
  }

  const userIds = events
    .map((event) => safeNumber(event.userId))
    .filter((id) => id !== null);
  const names = await resolveLeaderboardDisplayNames(userIds);

  for (const event of events) {
    const text = await formatActivityEvent(event, names);
    if (!text) continue;

    const li = document.createElement("li");
    li.className = "vortex07-activity-item";
    const userId = safeNumber(event.userId);
    if (userId !== null) {
      const link = document.createElement("a");
      link.href = `/users/${userId}/profile`;
      link.className = "vortex07-activity-link";
      link.textContent = text;
      li.appendChild(link);
    } else {
      li.textContent = text;
    }
    list.appendChild(li);
  }

  if (!list.children.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-activity-empty";
    empty.textContent = "No recent rep yet — give someone +1 on a profile.";
    list.appendChild(empty);
  }
}

async function syncPendingReputationVotes() {
  const apiBase = getReputationApiBase();
  if (!apiBase || shouldSkipNonEssentialPolling()) return;

  const actorId = getActorUserId();
  if (actorId === null) return;

  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  if (pending.length === 0) return;

  const remaining = [];

  for (const userId of pending) {
    try {
      const response = await fetchReputationRequest(`${apiBase}/reputation`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId, actorUserId: actorId }),
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      await cacheReputation(userId, json.count, true);
      invalidateRepApiCache(userId);
    } catch {
      remaining.push(userId);
    }
  }

  await storageSet("local", { [REPUTATION_PENDING_KEY]: remaining });
}

async function unqueuePendingReputationVote(userId) {
  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  const next = pending.filter((id) => Number(id) !== Number(userId));
  if (next.length === pending.length) return;
  await storageSet("local", { [REPUTATION_PENDING_KEY]: next });
}

async function queuePendingReputationVote(userId) {
  const data = await storageGet("local", { [REPUTATION_PENDING_KEY]: [] });
  const pending = Array.isArray(data[REPUTATION_PENDING_KEY])
    ? data[REPUTATION_PENDING_KEY]
    : [];
  if (!pending.includes(Number(userId))) pending.push(Number(userId));
  await storageSet("local", { [REPUTATION_PENDING_KEY]: pending });
}

function getUserIdFromRepNode(node) {
  if (!node) return null;
  if (node.dataset?.vortex07UserId) return safeNumber(node.dataset.vortex07UserId);
  const href =
    node.getAttribute("href") ||
    node.querySelector("a[href*='/users/']")?.getAttribute("href") ||
    "";
  return extractUserIdFromHref(href);
}

function resolveGlobalRepHost(parentEl) {
  if (!parentEl) return null;

  if (parentEl.classList.contains("friend-card")) {
    let meta = parentEl.querySelector(".vortex07-friend-meta");
    if (!meta) {
      meta = document.createElement("span");
      meta.className = "vortex07-friend-meta";
      const nameEl = parentEl.querySelector(".friend-name");
      if (nameEl) nameEl.insertAdjacentElement("afterend", meta);
      else parentEl.appendChild(meta);
    }
    return meta;
  }

  if (parentEl.classList.contains("user-card")) {
    let meta = parentEl.querySelector(".vortex07-user-card-meta");
    if (!meta) {
      meta = document.createElement("span");
      meta.className = "vortex07-user-card-meta";
      const nameEl = parentEl.querySelector(".user-card-name");
      if (nameEl) nameEl.insertAdjacentElement("afterend", meta);
      else parentEl.appendChild(meta);
    }
    return meta;
  }

  if (parentEl.classList.contains("vortex07-player-result")) {
    let repRow = parentEl.querySelector(".vortex07-user-rep-row");
    if (!repRow) {
      repRow = document.createElement("span");
      repRow.className = "vortex07-user-rep-row";
      const info = parentEl.querySelector(".vortex07-user-info");
      if (info) info.appendChild(repRow);
      else parentEl.appendChild(repRow);
    }
    return repRow;
  }

  return parentEl;
}

function decorateGlobalRepBadge(parentEl, userId, count) {
  if (!currentSettings.enabled || !parentEl) return;
  const numeric = safeNumber(userId);
  if (numeric === null) return;

  const numericCount = Number(count) || 0;
  const isCompactTile =
    parentEl.classList.contains("friend-card") ||
    parentEl.classList.contains("user-card");

  const host = resolveGlobalRepHost(parentEl) || parentEl;

  if (isCompactTile && numericCount <= 0) {
    host.querySelector(".vortex07-global-rep")?.remove();
    return;
  }

  let badge = host.querySelector(".vortex07-global-rep");
  if (!badge) {
    badge = document.createElement("span");
    badge.className = "vortex07-global-rep";
    if (isCompactTile) badge.classList.add("vortex07-global-rep-compact");
    badge.title = "Global Vortex07 reputation";
    badge.innerHTML = `<span class="vortex07-global-rep-icon" aria-hidden="true">${repThumbUpSvg(isCompactTile ? 8 : 10)}</span><span class="vortex07-global-rep-num"></span>${isCompactTile ? "" : '<span class="vortex07-global-rep-label">rep</span>'}`;
    host.appendChild(badge);
  }

  const numEl = badge.querySelector(".vortex07-global-rep-num");
  if (numEl) numEl.textContent = String(numericCount);

  if (numericCount > 0) {
    host.querySelector(".vortex07-rep-milestone")?.remove();
    const milestone = createRepMilestoneEl(numericCount);
    if (milestone) host.appendChild(milestone);
  } else {
    host.querySelector(".vortex07-rep-milestone")?.remove();
  }
}

async function applyGlobalRepBadges(root = document) {
  if (!currentSettings.enabled) return;

  const nodes = root.querySelectorAll(
    ".friend-card, .user-card, .vortex07-player-result, .user-row",
  );
  if (nodes.length === 0) return;

  const ids = [];
  nodes.forEach((node) => {
    const id = getUserIdFromRepNode(node);
    if (id !== null) ids.push(id);
  });

  const repMap = isExtensionContextAlive()
    ? await fetchReputationCountsBulk(ids)
    : await buildRepMapFromCache(ids);
  nodes.forEach((node) => {
    const id = getUserIdFromRepNode(node);
    if (id === null) return;
    const rep = repMap.get(id);
    const cached = rep || null;
    decorateGlobalRepBadge(
      node,
      id,
      cached ? cached.count : 0,
    );
  });

  scheduleExtensionMetaDecorations(root);
}

let globalRepScheduled = false;

function scheduleGlobalRepBadges(root = document) {
  if (globalRepScheduled || !currentSettings.enabled) {
    return;
  }
  globalRepScheduled = true;

  requestAnimationFrame(async () => {
    globalRepScheduled = false;
    await applyGlobalRepBadges(root);
  });
}

let homeLeaderboardInjected = false;

async function injectHomeLeaderboardStrip() {
  if (!currentSettings.enabled) return;

  const path = window.location.pathname;
  if (path !== "/home" && path !== "/") return;

  if (document.querySelector(".vortex07-home-leaderboard")) {
    homeLeaderboardInjected = true;
    return;
  }

  if (homeLeaderboardInjected) return;

  const gamesSection = document.querySelector("#Container .games-section");
  if (!gamesSection) return;

  homeLeaderboardInjected = true;

  const strip = document.createElement("div");
  strip.className = "vortex07-home-leaderboard";
  strip.innerHTML =
    '<div class="vortex07-home-leaderboard-head"><span class="vortex07-home-leaderboard-title">Vortex07 Rep Leaderboard</span><span class="vortex07-home-leaderboard-sub">Extension users only</span></div><ol class="vortex07-home-leaderboard-list"><li class="vortex07-home-leaderboard-loading">Loading…</li></ol><div class="vortex07-home-leaderboard-foot" hidden><span class="vortex07-home-leaderboard-foot-text">Give rep on profiles to climb the board</span></div>';

  const activityTicker = document.querySelector(".vortex07-activity-ticker");
  if (activityTicker) {
    activityTicker.insertAdjacentElement("afterend", strip);
  } else {
    gamesSection.insertAdjacentElement("afterend", strip);
  }

  const list = strip.querySelector(".vortex07-home-leaderboard-list");
  const rows = await fetchLeaderboard(10);
  list.textContent = "";

  if (!rows.length) {
    const empty = document.createElement("li");
    empty.className = "vortex07-home-leaderboard-empty";
    empty.textContent = "No rep yet — be the first to give rep on a profile.";
    list.appendChild(empty);
    return;
  }

  const userIds = rows
    .map((row) => safeNumber(row.userId))
    .filter((id) => id !== null);
  const avatars = await fetchPlayerAvatars(userIds);
  const displayNames = await resolveLeaderboardDisplayNames(userIds);
  const rankClasses = [
    "vortex07-home-leaderboard-row--gold",
    "vortex07-home-leaderboard-row--silver",
    "vortex07-home-leaderboard-row--bronze",
  ];

  rows.forEach((row, index) => {
    const userId = safeNumber(row.userId);
    if (userId === null) return;

    const li = document.createElement("li");
    li.className = "vortex07-home-leaderboard-row";
    if (rankClasses[index]) li.classList.add(rankClasses[index]);

    const rank = document.createElement("span");
    rank.className = "vortex07-home-leaderboard-rank";
    rank.textContent = String(index + 1);

    const avatar = document.createElement("img");
    avatar.className = "vortex07-home-leaderboard-avatar";
    avatar.alt = "";
    avatar.loading = "lazy";
    avatar.src =
      avatars.get(userId) ||
      `${VORTEX_ORIGIN}/images/placeholder-avatar.png`;

    const nameWrap = document.createElement("span");
    nameWrap.className = "vortex07-home-leaderboard-name-wrap";

    const name = document.createElement("a");
    name.className = "vortex07-home-leaderboard-name";
    name.href = `/users/${userId}/profile`;
    name.textContent =
      displayNames.get(userId) || `@user${userId}`;
    nameWrap.appendChild(name);
    appendUsernameBadges(nameWrap, userId);

    const count = document.createElement("span");
    count.className = "vortex07-home-leaderboard-count";
    count.innerHTML = `<span class="vortex07-global-rep-icon" aria-hidden="true">${repThumbUpSvg(10)}</span><span class="vortex07-global-rep-num">${Number(row.count) || 0}</span>`;

    li.append(rank, avatar, nameWrap, count);
    list.appendChild(li);
  });

  const foot = strip.querySelector(".vortex07-home-leaderboard-foot");
  if (foot) foot.hidden = false;

  enhanceRetroBadges(strip);
}

async function hydrateProfileAvatar(header, profileId) {
  if (!header || profileId === null) return;

  const avatar = header.querySelector(".profile-avatar");
  if (!avatar || avatar.dataset.vortex07AvatarHydrated === "1") return;

  const currentSrc = extractAvatarUrl(avatar.getAttribute("src") || "");
  const needsFetch = !currentSrc;

  const applyAvatarUrl = (url) => {
    if (!url) return false;
    avatar.src = url;
    avatar.alt = "";
    avatar.decoding = "async";
    avatar.referrerPolicy = "no-referrer";
    avatar.dataset.vortex07AvatarHydrated = "1";
    return true;
  };

  if (!needsFetch) {
    avatar.decoding = "async";
    avatar.referrerPolicy = "no-referrer";
    avatar.addEventListener(
      "error",
      () => {
        void fetchPlayerAvatars([profileId], { userInitiated: true }).then((map) => {
          const url = map.get(profileId);
          if (url) applyAvatarUrl(url);
        });
      },
      { once: true },
    );
    return;
  }

  const map = await fetchPlayerAvatars([profileId], { userInitiated: true });
  applyAvatarUrl(map.get(profileId));
}

function normalizeProfileLayout() {
  const header = document.querySelector(".profile-header");
  if (!header) return;

  header.classList.add("vortex07-profile-header");

  const avatarWrap = header.querySelector(".profile-avatar-wrap");
  if (avatarWrap) avatarWrap.classList.add("vortex07-profile-avatar-slot");

  const avatar = header.querySelector(".profile-avatar");
  const profileId = getProfileUserIdFromPage();
  if (avatarWrap && profileId !== null) {
    applyAvatarFrameClasses(avatarWrap, profileId);
  }

  if (avatar) {
    const framed =
      avatarWrap?.classList.contains("vortex07-rainbow-avatar-frame") ||
      avatarWrap?.classList.contains("vortex07-dev-avatar-frame");

    if (framed) {
      avatar.style.width = "100%";
      avatar.style.height = "100%";
      avatar.style.maxWidth = "none";
      avatar.style.maxHeight = "none";
      avatar.style.objectFit = "cover";
    } else {
      avatar.style.width = "100px";
      avatar.style.height = "100px";
      avatar.style.maxWidth = "100px";
      avatar.style.maxHeight = "100px";
      avatar.style.objectFit = "contain";
    }
  }

  if (profileId !== null) {
    void hydrateProfileAvatar(header, profileId);
  }

  ensureProfileMetaStack(header);
}

function applyAvatarFramesToPage(root = document) {
  const profileId = getProfileUserIdFromPage();
  if (profileId !== null) {
    const profileWrap = root.querySelector(".profile-avatar-wrap");
    if (profileWrap) applyAvatarFrameClasses(profileWrap, profileId);
  }

  root
    .querySelectorAll(".friend-card, .user-card, .user-row")
    .forEach((card) => {
      const userId = getUserIdFromRepNode(card);
      if (userId === null) return;

      const wrap =
        card.querySelector(
          ".friend-avatar-wrap, .user-row-avatar-wrap, [class*='avatar-wrap']",
        ) || card.querySelector(".friend-avatar, .user-row-avatar")?.parentElement;

      if (wrap) applyAvatarFrameClasses(wrap, userId);
    });
}

function normalizeOnlineIndicators() {
  document
    .querySelectorAll(
      ".friend-card, .profile-header, .user-row, .user-card",
    )
    .forEach((card) => {
      const indicators = card.querySelectorAll(
        ".status-dot, [class*='online-status'], [class*='status-indicator'], [data-online], [data-status]",
      );

      indicators.forEach((el) => {
        if (el.closest(".vortex07-reputation-panel")) return;
        if (el.matches("a, button, input, select, textarea")) return;

        el.classList.add("vortex07-status-pill");

        const text = safeLower(
          el.textContent ||
            el.getAttribute("data-status") ||
            el.getAttribute("data-online") ||
            el.className,
        );

        const isOnline =
          text.includes("online") ||
          text.includes("in-game") ||
          text.includes("ingame") ||
          el.classList.contains("online") ||
          el.getAttribute("data-online") === "true" ||
          el.getAttribute("data-status") === "online";

        const isOffline =
          text.includes("offline") ||
          el.classList.contains("offline") ||
          el.getAttribute("data-status") === "offline";

        el.classList.toggle("vortex07-status-online", isOnline);
        el.classList.toggle("vortex07-status-offline", isOffline && !isOnline);
      });
    });
}

