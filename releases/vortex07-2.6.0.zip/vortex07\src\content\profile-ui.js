// Vortex07 profile-ui.js — Profile tier features, mutual-friends indicator, roulette button.
// Shares scope with content.js.

/* ========================================================= */
/* = TIER A SOCIAL (v1.11.0) ============================== */
/* ========================================================= */

function getRepMilestoneTier(count) {
  const numeric = Number(count) || 0;
  return REP_MILESTONE_TIERS.find((tier) => numeric >= tier.min) || null;
}

function createRepMilestoneEl(count) {
  const tier = getRepMilestoneTier(count);
  if (!tier) return null;

  const el = document.createElement("span");
  el.className = `vortex07-rep-milestone vortex07-rep-milestone--${tier.tier}`;
  el.textContent = tier.label;
  el.title = `${tier.label} on Vortex07`;
  return el;
}

function syncRepMilestoneOnPanel(panel, count) {
  const head = panel?.querySelector(".vortex07-reputation-head");
  if (!head) return;

  head.querySelector(".vortex07-rep-milestone")?.remove();
  const milestone = createRepMilestoneEl(count);
  if (milestone) head.appendChild(milestone);
}

function normalizeComparePlayer(player) {
  const id = safeNumber(player?.id ?? player?.userId);
  if (id === null) return null;

  return {
    id,
    username: safeString(player?.username) || `user${id}`,
    displayName:
      safeString(player?.displayName) ||
      safeString(player?.username) ||
      `User ${id}`,
    avatarUrl: extractAvatarUrl(player?.avatarUrl),
    onlineStatus: safeString(player?.onlineStatus),
    roles: player?.roles || resolvePlayerRoles(id),
  };
}

function clearCompareAnchor() {
  compareAnchor = null;
  document.documentElement.classList.remove("vortex07-compare-mode");
  updateCompareModeUi();
}

function setCompareAnchor(player) {
  const normalized = normalizeComparePlayer(player);
  if (!normalized) return;

  compareAnchor = normalized;
  document.documentElement.classList.add("vortex07-compare-mode");
  updateCompareModeUi();
  showVortexToast(`Compare: pick another player`);
}

function updateCompareModeUi() {
  const input = findSearchInput();
  if (!input) return;

  if (compareAnchor) {
    input.placeholder = "Pick player to compare…";
    input.classList.add("vortex07-compare-picking");
    input.setAttribute("aria-label", "Pick player to compare");
  } else {
    input.classList.remove("vortex07-compare-picking");
    updateSearchPlaceholder();
  }
}

function triggerComparePlayer(player) {
  const target = normalizeComparePlayer(player);
  if (!target) return;

  if (!compareAnchor) {
    setCompareAnchor(target);
    return;
  }

  if (compareAnchor.id === target.id) {
    showVortexToast("Pick a different player");
    return;
  }

  void openCompareModal(compareAnchor, target);
  clearCompareAnchor();
}

function closeCompareModal() {
  document.getElementById("vortex07-compare-overlay")?.remove();
  document.removeEventListener("keydown", handleCompareModalKeydown);
}

function handleCompareModalKeydown(event) {
  if (event.key === "Escape") closeCompareModal();
}

function formatOnlineStatusLabel(status) {
  if (status === "in-game") return "In Game";
  if (status === "online") return "Online";
  if (status === "offline") return "Offline";
  return status ? String(status) : "Unknown";
}

async function buildCompareColumn(player, batchRow, statusText, avatarUrl) {
  const col = document.createElement("div");
  col.className = "vortex07-compare-col";

  const avatarWrap = makeUserAvatarEl(
    player.id,
    player.username,
    avatarUrl || player.avatarUrl,
    { onlineStatus: player.onlineStatus },
  );
  avatarWrap.classList.add("vortex07-compare-avatar");
  col.appendChild(avatarWrap);

  const nameRow = document.createElement("div");
  nameRow.className = "vortex07-compare-name-row";
  const name = document.createElement("span");
  name.className = "vortex07-compare-name";
  name.textContent = player.displayName || player.username;
  nameRow.appendChild(name);
  appendUsernameBadges(nameRow, player.id, player.roles);
  col.appendChild(nameRow);

  const handle = document.createElement("div");
  handle.className = "vortex07-compare-handle";
  handle.textContent = `@${player.username}`;
  col.appendChild(handle);

  const online = document.createElement("div");
  online.className = "vortex07-compare-online";
  online.textContent = formatOnlineStatusLabel(player.onlineStatus);
  col.appendChild(online);

  const repCount = Number(batchRow?.count) || 0;
  const repLine = document.createElement("div");
  repLine.className = "vortex07-compare-rep";
  repLine.innerHTML = `<span class="vortex07-global-rep-icon" aria-hidden="true">${repThumbUpSvg(12)}</span><span class="vortex07-compare-rep-num">${repCount}</span> rep`;
  const milestone = createRepMilestoneEl(repCount);
  if (milestone) repLine.appendChild(milestone);
  col.appendChild(repLine);

  const statusLine = normalizeExtensionStatus(statusText);
  if (statusLine && currentSettings.showExtensionStatus) {
    const ext = renderExtensionStatusEl(statusLine, {
      className: "vortex07-ext-status vortex07-compare-ext-status",
      userId: player.id,
    });
    if (ext) col.appendChild(ext);
  }

  const profileLink = document.createElement("a");
  profileLink.className = "vortex07-compare-profile-link";
  profileLink.href = `/users/${player.id}/profile`;
  profileLink.textContent = "View profile →";
  col.appendChild(profileLink);

  return col;
}

async function openCompareModal(left, right) {
  closeCompareModal();

  const overlay = document.createElement("div");
  overlay.id = "vortex07-compare-overlay";
  overlay.className = "vortex07-compare-overlay";

  const modal = document.createElement("div");
  modal.className = "vortex07-compare-modal";
  modal.setAttribute("role", "dialog");
  modal.setAttribute("aria-modal", "true");
  modal.setAttribute("aria-label", "Compare players");

  modal.innerHTML =
    '<div class="vortex07-compare-head"><span class="vortex07-compare-title">Compare Players</span><button type="button" class="vortex07-compare-close rbx-2007-btn" aria-label="Close">×</button></div><div class="vortex07-compare-body"><div class="vortex07-compare-loading">Loading…</div></div>';

  overlay.appendChild(modal);
  (document.body || document.documentElement).appendChild(overlay);

  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closeCompareModal();
  });
  modal.querySelector(".vortex07-compare-close")?.addEventListener("click", closeCompareModal);
  document.addEventListener("keydown", handleCompareModalKeydown);

  const body = modal.querySelector(".vortex07-compare-body");
  const leftPlayer = normalizeComparePlayer(left);
  const rightPlayer = normalizeComparePlayer(right);
  if (!leftPlayer || !rightPlayer || !body) return;

  try {
    const [batchMap, statusMap, avatars] = await Promise.all([
      fetchBatchPlayerData([leftPlayer.id, rightPlayer.id]),
      fetchBatchStatuses([leftPlayer.id, rightPlayer.id]),
      fetchPlayerAvatars([leftPlayer.id, rightPlayer.id], { userInitiated: true }),
    ]);

    clearElement(body);
    const grid = document.createElement("div");
    grid.className = "vortex07-compare-grid";

    const leftCol = await buildCompareColumn(
      leftPlayer,
      batchMap.get(leftPlayer.id),
      statusMap.get(leftPlayer.id) || "",
      avatars.get(leftPlayer.id),
    );
    const vs = document.createElement("div");
    vs.className = "vortex07-compare-vs";
    vs.textContent = "VS";
    const rightCol = await buildCompareColumn(
      rightPlayer,
      batchMap.get(rightPlayer.id),
      statusMap.get(rightPlayer.id) || "",
      avatars.get(rightPlayer.id),
    );

    grid.append(leftCol, vs, rightCol);

    const leftRep = Number(batchMap.get(leftPlayer.id)?.count) || 0;
    const rightRep = Number(batchMap.get(rightPlayer.id)?.count) || 0;
    if (leftRep > rightRep) {
      leftCol.classList.add("vortex07-compare-col--lead");
      const diff = document.createElement("div");
      diff.className = "vortex07-compare-diff";
      diff.textContent = `+${leftRep - rightRep} rep`;
      vs.appendChild(diff);
    } else if (rightRep > leftRep) {
      rightCol.classList.add("vortex07-compare-col--lead");
      const diff = document.createElement("div");
      diff.className = "vortex07-compare-diff";
      diff.textContent = `+${rightRep - leftRep} rep`;
      vs.appendChild(diff);
    } else if (leftRep > 0) {
      const tie = document.createElement("div");
      tie.className = "vortex07-compare-diff vortex07-compare-diff--tie";
      tie.textContent = "Tied";
      vs.appendChild(tie);
    }

    body.appendChild(grid);
    enhanceRetroBadges(modal);
  } catch (err) {
    logWarn("Compare modal failed:", err);
    body.textContent = "Compare unavailable — try again later.";
  }
}

async function isUserInVortex07Cache(userId) {
  const id = safeNumber(userId);
  if (id === null) return false;

  const key = String(id);
  if (sessionMemoryStore.repCache[key]) return true;
  if (Object.prototype.hasOwnProperty.call(sessionMemoryStore.statusCache, key)) {
    return true;
  }

  const data = await storageGet("local", {
    [REPUTATION_CACHE_KEY]: {},
    [STATUS_CACHE_KEY]: {},
  });

  if (data[REPUTATION_CACHE_KEY]?.[key]) return true;
  return Object.prototype.hasOwnProperty.call(data[STATUS_CACHE_KEY] || {}, key);
}

async function cacheFriendIdsFromPage() {
  const ids = [];
  document
    .querySelectorAll(
      ".friends-grid .friend-card, .friends-section .friend-card, .friends-grid > a[href*='/users/']",
    )
    .forEach((card) => {
      const id = getUserIdFromRepNode(card);
      if (id !== null) ids.push(id);
    });

  if (ids.length === 0) return;

  const data = await storageGet("local", { [VORTEX07_FRIEND_IDS_CACHE_KEY]: [] });
  const existing = Array.isArray(data[VORTEX07_FRIEND_IDS_CACHE_KEY])
    ? data[VORTEX07_FRIEND_IDS_CACHE_KEY]
    : [];
  const merged = [...new Set([...ids, ...existing.map((entry) => safeNumber(entry)).filter(Boolean)])].slice(
    0,
    200,
  );
  await storageSet("local", { [VORTEX07_FRIEND_IDS_CACHE_KEY]: merged });
}

async function countFriendsOnVortex07() {
  const cards = document.querySelectorAll(
    ".friends-grid .friend-card, .friends-section .friend-card, .friends-grid > a[href*='/users/']",
  );
  const ids = [];
  cards.forEach((card) => {
    const id = getUserIdFromRepNode(card);
    if (id !== null) ids.push(id);
  });

  if (ids.length === 0) return 0;

  let count = 0;
  for (const id of ids) {
    if (await isUserInVortex07Cache(id)) count += 1;
  }
  return count;
}

function injectMutualVortexIndicator(count) {
  const header = document.querySelector(".profile-header");
  if (!header || count <= 0) return;

  let pill = header.querySelector(".vortex07-mutual-indicator");
  if (!pill) {
    pill = document.createElement("div");
    pill.className = "vortex07-mutual-indicator";
    const statusHost = header.querySelector(".vortex07-profile-status-host");
    const usernameEl = header.querySelector(".profile-username");
    if (statusHost) {
      statusHost.insertAdjacentElement("afterend", pill);
    } else if (usernameEl) {
      usernameEl.insertAdjacentElement("afterend", pill);
    } else {
      header.appendChild(pill);
    }
  }

  pill.textContent =
    count === 1 ? "1 friend uses Vortex07" : `${count} friends use Vortex07`;
}

async function injectProfileMutualIndicator() {
  if (!currentSettings.enabled) return;
  if (getProfileUserIdFromPage() === null) return;

  await cacheFriendIdsFromPage();
  const count = await countFriendsOnVortex07();
  const header = document.querySelector(".profile-header");
  header?.querySelector(".vortex07-mutual-indicator")?.remove();
  if (count > 0) injectMutualVortexIndicator(count);
}

async function collectRoulettePool() {
  const ids = new Set();

  const archive = await loadPlayerArchive();
  archive.forEach((entry) => {
    const id = safeNumber(entry?.id);
    if (id !== null) ids.add(id);
  });

  const recent = await loadRecentPlayers();
  recent.forEach((entry) => {
    const id = safeNumber(entry?.id);
    if (id !== null) ids.add(id);
  });

  const friendData = await storageGet("local", { [VORTEX07_FRIEND_IDS_CACHE_KEY]: [] });
  const friendIds = Array.isArray(friendData[VORTEX07_FRIEND_IDS_CACHE_KEY])
    ? friendData[VORTEX07_FRIEND_IDS_CACHE_KEY]
    : [];
  friendIds.forEach((entry) => {
    const id = safeNumber(entry);
    if (id !== null) ids.add(id);
  });

  document
    .querySelectorAll(".friend-card, .friends-grid > a[href*='/users/']")
    .forEach((card) => {
      const id = getUserIdFromRepNode(card);
      if (id !== null) ids.add(id);
    });

  const repData = await storageGet("local", { [REPUTATION_CACHE_KEY]: {} });
  Object.keys(repData[REPUTATION_CACHE_KEY] || {}).forEach((key) => {
    const id = safeNumber(key);
    if (id !== null) ids.add(id);
  });

  if (ids.size < 5) {
    const leaderboard = await fetchLeaderboard(50);
    leaderboard.forEach((row) => {
      const id = safeNumber(row.userId);
      if (id !== null) ids.add(id);
    });
  }

  if (ids.size < 3 && isPlayvortexApiAvailable()) {
    const letters = ["a", "e", "s", "m", "j"];
    const letter = letters[Math.floor(Math.random() * letters.length)];
    const players = await fetchTopPlayers(letter, {
      userInitiated: true,
      throwOnFailure: false,
    });
    players.forEach((player) => {
      const id = safeNumber(player.id);
      if (id !== null) ids.add(id);
    });
  }

  return [...ids];
}

async function spinVortexRoulette() {
  const btn = document.getElementById("vortex07-roulette-btn");
  if (btn?.classList.contains("vortex07-roulette-spinning")) return;

  let lastId = null;
  try {
    lastId = safeNumber(sessionStorage.getItem(VORTEX07_ROULETTE_LAST_KEY));
  } catch {
    /* ignore */
  }

  btn?.classList.add("vortex07-roulette-spinning");

  const pool = await collectRoulettePool();
  const loggedInId = getLoggedInUserIdFromNav();
  let candidates = pool.filter((id) => id !== lastId && id !== loggedInId);
  if (candidates.length === 0) {
    candidates = pool.filter((id) => id !== loggedInId);
  }
  if (candidates.length === 0) {
    btn?.classList.remove("vortex07-roulette-spinning");
    showVortexToast("No profiles to explore — search some players first");
    return;
  }

  const pick = candidates[Math.floor(Math.random() * candidates.length)];
  try {
    sessionStorage.setItem(VORTEX07_ROULETTE_LAST_KEY, String(pick));
  } catch {
    /* ignore */
  }

  const names = await resolveLeaderboardDisplayNames([pick]);
  const label = names.get(pick) || `user${pick}`;
  showVortexToast(`🎲 ${label}`);

  await sleep(480);
  btn?.classList.remove("vortex07-roulette-spinning");
  window.location.assign(`/users/${pick}/profile`);
}

function injectRouletteButton() {
  if (!currentSettings.enabled) return;

  const anchor = document.getElementById("Alerts") || document.getElementById("Options");
  if (!anchor) return;

  let btn = document.getElementById("vortex07-roulette-btn");
  if (btn) {
    if (!btn.querySelector(".vortex07-roulette-icon")) {
      btn.textContent = "";
      const icon = document.createElement("img");
      icon.className = "vortex07-roulette-icon";
      icon.alt = "";
      icon.src = isExtensionContextAlive()
        ? extensionAssetUrl("assets/logo.png")
        : VORTEX_LOGO_DATA_URI;
      icon.onerror = () => {
        icon.remove();
        btn.textContent = "🎲";
      };
      btn.appendChild(icon);
    }
    return;
  }

  btn = document.createElement("button");
  btn.type = "button";
  btn.id = "vortex07-roulette-btn";
  btn.className = "vortex07-roulette-btn rbx-2007-btn";
  btn.title = "Surprise Me — random Vortex profile";
  btn.setAttribute("aria-label", "Surprise Me");
  btn.textContent = "";
  const icon = document.createElement("img");
  icon.className = "vortex07-roulette-icon";
  icon.alt = "";
  icon.src = isExtensionContextAlive()
    ? extensionAssetUrl("assets/logo.png")
    : VORTEX_LOGO_DATA_URI;
  icon.onerror = () => {
    icon.remove();
    btn.textContent = "🎲";
  };
  btn.appendChild(icon);
  btn.addEventListener("click", () => void spinVortexRoulette());

  const searchHost = findSearchHost();
  if (searchHost?.parentNode === anchor) {
    searchHost.insertAdjacentElement("afterend", btn);
  } else {
    anchor.appendChild(btn);
  }
}

function ensureProfileMetaStack(header) {
  if (!header) return null;

  const avatarWrap = header.querySelector(
    ".profile-avatar-wrap, .vortex07-profile-avatar-slot",
  );
  let stack = header.querySelector(".vortex07-profile-meta-stack");

  if (!stack) {
    stack = document.createElement("div");
    stack.className = "vortex07-profile-meta-stack";
    if (avatarWrap) {
      avatarWrap.insertAdjacentElement("afterend", stack);
    } else {
      header.prepend(stack);
    }
  }

  const orderedSelectors = [
    ".profile-username",
    ".profile-last-seen",
    ".profile-meta",
    ".vortex07-profile-status-host",
    ".vortex07-mutual-indicator",
    ".profile-stats",
    ".profile-actions",
  ];

  orderedSelectors.forEach((selector) => {
    header.querySelectorAll(selector).forEach((el) => {
      if (el.closest(".vortex07-reputation-panel")) return;
      if (!stack.contains(el)) stack.appendChild(el);
    });
  });

  header.classList.add("vortex07-profile-showcase");
  header.dataset.vortex07MetaStack = "1";
  return stack;
}

function injectProfileStatusLine() {
  if (!currentSettings.enabled || !currentSettings.showExtensionStatus) return;

  const header = document.querySelector(".profile-header");
  const usernameEl = header?.querySelector(".profile-username");
  const userId = getProfileUserIdFromPage();
  if (!header || !usernameEl || userId === null) return;

  let host = header.querySelector(".vortex07-profile-status-host");
  if (!host) {
    host = document.createElement("div");
    host.className = "vortex07-profile-status-host";
    usernameEl.insertAdjacentElement("afterend", host);
  }

  host.dataset.vortex07UserId = String(userId);
  const loggedInId = getLoggedInUserIdFromNav();
  const isOwn = loggedInId !== null && loggedInId === userId;

  void (async () => {
    const status = await fetchUserStatus(userId);

    if (isOwn) {
      let editor = host.querySelector(".vortex07-status-editor");
      if (!editor) {
        host.textContent = "";

        const wrap = document.createElement("div");
        wrap.className = "vortex07-status-editor-wrap";

        editor = document.createElement("input");
        editor.type = "text";
        editor.className = "vortex07-status-editor";
        editor.maxLength = STATUS_MAX_LEN;
        editor.placeholder = "Set your Vortex07 status…";
        editor.spellcheck = false;
        editor.setAttribute("aria-label", "Vortex07 status line");

        const hint = document.createElement("span");
        hint.className = "vortex07-status-editor-hint";
        hint.setAttribute("aria-live", "polite");

        const updateHint = (state) => {
          if (state === "saving") {
            hint.textContent = "Saving…";
            hint.classList.add("vortex07-status-hint-saving");
            hint.classList.remove("vortex07-status-hint-synced");
            return;
          }
          if (state === "synced") {
            hint.textContent = "Synced";
            hint.classList.add("vortex07-status-hint-synced");
            hint.classList.remove("vortex07-status-hint-saving");
            return;
          }
          hint.classList.remove("vortex07-status-hint-saving", "vortex07-status-hint-synced");
          hint.textContent = `${editor.value.length}/${STATUS_MAX_LEN}`;
        };

        let saveTimer = null;
        const commit = async () => {
          updateHint("saving");
          editor.classList.remove("vortex07-status-synced");
          const result = await saveUserStatus(userId, editor.value);
          editor.classList.toggle("vortex07-status-empty", !normalizeExtensionStatus(editor.value));
          if (result.synced) {
            editor.classList.add("vortex07-status-synced");
            updateHint("synced");
            setTimeout(() => updateHint("idle"), 2200);
          } else {
            updateHint("idle");
          }
          scheduleExtensionMetaDecorations();
        };

        editor.addEventListener("input", () => {
          editor.classList.remove("vortex07-status-synced");
          updateHint("idle");
          clearTimeout(saveTimer);
          saveTimer = setTimeout(() => void commit(), 500);
        });
        editor.addEventListener("blur", () => void commit());
        editor.addEventListener("keydown", (event) => {
          if (event.key === "Enter") {
            event.preventDefault();
            editor.blur();
          }
        });

        wrap.append(editor, hint);
        host.appendChild(wrap);
        updateHint("idle");
      }

      editor.value = status;
      editor.classList.toggle("vortex07-status-empty", !status);
      return;
    }

    host.textContent = "";
    const line = renderExtensionStatusEl(status, {
      className: "vortex07-ext-status vortex07-ext-status-profile",
      userId,
    });
    if (line) host.appendChild(line);
  })();
}

function cleanupProfileSocialClutter() {
  if (getProfileUserIdFromPage() === null) return;

  document
    .querySelectorAll(
      ".vortex07-guestbook-section, .vortex07-profile-status-host, .vortex07-status-editor",
    )
    .forEach((el) => el.remove());
}

function injectProfileTierFeatures() {
  const header = document.querySelector(".profile-header");
  ensureProfileMetaStack(header);
  cleanupProfileSocialClutter();

  void injectProfileMutualIndicator();
  enhanceFriendsCarousels();
  header?.querySelector(".vortex07-profile-rep-king-banner")?.remove();
  scheduleExtensionMetaDecorations(header || document);
}

