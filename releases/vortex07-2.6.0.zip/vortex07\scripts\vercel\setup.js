#!/usr/bin/env node
/**
 * One-time / repair setup: root directory, link, install deps.
 */
const {
  ensureProjectRootDirectory,
  ensureApiLinked,
  npmInstallApi,
  PROJECT,
} = require("./config.js");

async function main() {
  console.log("Vortex07 API setup");
  console.log(`Project: ${PROJECT.name}`);
  console.log(`Root directory: ${PROJECT.rootDirectory}/`);

  const root = await ensureProjectRootDirectory();
  console.log(
    root.changed
      ? `Updated Vercel rootDirectory → ${root.rootDirectory}`
      : `Vercel rootDirectory already ${root.rootDirectory}`,
  );

  ensureApiLinked();
  console.log("Linked .vercel/project.json");

  npmInstallApi();
  console.log("Installed api/ dependencies");

  console.log("\nSetup complete. Run: npm run api:deploy");
}

main().catch((err) => {
  console.error("Setup failed:", err.message);
  process.exit(1);
});
