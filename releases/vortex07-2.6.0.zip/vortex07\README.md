# Vortex07

Chrome extension that restyles [playvortex.io](https://playvortex.io) with a 2006–2008 Roblox / Windows XP Luna theme — search, global rep, forum, guestbook, badges, and dark mode.

**Version:** 2.6.0

## Install (local / unpacked)

1. Clone or download this repo.
2. `chrome://extensions` → **Developer mode** → **Load unpacked** → select this folder.
3. Visit [playvortex.io](https://playvortex.io).

## Dev preview (CSS / popup)

Fastest loop for styling — **no extension reload** for CSS changes:

```bash
npm run dev
```

Opens **http://127.0.0.1:5173/dev/preview.html** with live CSS reload.

| URL | Use for |
|-----|---------|
| `/dev/preview.html` | Shell mock — home / social / profile tabs, dark toggle |
| `/dev/popup-preview.html` | Extension popup chrome |
| `/dev/fixture.html` | Full extension on localhost (load unpacked, then visit) |

**Extension pages (live site)**

| URL | Who | Panel |
|-----|-----|--------|
| `/home#vortex07-settings` | Everyone | Vortex07 settings |
| `/home#vortex07-forum` | Everyone (if enabled) | Community forum |
| `/admin#vortex07-dashboard` | Devs only (IDs 15936, 18202) | Admin / rep audit |

Popup and nav **Vortex07** tab open settings. **Admin** nav tab (dev-only) opens `/admin#vortex07-dashboard`.

**When to use what**

- **CSS only** → `preview.html` or `popup-preview.html` (edit `src/styles/styles.css` or `popup.css`, save, page refreshes styles automatically)
- **JS / API / real DOM** → unpacked extension on **playvortex.io** — reload extension at `chrome://extensions` after JS changes
- **Extension without live site** → `npm run dev` + visit `fixture.html` with extension loaded

## Share with friends

Build a small zip (extension files only — no API, no scripts):

```bash
npm run pack
```

Send `release/vortex07-2.6.0.zip`. They unzip and **Load unpacked**.

## API (optional — hosts community rep / forum)

```bash
npm run api:deploy
npm run api:verify
```

Live API: `https://vortex07.vercel.app/api`

## Discord updates

Requires `.env` with `DISCORD_WEBHOOK_URL`:

```bash
npm run publish -- "Changelog line 1 | line 2"
```

## Project layout

```
vortex07/
├── manifest.json       # Extension manifest
├── assets/             # Icons, badges, logo
├── src/                # Extension code (popup, content, service worker, styles)
├── api/                # Vercel backend (deploy separately)
├── scripts/
│   ├── pack.js         # Build share zip
│   ├── clean.js        # Remove node_modules / build junk
│   ├── publish-changes.js
│   └── vercel/         # API deploy automation
└── docs/               # Plans & notes
```

**What’s not in the repo:** `node_modules/`, build zips, `.env` — run `npm run clean` if your folder looks bloated locally.

## Permissions

- `storage`, `tabs` — settings and page routing
- `playvortex.io` — theme and features
- `vortex07.vercel.app` — community API
