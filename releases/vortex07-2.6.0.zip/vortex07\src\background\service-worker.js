/* Proxies Vortex07 community API calls — bypasses page CORS from playvortex.io. */
const ext = typeof browser !== "undefined" ? browser : chrome;

/**
 * SECURITY NOTE (secrets in bundle):
 *
 * VOTE_SECRET and ADMIN_SECRET are embedded in this service worker because MV3
 * does not support runtime secret injection. This "raises the bar" against casual
 * API abuse — the signature still requires a matching Vercel env var, and votes are
 * additionally constrained by account-binding, rate limits, and daily caps.
 *
 * For a Chrome Web Store / public release:
 *  - Rotate both secrets to new values on Vercel before publishing.
 *  - Never log these values (debugLogs guard in content.js must not reach SW).
 *  - Admin secret is only injected when message.adminAuth === true, which only
 *    fires for users with dev account IDs (15936, 18202) — client-side guard only;
 *    server-side must validate X-Vortex07-Admin independently.
 */

/** Only the canonical API host is allowed; no wildcard *.vercel.app. */
const ALLOWED_API_HOSTS = new Set(["vortex07.vercel.app"]);

/** Must match VORTEX07_VOTE_SECRET on Vercel. */
const VOTE_SECRET = "vortex07-vote-hmac-v2-5-0-playvortex";
/** Must match VORTEX07_ADMIN_SECRET on Vercel. */
const ADMIN_SECRET = "vortex07-admin-audit-v2-5-0";

function isAllowedApiUrl(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return false;
    return ALLOWED_API_HOSTS.has(parsed.hostname);
  } catch {
    return false;
  }
}

function bytesToHex(bytes) {
  return [...new Uint8Array(bytes)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function buildVoteSignatureHeaders(actorUserId, targetUserId) {
  const timestamp = String(Date.now());
  const payload = `${actorUserId}|${targetUserId}|${timestamp}`;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(VOTE_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(payload),
  );
  return {
    "X-Vortex07-Timestamp": timestamp,
    "X-Vortex07-Signature": bytesToHex(signature),
  };
}

function parseVoteBody(body) {
  if (!body) return null;
  try {
    const json = typeof body === "string" ? JSON.parse(body) : body;
    const actorUserId = String(json?.actorUserId || "").trim();
    const targetUserId = String(json?.userId || "").trim();
    if (!/^\d+$/.test(actorUserId) || !/^\d+$/.test(targetUserId)) return null;
    return { actorUserId, targetUserId };
  } catch {
    return null;
  }
}

function parseVoteQuery(url) {
  try {
    const parsed = new URL(url);
    const actorUserId = String(parsed.searchParams.get("actorUserId") || "").trim();
    const targetUserId = String(parsed.searchParams.get("userId") || "").trim();
    if (!/^\d+$/.test(actorUserId) || !/^\d+$/.test(targetUserId)) return null;
    return { actorUserId, targetUserId };
  } catch {
    return null;
  }
}

async function maybeSignReputationRequest(url, method, headers, body) {
  const upper = String(method || "GET").toUpperCase();
  if (upper !== "POST" && upper !== "DELETE") return headers || {};

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return headers || {};
  }

  if (!parsed.pathname.endsWith("/reputation")) return headers || {};

  const vote =
    parseVoteBody(body) ||
    parseVoteQuery(url) ||
    null;
  if (!vote) return headers || {};

  const signHeaders = await buildVoteSignatureHeaders(
    vote.actorUserId,
    vote.targetUserId,
  );
  return { ...(headers || {}), ...signHeaders };
}

ext.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "vortex07-api-fetch") return undefined;

  const url = String(message.url || "");
  if (!isAllowedApiUrl(url)) {
    sendResponse({ error: "blocked-url" });
    return false;
  }

  void (async () => {
    try {
      const headers = await maybeSignReputationRequest(
        url,
        message.method,
        message.headers,
        message.body,
      );

      if (message.adminAuth) {
        headers["X-Vortex07-Admin"] = ADMIN_SECRET;
      }

      const response = await fetch(url, {
        method: message.method || "GET",
        headers,
        body: message.body || undefined,
      });

      const body = await response.text();
      sendResponse({
        ok: response.ok,
        status: response.status,
        statusText: response.statusText,
        body,
        headers: {
          "content-type": response.headers.get("content-type") || "application/json",
        },
      });
    } catch (err) {
      sendResponse({ error: String(err?.message || err || "fetch failed") });
    }
  })();

  return true;
});
